var lazyLoadInstance = new LazyLoad({
  elements_selector: ".b-lazy",
  callback_loaded: function(element){
    setTimeout(function(){
      var parent = element.parentNode;
      parent.className = parent.className.replace(/\bb-loading\b/,'');
    }, 200);
  }
});

var roar = {
  init: function() {
      this.handleAccount(),
      this.handleCartAgree(),
      this.handleAddress(),
      this.initProductQuickShopItem(),
      this.initFilterSidebar(),
      this.initFooterCollapse(),
      this.initVerticalMenuSidebar(),
      this.initChangeInputNameCartPage(),
      this.handleOrder(),
      this.initCountdown(),
      this.addToCart(),
      this.cartSidebar(),
      this.removeCart(),
      this.addToWishlist(),
      this.handleCompare(),
      this.removeToWishlist(),
      this.handlePopups(),
      this.handleSearch(),
      this.handleGMap(),
      this.handleScrollToTop(),
      this.handleSmoothScroll(),
      this.mapFilters(),
      this.handleQuickshop(),
      this.handleBlog(),
      this.handleCookie(),
      this.fixedHeaderMenu(),
      this.searchAutoComplete(),
      this.handleDropdown(),
      this.toggleFilter(),
      this.handleHeaderNotice(),
      this.handleInstagramFloatBar()
  },
  handleSeasonalFrame: function() {
      jQuery(window).resize(function() {
          if (0 < $(".rt-seasonal-frames").length) {
              var t = !1;
              if (0 == $(".rt-seasonal-frames").data("mobile") && 768 < roar.getWidthBrowser() && (t = !0), 1 == $(".rt-seasonal-frames").data("mobile") && (t = !0), 1 == t) {
                  $(".rt-seasonal-frames").show();
                  for (var e = $(".rt-seasonal-frames"), i = e.data("ow"), a = e.data("oh"), n = 0; n < e.children().length; n++) {
                      var o, s, r, c, l = $(e.children()[n]),
                          d = l.data("position"),
                          h = l.data("idx"),
                          u = l.data("w"),
                          p = l.data("h"),
                          f = l.data("x"),
                          m = l.data("y"),
                          g = l.data("src"),
                          v = 1e3 + h;
                      "top" == d || "bottom" == d ? (s = u * (o = window.innerWidth / i), _newHeight = p * o, r = f * o, c = "top" == d ? m * o : (a - m - p) * o, l.html(""), l.html('<img width="' + s + '" height="' + _newHeight + '" style="z-index:' + v + ";left:" + r + "px;" + d + ":" + c + 'px" src="' + g + '"/>')) : (s = u * (o = window.innerHeight / a), _newHeight = p * o, c = m * o, r = "left" == d ? f * o : (i - f - u) * o, l.html(""), l.html('<img width="' + s + '" height="' + _newHeight + '" style="z-index:' + v + ";top:" + c + "px;" + d + ":" + r + 'px" src="' + g + '"/>'))
                  }
              } else $(".rt-seasonal-frames").hide()
          }
      }).resize()
  },
  handleCartAgree: function() {
      $("body").on("change", ".product-cart__agree", function(t) {
          var e = $(this),
              i = $(this).closest(".cart__condition__wrapper").find(".checkout-button");
          e.is(":checked") ? i.removeClass("btn-disabled") : i.addClass("btn-disabled")
      })
  },
  handleAddress: function() {
      var t = $("#AddressNewForm");
      t.length && (Shopify && new Shopify.CountryProvinceSelector("AddressCountryNew", "AddressProvinceNew", {
          hideElement: "AddressProvinceContainerNew"
      }), $(".address-country-option").each(function() {
          var t = $(this).data("form-id"),
              e = "AddressCountry_" + t,
              i = "AddressProvince_" + t,
              a = "AddressProvinceContainer_" + t;
          new Shopify.CountryProvinceSelector(e, i, {
              hideElement: a
          })
      }), $(".address-new-toggle").on("click", function() {
          t.toggleClass("hide")
      }), $(".address-edit-toggle").on("click", function() {
          var t = $(this).data("form-id");
          $("#EditAddress_" + t).toggleClass("hide")
      }), $(".address-delete").on("click", function() {
          var t = $(this),
              e = t.data("form-id"),
              i = t.data("confirm-message");
          confirm(i || "Are you sure you wish to delete this address?") && Shopify.postLink("/account/addresses/" + e, {
              parameters: {
                  _method: "delete"
              }
          })
      }))
  },
  handleAccount: function() {
      function t() {
          return $("#recover-password").fadeIn(), $("#customer-login").hide(), !(window.location.hash = "#recover")
      }

      function e() {
          return $("#recover-password").hide(), $("#customer-login").fadeIn(), window.location.hash = "", !1
      }
      $("#forgot_password a").click(function() {
          t()
      }), "#recover" == window.location.hash ? t() : e(), $("#recover-password .cancel").click(function() {
          e()
      })
  },
  handleHeaderNotice: function() {
      if (window.hn_use) {
          var t = !0;
          window.hn_once && "yes" == localStorage.getItem("displayNotice") && (t = !1), 1 == t && ($("#header-notice .header-notice").children().show(), $("#header-notice .close-notice").on("click", function() {
              return window.hn_once && localStorage.setItem("displayNotice", "yes"), $("#header-notice .header-notice").children().hide(), !1
          }))
      }
  },
  handleInstagramFloatBar: function() {
      window.social_instagram && $.instagramFeed({
          username: $("#instagram_list").data("uid"),
          items: $("#instagram_list").data("limit"),
          container: "#instagram_list",
          display_profile: !1,
          display_biography: !1,
          display_gallery: !0,
          get_raw_json: !1,
          callback: null,
          styling: !1,
          custom_class: ""
      })
  },
  initLazyLoading: function(t, e) {
      lazyLoadInstance.update()
  },
  initProductQuickShopItem: function(t) {
      t = t || "body";

      function n(t, e) {
          var i = t.replace("https:", "").replace("http:", "").split("?v=")[0].split("/"),
              a = i[i.length - 1].split("."),
              n = a.pop(),
              o = a.join(".") + e + "@2x." + n,
              s = a.join(".") + e + "." + n,
              r = {};
          return r.srcset = t.replace(i[i.length - 1], o) + " 500w," + t.replace(i[i.length - 1], s) + " 166w", r.src = t.replace(i[i.length - 1], s), r
      }

      function o(t, e) {
          if (e.available ? (t.find("div.price").data("price", e.price), t.find(".btn-action.addtocart-item-js span").text(theme.strings.addToCart), t.find(".btn-action.addtocart-item-js").prop("disabled", !1)) : (t.find("div.price").data("price", "0"), t.find(".btn-action.addtocart-item-js span").text(theme.strings.soldOut), t.find(".btn-action.addtocart-item-js").prop("disabled", !0)), 0 < t.closest(".grouped-product").length && roar.updateGroupedPrice(), t.find("select.variation-select.no-js").val(e.id), t.find("span.price-new.money").html(theme.Currency.formatMoney(e.price, theme.settings.moneyFormat)), e.compare_at_price > e.price) {
              if (t.find("span.price-old.money").html(theme.Currency.formatMoney(e.compare_at_price, theme.settings.moneyFormat)).removeClass("hide"), t.find(".sale").text(theme.strings.sale).removeClass("hide"), t.find(".sale").hasClass("percentage")) {
                  var i = Math.round(100 * (e.compare_at_price - e.price) / e.compare_at_price);
                  t.find(".sale").text("-" + i + "%")
              }
          } else t.find("span.price-old.money").addClass("hide"), t.find(".sale").addClass("hide");
          if (window.show_multiple_currencies && (function(t) {
                  var e, i = t,
                      a = [],
                      n = i.get(0).attributes,
                      o = n.length;
                  for (e = 0; e < o; e++) "data-" === n[e].name.substring(0, 5) && a.push(n[e].name);
                  $.each(a, function(t, e) {
                      i.removeAttr(e)
                  })
              }(t.find(".money")), theme.CurrencyPicker.convert(".product-item-advanced-wrapper .money")), null !== e.featured_image) {
              ! function(t, e) {
                  var i = e.replace("https:", "").replace("http:", "").split("?v=")[0],
                      a = "";
                  0 < t.find(".item-images-wrapper a").length && t.find(".item-images-wrapper a").each(function() {
                      $(this).data("_image").replace("https:", "").replace("http:", "").split("?v=")[0] != i || (a = $(this))
                  }), t.find(".item-images-wrapper a").removeClass("active"), "" != a && a.addClass("active")
              }(t, e.featured_image.src);
              var a = n(e.featured_image.src, t.data("_dim"));
              t.find("img.mpt-image").attr("srcset", a.srcset).attr("src", a.src)
          }
      }
      var e = $(t).find(".single-option-selector-item");
      0 < e.length && e.unbind("change") && e.on("change", function() {
          var t = $(this).closest(".product-item-advanced-wrapper");
          if (0 < $(t.find(".product-item-option").data("id")).length) {
              var e = JSON.parse($(t.find(".product-item-option").data("id")).html()),
                  i = {},
                  a = "not_found";
              for ($(this).closest(".variations-content").find(".single-option-selector-item").each(function() {
                      i[$(this).data("index")] = $(this).val()
                  }), k = 0; k < e.variants.length; k++) {
                  var n = !1;
                  for (ol = 1; ol <= e.options.length; ol++) {
                      if (i["option" + ol] != e.variants[k]["option" + ol]) {
                          n = !1;
                          break
                      }
                      n = !0
                  }
                  if (1 == n) {
                      a = "found", o(t, e.variants[k]);
                      break
                  }
              }
              "not_found" == a && (t.find(".btn-action.addtocart-item-js span").text(theme.strings.unavailable), t.closest(".product-item-advanced-wrapper").find(".btn-action.addtocart-item-js").prop("disabled", !0))
          }
      });
      var a = $(t).find(".product-item-option");
      if (0 < a.length) {
          var P = 0,
              A = {};
          a.each(function() {
              if (!$(this).hasClass("has-swatch-finished")) {
                  P += 1;
                  var t = $(this).closest(".product-item-advanced-wrapper").addClass("product-item-advanced-wrapper-" + P);
                  if ($(this).find(".single-option-selector-item").each(function() {
                          var t = $(this).data("id") + "-" + P;
                          $(this).attr("id", t), $(this).data("_index", P)
                      }), 0 < $($(this).data("id")).length) {
                      var n = JSON.parse($($(this).data("id")).html());
                      0 < $($(this).data("swatch_id")).length && (A = JSON.parse($($(this).data("swatch_id")).html()));
                      var e = new Array;
                      if ("1" == window.swatch_size && e.push("Size"), e.push("size"), "1" == window.swatch_color && (e.push("Color"), e.push("Colour"), e.push("color"), e.push("colour")), 0 < e.length) {
                          var a = !1,
                              o = 0,
                              s = theme.asset_url.substring(0, theme.asset_url.lastIndexOf("?")),
                              r = theme.asset_url.substring(theme.asset_url.lastIndexOf("?"), theme.asset_url.length);
                          for (i = 0; i < n.options.length; i++) {
                              var c = "",
                                  l = "",
                                  d = "",
                                  h = "",
                                  u = "",
                                  p = "",
                                  f = "",
                                  m = "img btooltip";
                              if (c = "object" == typeof n.options[i] ? n.options[i].name : n.options[i], a = !1, -1 < e.indexOf(c)) {
                                  a = !0, o = i;
                                  var g = c.toLowerCase();
                                  if (/color|colour/i.test(g) && !0, a) {
                                      var v = new Array;
                                      for (j = 0; j < n.variants.length; j++) {
                                          var _ = n.variants[j],
                                              w = (I = _.options[o], String(I).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;")),
                                              y = w.toLowerCase().replace(/[^a-z0-9 -]/g, "").replace(/\s+/g, "-").replace(/-+/g, "-");
                                          v.indexOf(w) < 0 && ("color" != g && "colour" != g ? (f = w, m = "btooltip") : f = "1" == window.swatch_color_advanced ? null !== A[y] && void 0 !== A[y] && "" != A[y] ? (m = "img btooltip swatch_color_advanced", '<i class="b-lazy" data-src="' + s + A[y] + ".png" + r + '"></i>') : null !== _.featured_image ? (m = "img btooltip swatch_color_advanced", '<i class="b-lazy" data-src="' + (C = _.featured_image.src, S = k = void 0, k = C.replace("https:", "").replace("http:", "").split("?v=")[0].split("/"), S = k[k.length - 1].split("."), x = S.pop(), T = S.join(".") + "_100x." + x, C.replace(k[k.length - 1], T)) + '"></i>') : '<i class="b-lazy" style="background-color:' + w + ';" data-src="' + s + y + ".png" + r + '"></i>' : '<i class="b-lazy" style="background-color:' + w + ';" data-src="' + s + y + ".png" + r + '"></i>', p = $("#single-option-selector-" + n.id + "-" + o + "-" + P).val() == w ? "selected " : "", d = d + '<div class="swatch-element ' + g + y + ' available"><input data-id="#single-option-selector-' + n.id + "-" + o + "-" + P + '" data-value="' + w + '"  class="swatch-radio ' + p + '" id="swatch-single-option-selector-' + n.id + "-" + o + "-" + y + "-" + P + '" type="radio" data-swatch="' + g + '" data-poption="' + o + '" name="option-' + o + '" value="' + w + '"><label for="swatch-single-option-selector-' + n.id + "-" + o + "-" + y + "-" + P + '" class="' + m + '" title="' + w + '"><span class="soldout-image"></span>' + f + "</label></div>", v.push(w))
                                      }
                                      l = '<div class="wrapper-swatches-product-item wrapper-swatches swatch ' + g + '" data-attribute_name="attribute_pa_' + g + '"><div>' + d + "</div></div>", h = t.find("#single-option-selector-" + n.id + "-" + o + "-" + P), u = t.find("#single-option-selector-" + n.id + "-" + o + "-" + P), "" != l && (h.after(l), h.hide(), u.addClass("hide-choose-option"))
                                  }
                              }
                          }
                      }
                      var b = "";
                      0 < t.find(".wrapper-swatches-product-item").length && ((b = t.find(".wrapper-swatches-product-item .swatch-radio")).unbind("click"), b.on("click", function() {
                          var t = $(this).closest(".product-item-advanced-wrapper").find($(this).data("id")),
                              e = $(this).data("poption"),
                              a = $(this).data("value");
                          $(this).data("value") != t.val() && (t.val($(this).data("value")).trigger("change"), t.closest(".selector-wrapper").find(".swatch-radio").removeClass("selected"), $(this).addClass("selected")),
                              function(s, r, c, l) {
                                  if (1 < r.options.length)
                                      for (i = 0; i < r.options.length; i++) i != c && $("#single-option-selector-" + r.id + "-" + i + "-" + s + " option").each(function() {
                                          var t = $(this).closest(".product-item-advanced-wrapper"),
                                              e = "unavailable",
                                              a = $(this).attr("value");
                                          for (j = 0; j < r.variants.length; j++) {
                                              var n = r.variants[j];
                                              if (n.options[c] == l && n.options[i] == a) {
                                                  e = 1 == n.available ? "available" : "sold_out";
                                                  break
                                              }
                                          }
                                          var o = t.find(".variations-content-" + r.id + " #swatch-" + i + "-" + a.toLowerCase().replace(/[^a-z0-9 -]/g, "").replace(/\s+/g, "-").replace(/-+/g, "-") + "-" + s);
                                          $(o).closest(".swatch-element").removeClass("available").removeClass("sold_out").removeClass("unavailable").addClass(e)
                                      });
                                  else
                                      for (i = 0; i < r.options.length; i++) $("#single-option-selector-" + r.id + "-" + i + "-" + s + " option").each(function() {
                                          var t = $(this).closest(".product-item-advanced-wrapper"),
                                              e = "unavailable",
                                              a = $(this).attr("value");
                                          for (j = 0; j < r.variants.length; j++)
                                              if (r.variants[j].options[i] == a) {
                                                  e = r.variants[j].available ? "available" : "sold_out";
                                                  break
                                              } var n = t.find(".variations-content-" + r.id + " #swatch-" + i + "-" + a.toLowerCase().replace(/[^a-z0-9 -]/g, "").replace(/\s+/g, "-").replace(/-+/g, "-") + "-" + s);
                                          $(n).closest(".swatch-element").removeClass("available").removeClass("sold_out").removeClass("unavailable").addClass(e)
                                      })
                              }(t.data("_index"), n, e, a)
                      })), $(".swatch-radio.selected").trigger("click")
                  }
                  $(this).addClass("has-swatch-finished")
              }
              var C, k, S, x, T, I
          })
      }
      $(document).on("mouseenter mouseleave click", ".product-item-advanced-wrapper:not(.ag-column-content.col-sm-3 .product-item-advanced-wrapper):not(.ag-column-content.col-sm-4 .product-item-advanced-wrapper)", function(t) {
          if (!$(this).parent().hasClass("mproducts-list-detail")) {
              var e = $(this),
                  i = window.innerWidth,
                  a = e.find(".product-item-content"),
                  n = e.find(".product-item-inside-hover"),
                  o = parseInt(n.height()) + parseInt(n.css("marginTop")) + 3,
                  s = e.find(".count_holder_item .is-countdown"),
                  r = (e.find(".count_holder_item .is-countdown").innerHeight(), e.find(".item-images-wrapper"));
              e.find(".item-images-wrapper").innerHeight(), t.target, "mouseenter" === t.type && 1024 < i ? (e.css({
                  height: "100%"
              }).addClass("hovered"), a.css("transform", "translateY(-" + o + "px)"), n.css("opacity", "1"), s.css("transform", "translateY(-" + parseInt(o + 10) + "px)"), r.css("transform", "translateY(-" + parseInt(o) + "px)")) : "mouseleave" === t.type && t.relatedTarget && 1024 < i && (e.removeClass("hovered").removeAttr("style"), a.removeAttr("style"), n.removeAttr("style"), s.removeAttr("style"), r.removeAttr("style"))
          }
      }), 0 < $(".item-images-wrapper").length && $(".item-images-wrapper a").on("click", function() {
          if (!$(this).hasClass("active")) {
              var t = n($(this).data("_image"), $(this).data("_dim"));
              $(this).closest(".item-images-wrapper").find("a").removeClass("active"), $(this).addClass("active"), $(this).closest(".product-content-wrapper").find("img.mpt-image").attr("srcset", t.srcset).attr("src", t.src)
          }
      }), $(".items-image-buttons a").on("click", function(t) {
          t.preventDefault(), $(this).hasClass("next") ? $(this).closest(".product").find(".item-images-wrapper a.active").next().trigger("click") : $(this).closest(".product").find(".item-images-wrapper a.active").prev().trigger("click")
      })
  },
  initFilterSidebar: function() {
      $(".filter_title .arrow").click(function() {
          $(this).toggleClass("rotArr"), $(this).parent().next().slideToggle(300)
      })
  },
  initFooterCollapse: function() {
      $(".footer-accordion-heading").on("click", function(t) {
          t.preventDefault();
          var e = $(this).closest(".footer-accordion").find(".footer-accordion-content"),
              i = $(this).find("i.fa");
          i.hasClass("aDown") ? i.removeClass("aDown") && e.slideUp() : i.addClass("aDown") && e.slideDown()
      })
  },
  initVerticalMenuSidebar: function() {
      $(".ver-dropdown-parent-submenu a.dropdown-link").on("click", function(t) {
          t.preventDefault();
          var e = $(this).closest(".ver-dropdown-parent-submenu").find("ul.ver-dropdown-menu"),
              i = $(this).find("i.fa");
          i.hasClass("aDown") ? i.removeClass("aDown") && e.slideUp() : i.addClass("aDown") && e.slideDown()
      })
  },
  changeInputNameCartPage: function() {
      var t = "updates[]";
      767 < $(window).width() ? ($(".input-mobile").attr("name", ""), $(".input-desktop").attr("name", t)) : ($(".input-mobile").attr("name", t), $(".input-desktop").attr("name", ""))
  },
  initChangeInputNameCartPage: function() {
      $(".input-mobile").length && $(".input-desktop").length && (roar.changeInputNameCartPage(), $(window).resize(function() {
          roar.changeInputNameCartPage()
      }))
  },
  fixedHeaderMenu: function() {
      if (!($(window).width() <= 991)) {
          if (0 < $("#header-phantom").length && $("#header-phantom").remove(), 0 < $(".section-megamenu-content").length && $(".section-megamenu-content").each(function() {
                  var t = $(this).data("menu_width_class");
                  0 < $(this).closest(".shopify-section").length && ($(this).closest(".shopify-section").hasClass(t) || $(this).closest(".shopify-section").addClass(t))
              }), "menu" == window.fixed_header) $('<div id="header-phantom" class="fixed-header-1 sticky-header"></div>').insertAfter(".megamenu-background"), $(".megamenu-background").clone().appendTo("#header-phantom"), roar.fixedMenu(), $(window).resize(function() {
              roar.fixedMenu()
          }), $(window).scroll(function() {
              roar.fixedMenu()
          });
          else if ("header" == window.fixed_header) {
              $('<div id="header-phantom" class="fixed-header-1 sticky-header"></div>').insertAfter("#top"), $("#top").clone().appendTo("#header-phantom"), roar.fixedHeader(), $(window).resize(function() {
                  roar.fixedHeader()
              }), $(window).scroll(function() {
                  roar.fixedHeader()
              })
          }
          0 < $("#header-phantom .shopify-section").length && $("#header-phantom .shopify-section").each(function() {
              $(this).removeClass("shopify-section")
          })
      }
  },
  fixedHeader: function() {
      var t = $("header #top").first().width();
      $("header #top .background").first().width() != $("header").first().width() && $(".sticky-header").css("background", "none"), $(".sticky-header").css("width", t).css("left", "50%").css("right", "auto").css("margin-left", "-" + Math.ceil(t / 2) + "px").css("margin-right", "-" + Math.ceil(t / 2) + "px"), 1160 <= roar.getWidthBrowser() && 280 < $(window).scrollTop() ? $(".sticky-header").addClass("fixed-header") : $(".sticky-header").removeClass("fixed-header")
  },
  fixedMenu: function() {
      var t = $("header .megamenu-background").first().width();
      $("header #top .background").first().width() != $("header").first().width() && $(".sticky-header").css("background", "none"), $(".sticky-header").css("width", t).css("left", "50%").css("right", "auto").css("margin-left", "-" + Math.ceil(t / 2) + "px").css("margin-right", "-" + Math.ceil(t / 2) + "px"), 1160 <= roar.getWidthBrowser() && 280 < $(window).scrollTop() ? $(".sticky-header").addClass("fixed-header") : $(".sticky-header").removeClass("fixed-header")
  },
  toggleFilter: function() {
      $("#filter-sidebar").on("click", function() {
          $("body").toggleClass("open_filter")
      }), $(document).on("click", ".open_filter .spinner", function() {
          $("body").removeClass("open_filter")
      }), $("#filter-addtocart").on("click", function() {
          $("#product .add-to-cart").trigger("click")
      })
  },
  searchAutoComplete: function() {
      var s = null;
      $('form[action="/search"]').each(function() {
          var n = "product",
              t = $(this).find('select[name="category_id"]'),
              e = $(this).find('input[name="type"]');
          0 < t.length && 0 < e.length && $(t).bind("change", function() {
              $(e).val($(this).val()), n = $(this).val()
          });
          var o = $(this).find('input[name="q"]');
          $('<ul class="ui-autocomplete ui-front"></ul>').appendTo($(this).find(".autocomplete-results")).hide(), o.attr("autocomplete", "off").bind("keyup change", function() {
              var t = $(this).val(),
                  e = $(this).closest("form"),
                  i = "/search?type=" + n + "&q=*" + t + "*",
                  a = e.find(".ui-autocomplete");
              3 <= t.length && t != $(this).attr("data-old-term") && (o.addClass("ui-autocomplete-loading"), $(this).attr("data-old-term", t), null != s && s.abort(), s = $.getJSON(i + "&view=result", function(t) {
                  o.removeClass("ui-autocomplete-loading"), a.empty(), 0 == t.results_count ? a.hide() : ($.each(t.results, function(t, e) {
                      var i = $("<a></a>").attr("href", e.url);
                      i.append('<span class="thumbnail"><img src="' + e.thumbnail + '" /></span>'), i.append('<span class="title">' + e.title + "</span>"), i.wrap("<li></li>"), a.append(i.parent())
                  }), 1 < t.results_count && a.append('<li><span class="title"><a href="' + i + '">' + window.all_results_text + " (" + t.results_count + ")</a></span></li>"), a.fadeIn(200))
              }))
          })
      }), $("body").bind("click", function() {
          $(".ui-autocomplete").hide()
      })
  },
  destroyCountdown: function() {
      $.fn.countdown && $(".is-countdown").countdown("destroy")
  },
  initCountdown: function() {
      $.fn.countdown && $(".countdown:not(.is-countdown)").each(function() {
          var t = $(this),
              e = new Date,
              i = new Date(parseInt(t.data("year")), parseInt(t.data("month")) - 1, t.data("day"));
          e < i ? t.countdown({
              until: i
          }) : t.parent().hide()
      })
  },
  handleCookie: function() {
      ! function() {
          try {
              var t = "popup-module-cookie";
              if (0 < document.cookie.length) {
                  var e = document.cookie.indexOf(t + "=");
                  if (-1 != e) {
                      e = e + t.length + 1;
                      var i = document.cookie.indexOf(";", e);
                      return -1 == i && (i = document.cookie.length), unescape(document.cookie.substring(e, i))
                  }
              }
          } catch (t) {
              console.log(t.message)
          }
      }() && $("#cookie").length && ($("#cookie.cookie").length ? $("#cookie").fadeIn("slow") : $("#cookie.popup").length && $.magnificPopup.open({
          items: {
              src: "#cookie",
              type: "inline"
          },
          tLoading: "",
          mainClass: "popup-module mfp-with-zoom popup-type-2",
          removalDelay: 200,
          modal: !0
      }), $("#cookie .accept").click(function() {
          (function() {
              try {
                  var t = "domain=." + document.domain,
                      e = new Date;
                  e.setTime(e.getTime() + 31536e6);
                  var i = "; expires=" + e.toGMTString();
                  document.cookie = "popup-module-cookie=true" + i + "; path=/; " + t
              } catch (t) {
                  console.log(t.message)
              }
          })(), $("#cookie.cookie").length ? $("#cookie").fadeOut("slow") : $("#cookie.popup").length && $.magnificPopup.close()
      }))
  },
  handleBlog: function() {
      if ($("body").hasClass("templateBlog")) {
          var t = {};
          $(".posts").hasClass("posts-grid") && (t = $(".posts").masonry({
              itemSelector: ".post"
          })).imagesLoaded().progress(function() {
              t.masonry("layout")
          }), $("#load-more").click(function() {
              var e = $(this).attr("data-page");
              $.ajax({
                  url: location.href,
                  type: "get",
                  dataType: "html",
                  data: {
                      page: e
                  },
                  beforeSend: function() {
                      $("#load-more").button("loading")
                  },
                  complete: function() {
                      $("#load-more").button("reset")
                  },
                  success: function(t) {
                      return "" == t ? void $(".pagination-ajax").fadeOut() : ($(".posts").hasClass("posts-grid") ? ($(".posts").append($(t).find(".posts").html()), $(".posts").masonry("reloadItems").masonry({
                              sortBy: "original-order"
                          }), setTimeout(function() {
                              $(".posts").masonry("reloadItems").masonry({
                                  sortBy: "original-order"
                              })
                          }, 500)) : $(".posts").append($(t).find(".posts").html()), $("#load-more").attr("data-page", parseInt(++e)), void
                          function(t) {
                              $.ajax({
                                  url: location.href,
                                  type: "get",
                                  dataType: "html",
                                  data: {
                                      page: t
                                  },
                                  success: function(t) {
                                      "" != $(t).find(".blog-page .empty").html() && $(".pagination-ajax").hide()
                                  },
                                  error: function() {
                                      $(".pagination-ajax").hide()
                                  }
                              })
                          }(e))
                  }
              })
          })
      }
  },
  handleCompare: function() {
      "1" == window.compare && (roar.handleCompareEvent(), roar.autoloadCompare(), roar.handleCompareScroll())
  },
  handleCompareEvent: function() {
      var t = $("body");
      $("a.add_to_compare");
      t.on("click", "a.add_to_compare", function() {
          var t = $(this).data("pid"),
              e = "",
              i = RoarCookie.cookie.rtread("rt-compare");
          if ((i = null != i && "" != i ? i.split(",") : new Array).indexOf(t) < 0 && !1 === $(this).hasClass("added")) {
              i.push(t);
              var a = i.join(",");
              "," == a.substring(0, 1) && (a = a.substring(1)), RoarCookie.cookie.rtwrite("rt-compare", a)
          }!1 === $(this).hasClass("added") || "" === e ? (e = "", $.ajax({
              url: "/search?view=compare&q=" + i,
              dataType: "html",
              type: "GET",
              success: function(t) {
                  e = t
              },
              error: function(t) {
                  console.log("ajax error")
              },
              complete: function() {
                  $.magnificPopup.open({
                      items: {
                          src: e,
                          type: "inline"
                      },
                      preloader: !0,
                      tLoading: "",
                      mainClass: "quickview compareview",
                      removalDelay: 200,
                      gallery: {
                          enabled: !0
                      },
                      callbacks: {
                          open: function() {
                              $('[data-pid="' + t + '"]').addClass("added").attr("title", $('[data-pid="' + t + '"]').attr("data-added")), $('[data-pid="' + t + '"]').find("span").html($('[data-pid="' + t + '"]').attr("data-add")), window.show_multiple_currencies && theme.CurrencyPicker.convert(".compare-content .money"), roar.handleReviews(), roar.handleCompareScroll()
                          }
                      }
                  })
              }
          })) : $.ajax({
              url: "/search?view=compare&q=" + i,
              dataType: "html",
              type: "GET",
              success: function(t) {
                  e = t
              },
              error: function(t) {
                  console.log("ajax error")
              },
              complete: function() {
                  $.magnificPopup.open({
                      items: {
                          src: e,
                          type: "inline"
                      },
                      preloader: !0,
                      tLoading: "",
                      mainClass: "quickview compareview",
                      removalDelay: 200,
                      gallery: {
                          enabled: !0
                      },
                      callbacks: {
                          open: function() {
                              window.show_multiple_currencies && theme.CurrencyPicker.convert(".compare-content .money"), roar.handleReviews(), roar.handleCompareScroll()
                          }
                      }
                  })
              }
          })
      }), t.on("click", ".remove_from_compare", function(t) {
          t.preventDefault();
          var e = $(this).attr("data-rev");
          $(".compare-content");
          $('[data-pid="' + e + '"]').removeClass("added").attr("title", $('[data-pid="' + e + '"]').attr("data-add")), $('[data-pid="' + e + '"]').find("span").html($('[data-pid="' + e + '"]').attr("data-add"));
          var i = decodeURI(RoarCookie.cookie.rtread("rt-compare"));
          null != i && (i = i.split(",")), i = jQuery.grep(i, function(t) {
              return t != e
          }), i = $.trim(i), RoarCookie.cookie.rtwrite("rt-compare", i), $(".fastor_" + e).remove(), i.length <= 0 && $(".mfp-close").trigger("click")
      })
  },
  autoloadCompare: function() {
      if (0 != parseInt(theme.compare)) {
          var t = RoarCookie.cookie.rtread("rt-compare");
          null != t ? (t = t.split(",")).map(function(t, e) {
              $('[data-pid="' + t + '"]').addClass("added").attr("title", $('[data-pid="' + t + '"]').attr("data-added")), $('[data-pid="' + t + '"]').find("span").html($('[data-pid="' + t + '"]').attr("data-added"))
          }) : t = new Array
      }
  },
  handleCompareScroll: function() {
      jQuery("#be_compare_features_table").on("scroll", function() {
          var t = jQuery(this).parent();
          jQuery(this).scrollLeft() + jQuery(this).innerWidth() >= jQuery(this)[0].scrollWidth ? t.hasClass("scroll-right") && t.removeClass("scroll-right") : 0 === jQuery(this).scrollLeft() ? t.hasClass("scroll-left") && t.removeClass("scroll-left") : (t.hasClass("scroll-right") || t.addClass("scroll-right"), t.hasClass("scroll-left") || t.addClass("scroll-left"))
      }), be_compare_container = document.getElementById("be_compare_features_table"), null !== be_compare_container && be_compare_container.offsetWidth < be_compare_container.scrollWidth && (jQuery("#be_compare_features_table_inner").hasClass("scroll-right") || jQuery("#be_compare_features_table_inner").addClass("scroll-right")), jQuery(window).on("resize", function() {
          roar.be_compare_products_table_shadows()
      }), jQuery("#be_compare_features_table_inner").hasClass("scroll-left") || jQuery("#be_compare_features_table_inner").hasClass("scroll-right") ? $(".compareview").addClass("no-flex") : $(".compareview").removeClass("no-flex")
  },
  be_compare_products_table_shadows: function() {
      be_compare_container = document.getElementById("be_compare_features_table"), null !== be_compare_container && (be_compare_container.offsetWidth < be_compare_container.scrollWidth ? jQuery("#be_compare_features_table_inner").hasClass("scroll-right") || jQuery("#be_compare_features_table_inner").addClass("scroll-right") : (jQuery("#be_compare_features_table_inner").hasClass("scroll-right") && jQuery("#be_compare_features_table_inner").removeClass("scroll-right"), jQuery("#be_compare_features_table_inner").hasClass("scroll-left") && jQuery("#be_compare_features_table_inner").removeClass("scroll-left")), jQuery("#be_compare_features_table_inner").hasClass("scroll-left") || jQuery("#be_compare_features_table_inner").hasClass("scroll-right") ? $(".compareview").addClass("no-flex") : $(".compareview").removeClass("no-flex"))
  },
  removeToWishlist: function() {
      $(document).on("click", ".remove-wishlist", function(t) {
          t.preventDefault();
          var e = $(this),
              i = {
                  action: "remove_wishlist"
              };
          return i = e.closest("form").serialize() + "&" + $.param(i), $.ajax({
              type: "POST",
              url: "/a/wishlist",
              async: !0,
              cache: !1,
              data: i,
              dataType: "json",
              beforeSend: function() {
                  $(".page-wishlist").addClass("is_loading")
              },
              error: function(t) {
                  console.log(t), $(".page-wishlist").removeClass("is_loading")
              },
              success: function(t) {
                  1 == t.code ? e.closest(".item").slideUp("fast", function() {
                      e.closest(".item").remove(), $(".page-wishlist .infos").removeClass("hide"), $(".wishlist_items_number").text(t.json), 0 == t.json && $(".wishlist-empty").removeClass("hide")
                  }) : (alert(t.json), console.log(t.json)), $(".page-wishlist").removeClass("is_loading")
              }
          }), !1
      })
  },
  addToWishlist: function() {
      $(document).on("click", ".add-to-wishlist:not(.added)", function(t) {
          if ($(this).hasClass("need-login")) {
              var e = $("#wishlist_error").html();
              return $.notify({
                  message: e,
                  target: "_blank"
              }, {
                  type: "info",
                  showProgressbar: !0,
                  z_index: 2031,
                  mouse_over: "pause",
                  placement: {
                      from: "top",
                      align: window.rtl ? "left" : "right"
                  }
              }), !1
          }
          var a = $(this),
              n = {
                  action: "add_wishlist"
              };
          return n = a.closest("form").serialize() + "&" + $.param(n), $.ajax({
              type: "POST",
              url: "/a/wishlist",
              async: !0,
              cache: !1,
              data: n,
              dataType: "json",
              beforeSend: function() {
                  a.hasClass("btooltip") ? a.addClass("loading") : a.attr("title", a.attr("data-loading-text")).find("span").text(a.attr("data-loading-text"))
              },
              complete: function() {
                  a.hasClass("btooltip") && a.removeClass("loading"), $(".wishlist" + a.prev().val()).attr("title", a.attr("data-added")).addClass("added").find("span").text(a.attr("data-added"))
              },
              error: function(t) {
                  var e = i = $.parseJSON(t.responseText),
                      a = e.message + ": " + e.description;
                  $.notify({
                      message: a,
                      target: "_blank"
                  }, {
                      type: "info",
                      showProgressbar: !0,
                      z_index: 2031,
                      mouse_over: "pause",
                      placement: {
                          from: "top",
                          align: window.rtl ? "left" : "right"
                      }
                  })
              },
              success: function() {
                  var t = a.closest(".product"),
                      e = [{
                          product_url: t.find(".name a").attr("href"),
                          product_name: t.find(".name a").text()
                      }];
                  $.notify({
                      message: $("<div>").append($("#wishlist_success").tmpl(e).clone()).html(),
                      target: "_blank"
                  }, {
                      type: "success",
                      showProgressbar: !0,
                      z_index: 2031,
                      mouse_over: "pause",
                      placement: {
                          from: "top",
                          align: window.rtl ? "left" : "right"
                      }
                  })
              }
          }), !1
      })
  },
  addToCart: function() {
      "direct" != window.shopping_cart_type && $(document).on("click", ".add-to-cart:not(.disabled)", function() {
          var t = $(this),
              e = t.closest("form");
          return $.ajax({
              type: "POST",
              url: "/cart/add.js",
              async: !0,
              cache: !1,
              data: e.serialize(),
              dataType: "json",
              beforeSend: function() {
                  t.hasClass("btooltip") ? t.addClass("loading") : t.button("loading") && $("#filter-addtocart span").text(t.attr("data-loading-text")) && $("#filter-addtocart").addClass("active")
              },
              complete: function() {
                  t.hasClass("btooltip") ? t.removeClass("loading") : t.button("reset") && $("#filter-addtocart").removeClass("active")
              },
              error: function(t) {
                  roar.updateCart(t, !1)
              },
              success: function(t) {
                  "sidebar" == window.shopping_cart_type ? roar.updateCartSidebar(t, !0) : roar.updateCart(t, !0)
              }
          }).done(function() {}), !1
      })
  },
  cartSidebar: function() {
      "sidebar" == window.shopping_cart_type && ($("body").on("click", ".cart-item a.remove-cart", function(t) {
          t.preventDefault();
          var e = $(this),
              i = {
                  type: "POST",
                  url: "/cart/change.js",
                  data: "quantity=0&id=" + e.attr("data-id"),
                  dataType: "json",
                  beforeSend: function() {
                      $(".cart-window-body").addClass("loading")
                  },
                  success: function() {
                      $.ajax({
                          url: "/search",
                          beforeSend: function() {},
                          success: function(t) {
                              roar.updateCart(e, !0)
                          },
                          error: function(t) {
                              console.log(t)
                          }
                      }).done(function() {
                          $(".cart-window-body").removeClass("loading")
                      })
                  },
                  error: function(t, e) {
                      Shopify.onError(t, e), $(".cart-window-body").removeClass("loading")
                  }
              };
          $.ajax(i)
      }), $(document).on("focus", "#cart_info .update", function() {
          $(this).select()
      }).on("blur", "#cart_info .update", function() {
          var t = $(this),
              e = {
                  type: "POST",
                  url: "/cart/change.js",
                  data: "quantity=" + t.val() + "&id=" + t.attr("data-id"),
                  dataType: "json",
                  beforeSend: function() {
                      $(".cart-window-body").addClass("loading")
                  },
                  success: function() {
                      roar.updateCart(t, !0)
                  },
                  error: function(t, e) {
                      Shopify.onError(t, e)
                  }
              };
          $.ajax(e).done(function() {
              $(".cart-window-body").removeClass("loading")
          })
      }), $("body").on("click", ".cart-block-click", function(t) {
          t.target === this && (t.preventDefault(), $(".cart-window-bg").toggleClass("window-hide"))
      }), $("body").on("click", ".cart-block-click a.button", function(t) {
          t.preventDefault();
          var e = $(this).attr("href");
          window.location.href = window.location.origin + e
      }), $("body").on("click", ".close-cart", function(t) {
          t.preventDefault(), $(".cart-window-bg").addClass("window-hide")
      }), $("body").on("click", ".qty-btn.cart-plus", function(t) {
          var e = $(this).data("id"),
              i = parseInt($(e).val()) + 1;
          $(e).val(i);
          var a = $(e),
              n = {
                  type: "POST",
                  url: "/cart/change.js",
                  data: "quantity=" + a.val() + "&id=" + a.attr("data-id"),
                  dataType: "json",
                  beforeSend: function() {
                      $(".cart-window-body").addClass("loading")
                  },
                  success: function() {
                      roar.updateCart(a, !0)
                  },
                  error: function(t, e) {
                      Shopify.onError(t, e)
                  }
              };
          $.ajax(n).done(function() {
              $(".cart-window-body").removeClass("loading")
          })
      }), $("body").on("click", ".qty-btn.cart-minus", function(t) {
          var e = $(this).data("id"),
              i = parseInt($(e).val());
          if (1 < i) {
              $(e).val(i - 1);
              var a = $(e),
                  n = {
                      type: "POST",
                      url: "/cart/change.js",
                      data: "quantity=" + a.val() + "&id=" + a.attr("data-id"),
                      dataType: "json",
                      beforeSend: function() {
                          $(".cart-window-body").addClass("loading")
                      },
                      success: function() {
                          roar.updateCart(a, !0)
                      },
                      error: function(t, e) {
                          Shopify.onError(t, e)
                      }
                  };
              $.ajax(n).done(function() {
                  $(".cart-window-body").removeClass("loading")
              })
          }
      }))
  },
  updateCartSidebar: function(t, e) {
      $.ajax({
          url: "/search",
          beforeSend: function() {
              $(".cart-window-body").addClass("loading")
          },
          success: function(t) {
              var e = "div#cart_block",
                  i = "div#cart_popup",
                  a = ".mobile-nav-cart",
                  n = "#filter-cart",
                  o = "div#cart-sidebar";
              0 < $(o).length && ($(o).html($(t).find(o).html()), setTimeout(function() {
                  $(".cart-block-click").trigger("click")
              }, 100)), $(e).html($(t).find(e).html()), $(i).html($(t).find(i).html()), $(a).html($(t).find(a).html()), $(n).html($(t).find(n).html()), window.show_multiple_currencies && (theme.CurrencyPicker.convert("#cart_block .money"), theme.CurrencyPicker.convert("#cart_popup .money"), theme.CurrencyPicker.convert("#cart-sidebar .money")), roar.handleReviews()
          },
          error: function(t) {
              console.log(t)
          }
      }).done(function() {
          $(".cart-window-body").removeClass("loading")
      })
  },
  updateCart: function(a, n) {
      if (1 == n) "sidebar" == window.shopping_cart_type ? $.ajax({
          url: "/search",
          beforeSend: function() {
              $(".cart-window-body").addClass("loading")
          },
          success: function(t) {
              var e = "div#cart_block",
                  i = "div#cart_popup",
                  a = ".mobile-nav-cart",
                  n = "#filter-cart",
                  o = "#cart-sidebar";
              0 < $(o).length && $(o).html($(t).find(o).html()), $(e).html($(t).find(e).html()), $(i).html($(t).find(i).html()), $(a).html($(t).find(a).html()), $(n).html($(t).find(n).html()), window.show_multiple_currencies && (theme.CurrencyPicker.convert("#cart_block .money"), theme.CurrencyPicker.convert("#cart_popup .money"), theme.CurrencyPicker.convert("#cart-sidebar .money")), roar.handleReviews()
          },
          error: function(t) {
              console.log(t)
          }
      }).done(function() {
          $(".cart-window-body").removeClass("loading")
      }) : $.ajax({
          url: "/search?view=cart&q=" + a.handle + "_sp_" + a.variant_id + "_sp_" + a.quantity + "_sp_" + a.price,
          beforeSend: function() {},
          success: function(t) {
              var e = "div#cart_block",
                  i = "div#cart_popup",
                  a = ".mobile-nav-cart",
                  n = "#filter-cart";
              $(e).html($(t).filter(e).html()), $(i).html($(t).filter(i).html()), $(a).html($(t).filter(a).html()), $(n).html($(t).filter(n).html()), window.show_multiple_currencies && (theme.CurrencyPicker.convert("#cart_popup .money"), theme.CurrencyPicker.convert("#cart_block .money"))
          },
          error: function(t) {
              console.log(t)
          }
      }).done(function() {
          if ("ajax_notify" == window.shopping_cart_type) {
              var t = [{
                  product_url: a.url,
                  product_name: a.title
              }];
              $.notify({
                  message: $("<div>").append($("#cart_success").tmpl(t).clone()).html(),
                  target: "_blank"
              }, {
                  type: "success",
                  showProgressbar: !0,
                  z_index: 2031,
                  mouse_over: "pause",
                  placement: {
                      from: "top",
                      align: window.rtl ? "left" : "right"
                  }
              })
          } else roar.popupCart(n)
      });
      else {
          var t = $.parseJSON(a.responseText);
          $.ajax({
              url: "/search?view=cart_error&q=" + t.description,
              beforeSend: function() {},
              success: function(t) {
                  var e = "div#cart_error_popup";
                  $(e).html($(t).filter(e).html())
              },
              error: function(t) {
                  console.log(t)
              }
          }).done(function() {
              if ("ajax_notify" == window.shopping_cart_type) {
                  var t = i = $.parseJSON(a.responseText),
                      e = t.message + ": " + t.description;
                  $.notify({
                      message: e,
                      target: "_blank"
                  }, {
                      type: "info",
                      showProgressbar: !0,
                      z_index: 2031,
                      mouse_over: "pause",
                      placement: {
                          from: "top",
                          align: window.rtl ? "left" : "right"
                      }
                  })
              } else roar.popupCart(n)
          })
      }
  },
  removeCart: function() {
      $(document).on("click", ".mini-cart-info .remove a", function(t) {
          t.preventDefault();
          var e = {
              type: "POST",
              url: "/cart/change.js",
              data: "quantity=0&id=" + $(this).attr("data-id"),
              dataType: "json",
              beforeSend: function() {
                  $("#cart_content").addClass("loading")
              },
              success: function() {
                  $.ajax({
                      url: "/search?view=cart",
                      beforeSend: function() {},
                      success: function(t) {
                          var e = "div#cart_block",
                              i = "div#cart_popup",
                              a = ".mobile-nav-cart",
                              n = "#filter-cart";
                          $(e).html($(t).filter(e).html()), $(i).html($(t).filter(i).html()), $(a).html($(t).filter(a).html()), $(n).html($(t).filter(n).html()), window.show_multiple_currencies && (theme.CurrencyPicker.convert("#cart_popup .money"), theme.CurrencyPicker.convert("#cart_block .money"))
                      },
                      error: function(t) {
                          console.log(t)
                      }
                  }).done(function() {
                      $("#cart_content").removeClass("loading")
                  })
              },
              error: function(t, e) {
                  Shopify.onError(t, e), $("#cart_content").removeClass("loading")
              }
          };
          $.ajax(e)
      })
  },
  popupCart: function(t) {
      1 == t ? $.magnificPopup.open({
          items: {
              src: "#cart_popup",
              type: "inline"
          },
          tLoading: "",
          mainClass: "popup-module mfp-with-zoom popup-type-1",
          removalDelay: 200,
          callbacks: {
              open: function() {
                  $("#cart_popup .continue-shopping").unbind("click"), $("body").on("click", "#cart_popup .continue-shopping", function(t) {
                      t.preventDefault(), $.magnificPopup.close()
                  })
              }
          }
      }) : $.magnificPopup.open({
          items: {
              src: "#cart_error_popup",
              type: "inline"
          },
          tLoading: "",
          mainClass: "popup-module mfp-with-zoom popup-type-1",
          removalDelay: 200
      })
  },
  handlePopups: function() {
      function t() {
          if (0 == window.popup_mailchimp_expire ? $("#popup-mailchimp .dont-show-me").change(function() {
                  $(this).is(":checked") ? n() : o()
              }) : 1 == window.popup_mailchimp_expire && o(), ! function() {
                  try {
                      var t = "popup-module-mailchimp";
                      if (0 < document.cookie.length) {
                          var e = document.cookie.indexOf(t + "=");
                          if (-1 != e) {
                              e = e + t.length + 1;
                              var i = document.cookie.indexOf(";", e);
                              return -1 == i && (i = document.cookie.length), unescape(document.cookie.substring(e, i))
                          }
                      }
                  } catch (t) {
                      console.log(t.message)
                  }
              }()) {
              var t = parseInt(window.popup_mailchimp_delay, 20),
                  e = parseInt(window.popup_mailchimp_close, 20);
              setTimeout(function() {
                  $.magnificPopup.open({
                      items: {
                          src: "#popup-mailchimp",
                          type: "inline"
                      },
                      tLoading: "",
                      mainClass: "popup-module mfp-with-zoom popup-type-1",
                      removalDelay: 200
                  }), 0 < e && setTimeout(function() {
                      $.magnificPopup.close()
                  }, e)
              }, t), 2 == window.popup_mailchimp_expire && n()
          }
          var i = $("#mc-form"),
              a = i.attr("action");
          i.ajaxChimp({
              url: a,
              callback: function(t) {}
          })
      }

      function n() {
          try {
              var t = parseInt(window.popup_mailchimp_period);
              t <= 0 && (t = 1);
              var e = "domain=." + document.domain,
                  i = new Date;
              i.setTime(i.getTime() + 24 * t * 60 * 60 * 1e3);
              var a = "; expires=" + i.toGMTString();
              document.cookie = "popup-module-mailchimp=true" + a + "; path=/; " + e
          } catch (e) {
              console.log(e.message)
          }
      }

      function o() {
          try {
              var t = "domain=." + document.domain;
              document.cookie = "popup-module-mailchimp=; expires=Thu, 01 Jan 1970 00:00:00 GMT; path=/; " + t
          } catch (t) {
              console.log(t.message)
          }
      }
      $("#popup-mailchimp").length && ($("#popup-mailchimp").hasClass("hidden-xs") ? 768 <= roar.getWidthBrowser() && t() : t())
  },
  handleVerticalMenu: function() {
      $(".category_trigger").click(function() {
          (roar.getWidthBrowser() < 768 || $("html").hasClass("touch")) && ($(".shop_category").hasClass("is_open") ? ($(".shop_category").removeClass("is_open"), $(".shop_category .submenu-group").slideUp()) : ($(".shop_category").addClass("is_open"), $(".shop_category .submenu-group").slideDown()))
      }), $(".shop_category .has-children>span>.fa").click(function() {
          var t = $(this).closest(".menu-item"),
              e = t.find(".submenu");
          (roar.getWidthBrowser() < 768 || $("html").hasClass("touch")) && (t.hasClass("is_open") ? (t.removeClass("is_open"), e.slideUp()) : (t.addClass("is_open"), e.slideDown()))
      })
  },
  updateGroupedPrice: function() {
      if (0 != $("#grouped-price").length) {
          var t = 0;
          $(".grouped-product-item .grouped-checkbox").each(function() {
              $(this).is(":checked") && (t += parseFloat($($(this).data("id")).find("div.price").data("price")), $("#grouped-price").html('<span class="money">' + theme.Currency.formatMoney(t, theme.settings.moneyFormat) + "</span>"), window.show_multiple_currencies && theme.CurrencyPicker.convert("#grouped-price .money"))
          })
      }
  },
  handleQuickshop: function(t) {
      t = t || "body";
      var e = "";
      return $(t).find(".quickview .quick_view").magnificPopup({
          type: "ajax",
          preloader: !0,
          tLoading: "",
          mainClass: "quickview",
          removalDelay: 200,
          gallery: {
              enabled: !1
          },
          callbacks: {
              open: function() {
                  0 < $("#main").next(".product-360-view-wrapper").length && $("#main").next(".product-360-view-wrapper").remove()
              },
              ajaxContentAdded: function() {
                  roar.handleReviews(), (new theme.Sections).register("product-quickview-template", theme.Product), roar.initCountdown(), window.show_multiple_currencies && theme.CurrencyPicker.convert("#ProductSection-product-quickview-template .money"), Shopify.PaymentButton.init();
                  var t = $(".quickview").find(".add-to-wishlist");
                  t.attr("title", t.attr("data-added")).addClass("added").find("span").text(t.attr("data-added")), setTimeout(function() {
                      $(window).trigger("resize")
                  }, 1e3)
              },
              beforeClose: function() {
                  0 < $(".quickview._reopen").length && "" != $(".quickview._reopen").data("_qid") && (e = $(".quickview._reopen").data("_qid"))
              },
              afterClose: function() {
                  "" != e && ($(e).trigger("click"), e = "")
              }
          }
      }), !1
  },
  mapClearFilter: function() {
      $(".mfilter-box .column").each(function() {
          var e = $(this);
          0 < e.find("input:checked").length && e.find(".clear").on("click", function(t) {
              var i = [];
              Shopify.queryParams.constraint && (i = Shopify.queryParams.constraint.split("+")), e.find("input:checked").each(function() {
                  var t = $(this).val();
                  if (t) {
                      var e = i.indexOf(t);
                      0 <= e && i.splice(e, 1)
                  }
              }), i.length ? Shopify.queryParams.constraint = i.join("+") : delete Shopify.queryParams.constraint, roar.filterAjaxClick(), t.preventDefault()
          })
      })
  },
  mapSingleFilter: function() {
      $("body").on("change", ".advanced-filter .field:not(.disable) input", function() {
          var t = $(this).parent(),
              e = $(this).val(),
              i = [];
          if (Shopify.queryParams.constraint && (i = Shopify.queryParams.constraint.split("+")), !window.enable_filter_multiple_choice && !t.hasClass("active")) {
              var a = t.parents(".advanced-filter").find(".active");
              0 < a.length && a.each(function() {
                  var t = $(this).data("handle");
                  if ($(this).removeClass("active"), t) {
                      var e = i.indexOf(t);
                      0 <= e && i.splice(e, 1)
                  }
              })
          }
          if (e) {
              var n = i.indexOf(e);
              n < 0 ? (i.push(e), t.addClass("active")) : (i.splice(n, 1), t.removeClass("active"))
          }
          i.length ? Shopify.queryParams.constraint = i.join("+") : delete Shopify.queryParams.constraint, roar.filterAjaxClick()
      })
  },
  mapSingleCollection: function() {
      $("body").on("click", ".advanced-collection .field", function(t) {
          var e = $(this),
              i = e.attr("href");
          e.hasClass("active") || (roar.filterAjaxClick(i), $(".advanced-collection .field").removeClass("active"), e.addClass("active"), t.preventDefault())
      })
  },
  mapSingleSort: function() {
      $("body").on("change", ".advanced-sortby .field", function(t) {
          var e = $(this).val();
          Shopify.queryParams.sort_by = e, roar.filterAjaxClick(), t.preventDefault()
      })
  },
  mapSingleLimit: function() {
      $("body").on("change", ".advanced-limit .field", function(t) {
          var e = $(this).val();
          Shopify.queryParams.view = e, roar.filterAjaxClick(), t.preventDefault()
      })
  },
  mapSinglePagination: function() {
      $("body").on("click", "#mfilter-content-container .advanced-pagination a", function(t) {
          var e = $(this);
          delete Shopify.queryParams.page, delete Shopify.queryParams.constraint, delete Shopify.queryParams.q, delete Shopify.queryParams.sort_by, roar.filterAjaxClickPaging(e.attr("href")), t.preventDefault()
      })
  },
  mapFilters: function() {
      roar.handleGridList(), roar.mapPagination()
  },
  mapPaginationCallback: function() {
      roar.handleGridList(), roar.handleQuickshop(), roar.handleReviews(), roar.initCountdown(), roar.initProductQuickShopItem("#mfilter-content-container"), roar.initLazyLoading("#sandbox", !0), window.show_multiple_currencies && theme.CurrencyPicker.convert("#sandbox .money")
  },
  mapPagination: function() {
      if ($(document.body).on("click", ".fastor_ajax_load_button a", function(t) {
              if (t.preventDefault(), $(".pagination a.next").length) {
                  $(".fastor_ajax_load_button a").attr("data-processing", 1);
                  var e = $(".pagination a.next").attr("href"),
                      i = $(".fastor_ajax_load_button a").attr("data-loading-items"),
                      a = $(".fastor_ajax_load_button a").attr("data-no-more");
                  $(".fastor_ajax_load_button").hide(), $(".pagination").before('<div class="fastor_ajax_load_more_loader animated fadeIn"><a href="#"><i class="icon-px-outline-load"></i>&nbsp;&nbsp;<span>' + i + "</span></a></div>"), $.get(e, function(t) {
                      $(".advanced-pagination").html($(t).find(".advanced-pagination").html()), $(t).find(".product-list .product").each(function() {
                          $(".product-list .product:last").after($(this))
                      }), $(t).find(".product-grid .product-item").each(function() {
                          $(".product-grid .product-item:last").after($(this))
                      }), roar.mapPaginationCallback(), $(".fastor_ajax_load_more_loader").fadeOut("slow"), $(".fastor_ajax_load_button").fadeIn("slow"), $(".fastor_ajax_load_button a").attr("data-processing", 0), 0 == $(".pagination a.next").length && ($(".fastor_ajax_load_button").addClass("finished").removeClass("fastor_ajax_load_more_hidden"), $(".fastor_ajax_load_button a").show().html(a).addClass("disabled"))
                  })
              } else {
                  a = $(".fastor_ajax_load_button a").attr("data-no-more");
                  $(".fastor_ajax_load_button").addClass("finished").removeClass("fastor_ajax_load_more_hidden"), $(".fastor_ajax_load_button a").show().html(a).addClass("disabled")
              }
          }), $(".fastor_ajax_load_button").hasClass("fastor_ajax_load_more_hidden")) {
          var t = Math.abs(0);
          $(window).scroll(function() {
              $(".products").length && $(".products").offset().top + $(".products").outerHeight() - $(window).scrollTop() - t < $(window).height() && 0 == $(".fastor_ajax_load_button a").attr("data-processing") && $(".fastor_ajax_load_button a").trigger("click")
          })
      }
  },
  filterCreateUrl: function(t) {
      var e = $.param(Shopify.queryParams).replace(/%2B/g, "+");
      return t ? "" != e ? t + "?" + e : t : location.pathname + "?" + e
  },
  updateQueryStringParameter: function(t, e, i) {
      var a = new RegExp("([?&])" + e + "=.*?(&|$)", "i"),
          n = -1 !== t.indexOf("?") ? "&" : "?";
      return t.match(a) ? t.replace(a, "$1" + e + "=" + i + "$2") : t + n + e + "=" + i
  },
  filterCreateUrlPaging: function(t) {
      var e = 1,
          i = t.split("page=");
      return 1 < i.length && (e = parseInt(i[1])), roar.updateQueryStringParameter(window.location.href, "page", e)
  },
  filterAjaxClick: function(t) {
      delete Shopify.queryParams.page;
      var e = roar.filterCreateUrl(t);
      roar.filterGetContent(e)
  },
  filterAjaxClickPaging: function(t) {
      delete Shopify.queryParams.page;
      var e = roar.filterCreateUrlPaging(t);
      roar.filterGetContent(e)
  },
  filterGetContent: function(i) {
      $.ajax({
          type: "get",
          url: i,
          beforeSend: function() {
              roar.destroyCountdown(), $("body").addClass("is_loading").removeClass("open_filter")
          },
          success: function(t) {
              var e = t.match("<title>(.*?)</title>")[1];
              $(t).find(".breadcrumb-content").length && $(".breadcrumb-content").html($(t).find(".breadcrumb-content").html()), $(".category-info").remove(), $(t).find(".category-info").length && $("#mfilter-content-container").prepend($(t).find(".category-info")), $("#sandbox").empty().html($(t).find("#sandbox").html()), $(".mfilter-box .mfilter-content").empty().html($(t).find(".mfilter-box .mfilter-content").html()), $("#mfilter-content-container .advanced-pagination").empty().html($(t).find("#mfilter-content-container .advanced-pagination").html()), $(".page-top").empty().html($(t).find(".page-top").html()), History.pushState({
                  param: Shopify.queryParams
              }, e, i), setTimeout(function() {
                  $("html,body").animate({
                      scrollTop: $("body #sandbox").offset().top
                  }, 500, "swing")
              }, 100), $("body").removeClass("is_loading"), roar.mapClearFilter(), roar.handleQuickshop(), roar.handleReviews(), roar.initCountdown(), roar.initProductQuickShopItem("#mfilter-content-container"), roar.initFilterSidebar(), roar.initLazyLoading("#sandbox", !0), window.show_multiple_currencies && theme.CurrencyPicker.convert("#sandbox .money")
          },
          error: function() {
              $("body").removeClass("is_loading")
          }
      })
  },
  handleReviews: function() {
      "1" == window.reviews_enable ? "undefined" != typeof SPR && (SPR.registerCallbacks(), SPR.initRatingHandler(), SPR.initDomEls(), SPR.loadProducts(), SPR.loadBadges()) : "2" == window.reviews_enable && $.aliReviewsAddRatingCollection()
  },
  convertToSlug: function(t) {
      return t.toLowerCase().replace(/[^\w\u00C0-\u024f]+/g, "-").replace(/^-+|-+$/g, "")
  },
  getWidthBrowser: function() {
      var t;
      return "number" == typeof window.innerWidth ? t = window.innerWidth : document.documentElement && (document.documentElement.clientWidth || document.documentElement.clientHeight) ? t = document.documentElement.clientWidth : document.body && (document.body.clientWidth || document.body.clientHeight) && (t = document.body.clientWidth), t
  },
  handleScrollToTop: function() {
      $(window).scroll(function() {
          if (767 < $(window).width()) {
              var t = $(this).scrollTop(),
                  e = $(this).height(),
                  i = 1;
              0 < t && (i = t + e / 2);
              var a = $("#scroll-top");
              i < 1e3 ? a.removeClass("on") : a.addClass("on")
          } else {
              t = $(this).scrollTop();
              if (0 < $("#shopify-section-mobile-nav").length) e = $("#shopify-section-mobile-nav").offset().top + $("#shopify-section-mobile-nav").height();
              else e = $("header").offset().top + $("header").height();
              a = $("#widgets");
              t < e ? a.removeClass("on") : a.addClass("on")
          }
      }), $("#scroll-top").click(function(t) {
          t.preventDefault(), $("html,body").animate({
              scrollTop: 0
          }, 800, "swing")
      })
  },
  handleGMap: function() {
      $("#contact_map").length && $().gMap && $("#contact_map").gMap({
          zoom: 17,
          scrollwheel: !1,
          maptype: "ROADMAP",
          markers: [{
              address: window.contact_map_address,
              html: "_address",
              icon: {
                  iconsize: [188, 68],
                  iconanchor: [0, 68]
              }
          }]
      })
  },
  handleGridList: function() {
      $(document).on("click", "#grid", function() {
          $("#mfilter-content-container").removeClass("list").addClass("grid")
      }), $(document).on("click", "#list", function() {
          $("#mfilter-content-container").removeClass("grid").addClass("list"), $("body").removeClass("flex-view-2 flex-view-3 flex-view-4 flex-view-6").addClass("flex-view-1")
      })
  },
  handleSearch: function() {
      $(".button-search, .header-type-3 #top .search_form, .header-type-8 .search_form").bind("click", function() {
          $(this).closest("form").submit()
      })
  },
  handleSmoothScroll: function() {
      $(document).on("click", ".smoothscroll", function(t) {
          t.preventDefault();
          var e = $(this).attr("href");
          $(e).trigger("click"), setTimeout(function() {
              $("html,body").animate({
                  scrollTop: $(e).offset().top - 100
              }, 800, "swing")
          }, 300)
      })
  },
  handleOrder: function() {
      $(".orderable").each(function(t, e) {
          var i = $(e).children("div[data-order]");
          i.sort(function(t, e) {
              return $(t).data("order") - $(e).data("order")
          }), i.appendTo(e)
      })
  },
  handleDropdown: function() {
      $("[data-toggle='dropdown']").on("click", function() {
          $(this).parent().toggleClass("open")
      })
  }
};

function onFullWidthOption(t) {
  _force_full_width(t), $(window).resize(function() {
      _force_full_width(t)
  })
}

function _force_full_width(t) {
  var e = $(".standard-body .full-width #shopify-section-" + t);
  if (window.rtl) {
      if (0 < e.size()) {
          e.width($("body").width()), e.css("right", "0px");
          i = e.offset();
          e.css("right", "-" + -1 * i.left + "px"), e.find(".container").css("padding-left", -1 * i.left), e.find(".container").css("padding-right", -1 * i.left)
      }
  } else if (0 < e.size()) {
      e.width($("body").width()), e.css("left", "0px");
      var i = e.offset();
      e.css("left", "-" + i.left + "px"), e.find(".container").css("padding-left", i.left), e.find(".container").css("padding-right", i.left)
  }
  var a = $(".standard-body .fixed #shopify-section-" + t);
  if (window.rtl) {
      if (0 < a.size()) {
          a.width($(".standard-body").width()), a.css("right", "0px");
          i = a.offset(), n = $(".standard-body").offset(), o = i.left - n.left;
          a.css("right", "-" + -1 * o + "px"), a.find(".container").css("padding-left", -1 * o), a.find(".container").css("padding-right", -1 * o)
      }
  } else if (0 < a.size()) {
      a.width($(".standard-body").width()), a.css("left", "0px");
      var i = a.offset(),
          n = $(".standard-body").offset(),
          o = i.left - n.left;
      a.css("left", "-" + o + "px"), a.find(".container").css("padding-left", o), a.find(".container").css("padding-right", o)
  }
  var s = $(".standard-body .fixed2 #shopify-section-" + t);
  if (0 < s.size()) {
      s.width($("body").width()), s.css("left", "0px");
      i = s.offset();
      s.css("left", "-" + i.left + "px"), s.find(".container").css("padding-left", i.left), s.find(".container").css("padding-right", i.left)
  }
  var r = $(".fixed-body #shopify-section-" + t);
  if (window.rtl) {
      if (0 < r.size()) {
          r.width($(".fixed-body .main-fixed").width()), r.css("right", "0px");
          i = r.offset(), n = $(".fixed-body .main-fixed").offset(), o = i.left - n.left;
          r.css("right", "-" + -1 * o + "px"), r.find(".container").css("padding-left", -1 * o), r.find(".container").css("padding-right", -1 * o)
      }
  } else if (0 < r.size()) {
      r.width($(".fixed-body .main-fixed").width()), r.css("left", "0px");
      i = r.offset();
      var n = $(".fixed-body .main-fixed").offset(),
          o = i.left - n.left;
      r.css("left", "-" + o + "px"), r.find(".container").css("padding-left", o), r.find(".container").css("padding-right", o)
  }
}
theme.CurrencyPicker = function() {
  var n = {
          selector: ".money",
          container: ".currency__picker",
          currency: ".currency__picker .currency__switcher",
          currencyPicker: ".currency__picker .currency",
          currencyActive: ".currency__picker .currency.active",
          currencyCurrent: ".currency__picker .currency__current",
          currencyNotification: ".currency__notification"
      },
      o = {
          currency_format: "",
          shop_currency: "",
          default_currency: "",
          money_with_currency_format: "",
          money_format: "",
          auto_switch: "true",
          original_price: "true"
      };

  function s() {
      if ("false" == o.original_price) return !1;
      var i = Currency.currentCurrency,
          t = Currency.cookie.read(),
          a = o.shop_currency;
      t && (i = t), $(n.selector).each(function() {
          var t = $(this);
          if (t.removeAttr("data-currency-default"), a != i) {
              var e = t.attr("data-currency-" + a);
              "USD" == a && (e += " USD"), t.attr("data-currency-default", e)
          }
      })
  }

  function r() {
      $(n.currencyNotification).length && (Currency.currentCurrency != o.shop_currency ? $(n.currencyNotification).each(function() {
          var t = $(this),
              e = t.data("html"),
              i = "<strong>" + Currency.currentCurrency + "</strong>";
          e = e.replace(new RegExp("{{ current_currency }}", "g"), i), t.html(e), t.hasClass("loaded") || t.addClass("loaded").slideDown()
      }) : $(n.currencyNotification).removeClass("loaded").slideUp())
  }

  function t() {
      var t = $(n.container);
      o.currency_format = t.find(".currency_format").val(), o.shop_currency = t.find(".shop_currency").val(), o.default_currency = t.find(".default_currency").val(), o.money_with_currency_format = t.find(".money_with_currency_format").val(), o.money_format = t.find(".money_format").val(), o.auto_switch = t.find(".auto_switch").val(), o.original_price = t.find(".original_price").val(), Currency.format = o.currency_format;
      var e = o.shop_currency;
      Currency.moneyFormats[e].money_with_currency_format = o.money_with_currency_format, Currency.moneyFormats[e].money_format = o.money_format;
      var i = o.default_currency,
          a = Currency.cookie.read();
      $(".money .money").each(function() {
          $(this).parents(".money").removeClass("money")
      }), $(n.selector).each(function() {
          var t = $(this);
          if (void 0 === t.attr("data-currency-" + o.shop_currency)) {
              var e = t.text();
              t.attr("data-currency-" + o.shop_currency, e)
          }
      }), null == a ? e !== i ? Currency.convertAll(e, i, n.selector) : Currency.currentCurrency = i : $(n.currency).length && 0 === $(n.currency + " .currency[data-code=" + a + "]").size() ? (Currency.currentCurrency = e, Currency.cookie.write(e)) : a === e ? Currency.currentCurrency = e : Currency.convertAll(e, a, n.selector), $(n.currency).on("click", ".currency:not(.active)", function() {
          var t = $(this).data("code");
          Currency.convertAll(Currency.currentCurrency, t, n.selector), $(n.currencyPicker).removeClass("active"), $(this).addClass("active"), $(n.currencyCurrent).text(Currency.currentCurrency).attr("data-code", Currency.currentCurrency), s(), r()
      });
      window.selectCallback;
      $(n.currencyPicker).removeClass("active"), $(n.currency + " .currency[data-code=" + Currency.currentCurrency + "]").addClass("active"), $(n.currencyCurrent).text(Currency.currentCurrency).attr("data-code", Currency.currentCurrency), s(),
          function() {
              if ("false" == o.auto_switch) return;
              null == Currency.cookie.read() && $.getJSON("//ipinfo.io/json", function(t) {
                  var e = JSON.parse(JSON.stringify(t, null, 2));
                  void 0 !== e.country && $.getJSON("//restcountries.eu/rest/v1/alpha/" + e.country, function(t) {
                      var e = t.currencies[0];
                      $(n.currencyPicker + '[data-code="' + e + '"]').trigger("click")
                  })
              })
          }(), r()
  }
  return {
      init: function() {
          $(n.currency).length && ($(n.currency).hasClass("ml__js") ? t() : ($(n.currency).off("click", ".currency:not(.active)"), $(n.currency).on("click", ".currency:not(.active)", function() {
              var t = $(this).data("code"),
                  e = window.location,
                  i = e.pathname + e.search + e.hash,
                  a = document.createElement("form");
              a.setAttribute("action", "/cart/update"), a.setAttribute("method", "POST"), a.setAttribute("style", "display:none");
              var n = document.createElement("input");
              n.setAttribute("type", "hidden"), n.setAttribute("name", "form_type"), n.setAttribute("value", "currency");
              var o = document.createElement("input");
              o.setAttribute("type", "hidden"), o.setAttribute("name", "currency"), o.setAttribute("value", t);
              var s = document.createElement("input");
              s.setAttribute("type", "hidden"), s.setAttribute("name", "return_to"), s.setAttribute("value", i), a.appendChild(n), a.appendChild(o), a.appendChild(s), $(a).appendTo("body").submit()
          })))
      },
      convert: function(t) {
          $(n.currency).length && ($(t).each(function() {
              var t = $(this);
              if (void 0 === t.attr("data-currency-" + o.shop_currency)) {
                  var e = t.text();
                  t.attr("data-currency-" + o.shop_currency, e)
              }
          }), Currency.convertAll(o.shop_currency, $(n.currencyActive).attr("data-code"), t, o.currency_format), s())
      },
      convertAll: function() {
          $(n.currency).length && ($(n.selector).each(function() {
              var t = $(this);
              if (void 0 === t.attr("data-currency-" + o.shop_currency)) {
                  var e = t.text();
                  t.attr("data-currency-" + o.shop_currency, e)
              }
          }), Currency.convertAll(o.shop_currency, $(n.currencyActive).attr("data-code"), n.selector), s())
      }
  }
}(), theme.LanguagePicker = function() {
  var r = {
      language: ".language__picker .language__switcher",
      languagePicker: ".language__picker .language",
      languageCurrent: ".language__picker .language__current",
      selector: "#weketing_google_translate_element"
  };

  function c(t) {
      $(r.selector + " .goog-te-combo").val(t);
      var e, i = document.getElementsByClassName("goog-te-combo")[0];
      document.createEvent ? ((e = document.createEvent("HTMLEvents")).initEvent("change", !0, !0), i.dispatchEvent(e)) : ((e = document.createEventObject()).eventType = "change", i.fireEvent("on" + e.eventType, e))
  }
  return {
      init: function() {
          $(r.language).length && $(r.selector).length && ($(r.selector).bind("google_translate", function() {
              var t = weketingJS.settingsJS[8];
              if ("yes" == t.enable) {
                  for (var e = t.default_language, i = t.custom_languages, a = weketingSGT.languages(), n = localStorage.getItem("roarStorage_language"), o = 0; o < i.length - 1; o++)
                      if (i[o] == e) {
                          i.pop();
                          break
                      } for (o = 0; o < i.length; o++)
                      if (i[o] == n) {
                          e = n;
                          break
                      } for (o = 0; o < i.length; o++) {
                      var s = '<li class="language active notranslate" data-code="' + e + '">' + a[e] + "</li>";
                      i[o] != e && (s = '<li class="language notranslate" data-code="' + i[o] + '">' + a[i[o]] + "</li>"), $(r.language).append(s)
                  }
                  $(r.languageCurrent).text(a[e]), c(e)
              }
          }), $("body").on("click", r.languagePicker + ":not(.active)", function() {
              var t = $(this).data("code");
              if ("" != t) {
                  var e = $(this).text();
                  $(r.languagePicker).removeClass("active"), $(r.languagePicker + '[data-code="' + t + '"]').addClass("active"), $(r.languageCurrent).text(e), localStorage.setItem("roarStorage_language", t), c(t)
              }
          }), 0 < $(".dropdown.language-switcher").length && $(".dropdown.language-switcher").hover(function() {
              0 < $(".dropdown.language-switcher select").length && $(".dropdown.language-switcher select").attr("size", "4")
          }))
      }
  }
}(), window.theme = window.theme || {}, theme.Sections = function() {
  this.constructors = {}, this.instances = [], $(document).on("shopify:section:load", this._onSectionLoad.bind(this)).on("shopify:section:unload", this._onSectionUnload.bind(this)).on("shopify:section:select", this._onSelect.bind(this)).on("shopify:section:deselect", this._onDeselect.bind(this)).on("shopify:block:select", this._onBlockSelect.bind(this)).on("shopify:block:deselect", this._onBlockDeselect.bind(this))
}, theme.Sections.prototype = _.assignIn({}, theme.Sections.prototype, {
  _createInstance: function(t, e) {
      var i = $(t),
          a = i.attr("data-section-id"),
          n = i.attr("data-section-type");
      if (e = e || this.constructors[n], !_.isUndefined(e)) {
          var o = _.assignIn(new e(t), {
              id: a,
              type: n,
              container: t
          });
          this.instances.push(o)
      }
  },
  _onSectionLoad: function(t) {
      var e = $("[data-section-id]", t.target)[0];
      e && this._createInstance(e), roar.initLazyLoading()
  },
  _onSectionUnload: function(i) {
      this.instances = _.filter(this.instances, function(t) {
          var e = t.id === i.originalEvent.detail.sectionId;
          return e && _.isFunction(t.onUnload) && t.onUnload(i), !e
      })
  },
  _onSelect: function(e) {
      var t = _.find(this.instances, function(t) {
          return t.id === e.originalEvent.detail.sectionId
      });
      !_.isUndefined(t) && _.isFunction(t.onSelect) && t.onSelect(e)
  },
  _onDeselect: function(e) {
      var t = _.find(this.instances, function(t) {
          return t.id === e.originalEvent.detail.sectionId
      });
      !_.isUndefined(t) && _.isFunction(t.onDeselect) && t.onDeselect(e)
  },
  _onBlockSelect: function(e) {
      var t = _.find(this.instances, function(t) {
          return t.id === e.originalEvent.detail.sectionId
      });
      !_.isUndefined(t) && _.isFunction(t.onBlockSelect) && t.onBlockSelect(e)
  },
  _onBlockDeselect: function(e) {
      var t = _.find(this.instances, function(t) {
          return t.id === e.originalEvent.detail.sectionId
      });
      !_.isUndefined(t) && _.isFunction(t.onBlockDeselect) && t.onBlockDeselect(e)
  },
  register: function(t, i) {
      this.constructors[t] = i, $("[data-section-type=" + t + "]").each(function(t, e) {
          this._createInstance(e, i)
      }.bind(this))
  }
}), window.slate = window.slate || {}, theme.Images = {
  preload: function(t, e) {
      "string" == typeof t && (t = [t]);
      for (var i = 0; i < t.length; i++) {
          var a = t[i];
          this.loadImage(this.getSizedImageUrl(a, e))
      }
  },
  loadImage: function(t) {
      (new Image).src = t
  },
  switchImage: function(t, e, i) {
      var a = this.imageSize(e.src),
          n = this.getSizedImageUrl(t.src, a);
      i ? i(n, t, e) : e.src = n
  },
  imageSize: function(t) {
      var e = t.match(/.+_((?:pico|icon|thumb|small|compact|medium|large|grande)|\d{1,4}x\d{0,4}|x\d{1,4})[_\.@]/);
      return null !== e ? e[1] : null
  },
  getSizedImageUrl: function(t, e) {
      if (null == e) return t;
      if ("master" === e) return this.removeProtocol(t);
      var i = t.match(/\.(jpg|jpeg|gif|png|bmp|bitmap|tiff|tif)(\?v=\d+)?$/i);
      if (null == i) return null;
      var a = t.split(i[0]),
          n = i[0];
      return this.removeProtocol(a[0] + "_" + e + n)
  },
  removeProtocol: function(t) {
      return t.replace(/http(s)?:/, "")
  }
}, theme.Currency = {
  formatMoney: function(t, e) {
      "string" == typeof t && (t = t.replace(".", ""));
      var i = "",
          a = /\{\{\s*(\w+)\s*\}\}/,
          n = e || "${{amount}}";

      function o(t, e, i, a) {
          if (i = i || ",", a = a || ".", isNaN(t) || null === t) return 0;
          var n = (t = (t / 100).toFixed(e)).split(".");
          return n[0].replace(/(\d)(?=(\d\d\d)+(?!\d))/g, "$1" + i) + (n[1] ? a + n[1] : "")
      }
      switch (n.match(a)[1]) {
          case "amount":
              i = o(t, 2);
              break;
          case "amount_no_decimals":
              i = o(t, 0);
              break;
          case "amount_with_comma_separator":
              i = o(t, 2, ".", ",");
              break;
          case "amount_no_decimals_with_comma_separator":
              i = o(t, 0, ".", ",");
              break;
          case "amount_no_decimals_with_space_separator":
              i = o(t, 0, " ");
              break;
          case "amount_with_apostrophe_separator":
              i = o(t, 2, "'")
      }
      return n.replace(a, i)
  }
}, slate.Variants = function() {
  function t(t) {
      this.$container = t.$container, this.product = t.product, this.singleOptionSelector = t.singleOptionSelector, this.originalSelectorId = t.originalSelectorId, this.enableHistoryState = t.enableHistoryState, this.currentVariant = this._getVariantFromOptions(), $(this.singleOptionSelector, this.$container).on("change", this._onSelectChange.bind(this))
  }
  return t.prototype = _.assignIn({}, t.prototype, {
      _getCurrentOptions: function() {
          var t = _.map($(this.singleOptionSelector, this.$container), function(t) {
              var e = $(t),
                  i = e.attr("type"),
                  a = {};
              return "radio" === i || "checkbox" === i ? !!e[0].checked && (a.value = e.val(), a.index = e.data("index"), a) : (a.value = e.val(), a.index = e.data("index"), a)
          });
          return t = _.compact(t)
      },
      _getVariantFromOptions: function() {
          var t = this._getCurrentOptions(),
              e = this.product.variants;
          return _.find(e, function(e) {
              return t.every(function(t) {
                  return _.isEqual(e[t.index], t.value)
              })
          })
      },
      _onSelectChange: function() {
          var t = this._getVariantFromOptions();
          this.$container.trigger({
              type: "variantChange",
              variant: t
          }), t && (this._updateMasterSelect(t), this._updateImages(t), this._updatePrice(t), this._updateSKU(t), this.currentVariant = t, this.enableHistoryState && this._updateHistoryState(t))
      },
      _updateImages: function(t) {
          var e = t.featured_image || {},
              i = this.currentVariant.featured_image || {};
          t.featured_image && e.src !== i.src && this.$container.trigger({
              type: "variantImageChange",
              variant: t
          })
      },
      _updatePrice: function(t) {
          t.price === this.currentVariant.price && t.compare_at_price === this.currentVariant.compare_at_price || this.$container.trigger({
              type: "variantPriceChange",
              variant: t
          })
      },
      _updateSKU: function(t) {
          t.sku !== this.currentVariant.sku && this.$container.trigger({
              type: "variantSKUChange",
              variant: t
          })
      },
      _updateHistoryState: function(t) {
          if (history.replaceState && t) {
              var e = window.location.protocol + "//" + window.location.host + window.location.pathname + "?variant=" + t.id;
              window.history.replaceState({
                  path: e
              }, "", e)
          }
      },
      _updateMasterSelect: function(t) {
          $(this.originalSelectorId, this.$container).val(t.id)
      }
  }), t
}(), window.theme = window.theme || {}, theme.Product = function() {
  function t(t) {
      var e = this.$container = $(t),
          i = this.sectionId = e.attr("data-section-id");
      e.attr("data-section-type");
      this.settings = {
          imageSize: null,
          namespace: ".product-page-section",
          sectionId: i,
          sliderActive: !1,
          swatch_color: e.attr("data-product_swatch_color"),
          swatch_size: e.attr("data-product_swatch_size"),
          variant_image_grouped: e.attr("data-variant_image_grouped"),
          swatch_color_advanced: e.attr("data-product_swatch_color_advanced"),
          product_design: e.attr("data-product_design"),
          product_image_count: e.data("product_image_count")
      }, this.selectors = {
          product: "#ProductSection-" + i,
          addToCart: "#AddToCart-" + i,
          addToCartText: "#AddToCartText-" + i,
          stockText: ".stock-" + i,
          comparePrice: "#ComparePrice-" + i,
          originalPrice: "#ProductPrice-" + i,
          SKU: ".variant-sku",
          originalPriceWrapper: ".product-price__price-" + i,
          originalSelectorId: "#ProductSelect-" + i,
          productFeaturedImage: ".FeaturedImage-" + i,
          productImageWrap: "#FeaturedImageZoom-" + i,
          productPrices: ".product-single__price-" + i,
          productThumbImages: "#product-thumbnails-" + i,
          productMainImages: "#product-images-" + i,
          productPreviewMainImages: ".product-preview-images-" + i,
          saleLabel: ".product-price__sale-label-" + i,
          singleOptionSelector: ".single-option-selector-" + i,
          singleOptionSelectorId: "#single-option-selector-" + i,
          singleOptionSwatches: "wrapper-swatches-" + i,
          instagramProduct: "#product-instagram-" + i,
          instagramProductNameSpace: "product-instagram-" + i,
          variationsSelector: "#variations-" + i,
          variationSelector: ".variation-select-" + i,
          qtyVariant: ".qty-variant-" + i,
          threedId: ".threed-id-" + i,
          countDownId: ".countdown-" + i,
          couponCode: "#coupon-code-" + i,
          couponBtn: "#coupon-btn-" + i,
          sidebarSlide: ".sidebar-slick-vertical-" + i,
          optionsSelect: "#single-option-selector-" + i,
          stickCart: "#sticky-info-" + i,
          cartAgree: "#product-cart__agree-" + i,
          cartCheckout: "#product-buy__1click-" + i,
          groupedProduct: "#products-grouped-" + i,
          moreProducts: "#product-more-products-" + i,
          groupedButton: "#grouped-add-button-" + i,
          groupedCheckbox: "#products-grouped-" + i + " .grouped-checkbox"
      }, $("#ProductJson-" + i).html() && (this.productSingleObject = JSON.parse(document.getElementById("ProductJson-" + i).innerHTML), this.productSwatchSingleObject = JSON.parse(document.getElementById("ProductSwatchJson-" + i).innerHTML), this._stringOverrides(), this._initVariants(), this._initSwatches(), this._initFeature(), this._initCompact(), this._initStickyImages(), this._initThumbnailsGallery(), this._initImages(), this._initSidebar(), this._initZoom(), this._initGallery(), this._instagramProducts(), this._initQuantity(), this._initTabs(), this._initHandleProduct(), this._checkoutCart(), "product-template" == i && this._initRelatedProducts(), "product-template" == i && this._initViewedProducts(), "product-template" == i && this._initUpsellProducts(), "product-template" == i && this._initStickyInfo(), "product-template" == i && this._initGroupedProduct(), "product-template" == i && this._initMoreProducts())
  }
  return t.prototype = _.assignIn({}, t.prototype, {
      _stringOverrides: function() {
          theme.productStrings = theme.productStrings || {}, $.extend(theme.strings, theme.productStrings)
      },
      _initMoreProducts: function() {
          var i = this.selectors.moreProducts,
              a = $(i).find("a.mproduct-item");
          0 < a.length && a.on("click", function(t) {
              t.preventDefault(), a.removeClass("active"), $(this).addClass("active");
              var e = $(this).data("url");
              return $.ajax({
                  url: e,
                  dataType: "html",
                  type: "GET",
                  beforeSend: function() {
                      $(i).find(".mproducts-list-detail").addClass("loading")
                  },
                  success: function(t) {
                      $(i).find(".mproducts-list-detail").html(t), roar.initLazyLoading(i, !0), roar.initProductQuickShopItem(i)
                  },
                  error: function(t) {
                      console.log("ajax error")
                  },
                  complete: function() {
                      roar.handleQuickshop(i), $(i).find(".mproducts-list-detail").removeClass("loading")
                  }
              })
          })
      },
      _initGroupedProduct: function() {
          var t = $(this.selectors.groupedProduct);
          0 != t.length && ($(document).on("change", this.selectors.groupedCheckbox, function(t) {
              $(this).is(":checked") ? $($(this).data("id")).removeClass("hide") : $($(this).data("id")).addClass("hide"), roar.updateGroupedPrice()
          }), 0 < $(this.selectors.groupedButton).length && $(this.selectors.groupedButton).unbind("click"), $(document).on("click", this.selectors.groupedButton, function() {
              var e = $(this);
              return Shopify.queue = [], t.find(".grouped-checkbox").each(function() {
                  if ($(this).is(":checked")) {
                      var t = $($(this).data("id")).find("form .variation-select").val();
                      null !== t && Shopify.queue.push({
                          variantId: t,
                          quantity: 1
                      })
                  }
              }), Shopify.moveAlong = function() {
                  if (Shopify.queue.length) {
                      var t = Shopify.queue.shift();
                      $.ajax({
                          type: "POST",
                          url: "/cart/add.js",
                          async: !0,
                          cache: !1,
                          data: {
                              quantity: t.quantity,
                              id: t.variantId
                          },
                          dataType: "json",
                          beforeSend: function() {
                              e.addClass("loading")
                          },
                          complete: function() {
                              roar.updateCart(e, !1)
                          },
                          error: function(t) {
                              var e = $.parseJSON(t.responseText),
                                  i = e.message + ": " + e.description;
                              alert(i)
                          },
                          success: function(t) {
                              Shopify.moveAlong()
                          }
                      })
                  } else window.location.href = "/cart"
              }, Shopify.moveAlong(), !1
          }))
      },
      _initStickyInfo: function() {
          if ($(this.selectors.stickCart).length) {
              var e = this,
                  i = $("header").outerHeight() + $(".mini-breadcrumb").outerHeight() + $(".product-section-wrapper").offset().top;
              $(window).scroll(function() {
                  var t = $(this).scrollTop();
                  i < t ? $("body").addClass("show-sticky-info-product") : $("body").removeClass("show-sticky-info-product"), t
              }), $("body").on("click", ".sticky-button.button-cart", function(t) {
                  0 < $(e.selectors.addToCart).length && $(e.selectors.addToCart).trigger("click")
              })
          }
      },
      _checkoutCart: function() {
          var a = this,
              i = $(a.selectors.cartAgree);
          0 != i.length && ($(document).on("DOMNodeInserted", a.selectors.cartCheckout, function() {
              var e = $(this);
              setTimeout(function() {
                  var t = e.find(".shopify-payment-button__button");
                  t.length && (e.hide(), setTimeout(function() {
                      i.is(":checked") ? t.removeClass("btn-disabled") : t.addClass("btn-disabled"), e.fadeIn()
                  }, 300))
              }, 0)
          }), $(document).on("change", a.selectors.cartAgree, function(t) {
              var e = $(this),
                  i = $(a.selectors.cartCheckout).find(".shopify-payment-button__button");
              e.is(":checked") ? i.removeClass("btn-disabled") : i.addClass("btn-disabled")
          }))
      },
      _initTabs: function() {
          $("#tabs a").tabs()
      },
      _initHandleProduct: function() {
          0 == $("#main").next("#popup-product-sizechart").length && $("#main").after($("#popup-product-sizechart")), 0 == $("#main").next("#popup-product-question").length && $("#main").after($("#popup-product-question")), $(".button-product-question").click(function(t) {
              $(this).data("question");
              var e = $(this).data("_qid");
              $.magnificPopup.open({
                  items: {
                      src: "#popup-product-question",
                      type: "inline"
                  },
                  tLoading: "",
                  mainClass: "popup-module mfp-with-zoom",
                  removalDelay: 200
              }), (0 < $(".quickview .mfp-content").find("#popup-product-question").length || 0 < $(".quickview .mfp-content").find("#popup-product-sizechart").length) && ($(".quickview.mfp-wrap").addClass("_reopen"), $(".quickview.mfp-wrap").data("_qid", e))
          }), $(".button-product-sizechart").click(function(t) {
              var e = $(this).data("sizechart"),
                  i = $(this).data("_qid");
              $.magnificPopup.open({
                  items: {
                      src: e,
                      type: "inline"
                  },
                  tLoading: "",
                  mainClass: "popup-module mfp-with-zoom",
                  removalDelay: 200
              }), (0 < $(".quickview .mfp-content").find("#popup-product-sizechart").length || 0 < $(".quickview .mfp-content").find("#popup-product-question").length) && ($(".quickview.mfp-wrap").addClass("_reopen"), $(".quickview.mfp-wrap").data("_qid", i))
          }), $(document).on("click", "#tabProduct a", function(t) {
              t.preventDefault(), $(this).tab("show")
          })
      },
      _initUpsellProducts: function() {
          var t = "#upsellProducts .carousel-inner";
          0 < $("#upsellProducts.carousel").length && $(t).slick({
              arrows: !1,
              slidesToShow: 4,
              responsive: [{
                  breakpoint: 1200,
                  settings: {
                      slidesToShow: 4,
                      slidesToScroll: 4
                  }
              }, {
                  breakpoint: 768,
                  settings: {
                      slidesToShow: 4,
                      slidesToScroll: 4
                  }
              }, {
                  breakpoint: 550,
                  settings: {
                      slidesToShow: 2,
                      slidesToScroll: 2
                  }
              }],
              rtl: window.rtl
          }), $("#upsellProduct_next").click(function() {
              return $(t).slick("slickNext"), !1
          }), $("#upsellProduct_prev").click(function() {
              return $(t).slick("slickPrev"), !1
          }), roar.initLazyLoading(t, !0)
      },
      _initRelatedProducts: function() {
          var t = "#myCarouselRelated .carousel-inner";
          0 < $("#myCarouselRelated.carousel").length && $(t).slick({
              arrows: !1,
              slidesToShow: 4,
              responsive: [{
                  breakpoint: 1200,
                  settings: {
                      slidesToShow: 4,
                      slidesToScroll: 4
                  }
              }, {
                  breakpoint: 768,
                  settings: {
                      slidesToShow: 4,
                      slidesToScroll: 4
                  }
              }, {
                  breakpoint: 550,
                  settings: {
                      slidesToShow: 2,
                      slidesToScroll: 2
                  }
              }],
              rtl: window.rtl
          }), $("#myCarouselRelated_next").click(function() {
              return $(t).slick("slickNext"), !1
          }), $("#myCarouselRelated_prev").click(function() {
              return $(t).slick("slickPrev"), !1
          }), roar.initLazyLoading(t, !0)
      },
      _initViewedProducts: function() {
          var t = RoarCookie.cookie.rtread("rt-recent"),
              e = $(".templateProduct #recently-viewed-products").data("handle"),
              i = $(".templateProduct #recently-viewed-products").data("id"),
              a = $(".templateProduct #recently-viewed-products").data("limit");
          if (null != t) {
              if (1 < (t = (t = t.split(",")).reverse()).length ? $("#recently-viewed-products").show() : t != e && $("#recently-viewed-products").show(), $.ajax({
                      url: "/search?view=viewed&q=" + t + "_sp_" + i,
                      dataType: "html",
                      type: "GET",
                      success: function(t) {
                          $("#recently-viewed-products").html(t), roar.initLazyLoading("#recently-viewed-products", !0), roar.initProductQuickShopItem("#recently-viewed-products")
                      },
                      error: function(t) {
                          console.log("ajax error")
                      },
                      complete: function() {
                          var t = $("#myCarouselViewed .carousel-inner");
                          t.slick({
                              arrows: !1,
                              slidesToShow: 4,
                              responsive: [{
                                  breakpoint: 1200,
                                  settings: {
                                      slidesToShow: 4,
                                      slidesToScroll: 4
                                  }
                              }, {
                                  breakpoint: 768,
                                  settings: {
                                      slidesToShow: 4,
                                      slidesToScroll: 4
                                  }
                              }, {
                                  breakpoint: 550,
                                  settings: {
                                      slidesToShow: 2,
                                      slidesToScroll: 2
                                  }
                              }],
                              rtl: window.rtl
                          }), $("#myCarouselViewed_next").click(function() {
                              return t.slick("slickNext"), !1
                          }), $("#myCarouselViewed_prev").click(function() {
                              return t.slick("slickPrev"), !1
                          }), roar.handleQuickshop("#recently-viewed-products")
                      }
                  }), t.indexOf(e) < 0) {
                  t.length >= a && t.pop(), t.push(e);
                  try {
                      t = t.join(",")
                  } catch (t) {}
              }
          } else t = e;
          RoarCookie.cookie.rtwrite("rt-recent", t)
      },
      _initImages: function() {
          var t = $(this.selectors.productMainImages),
              e = !1;
          if (1 == parseInt(window.rtl) && (e = !0), "left" == this.settings.product_design || "upsell" == this.settings.product_design || "bottom" == this.settings.product_design || "compact2" == this.settings.product_design || "split" == this.settings.product_design || "sidebar" == this.settings.product_design || "simple" == this.settings.product_design || "full-screen" == this.settings.product_design) {
              if (0 < $(this.selectors.productThumbImages).length) {
                  var o = $(this.selectors.productThumbImages).find(".thumbnails"),
                      i = "0" != $(this.selectors.productThumbImages).data("vertical"),
                      a = 6,
                      n = !1;
                  if (6 < this.settings.product_image_count ? (a = 6, n = !0) : a = this.settings.product_image_count - 1, $(".product-page-section").hasClass("product-has-sidebar") && (3 < this.settings.product_image_count ? (a = 3, n = !0) : a = this.settings.product_image_count - 1), 1 == n) t.not(".slick-initialized").slick({
                      rtl: e,
                      slidesToShow: 1,
                      slidesToScroll: 1,
                      infinite: !1,
                      adaptiveHeight: !0,
                      asNavFor: o,
                      prevArrow: '<span class="fa fa-angle-left slick-prev-arrow"></span>',
                      nextArrow: '<span class="fa fa-angle-right slick-next-arrow"></span>'
                  }), o.not(".slick-initialized").slick({
                      slidesToShow: a,
                      slidesToScroll: 1,
                      asNavFor: t,
                      focusOnSelect: !0,
                      vertical: i,
                      infinite: !1,
                      prevArrow: '<span class="fa fa-angle-up slick-prev-arrow"></span>',
                      nextArrow: '<span class="fa fa-angle-down slick-next-arrow"></span>',
                      responsive: [{
                          breakpoint: 1024,
                          settings: {
                              slidesToShow: 3
                          }
                      }, {
                          breakpoint: 992,
                          settings: {
                              slidesToShow: 3
                          }
                      }, {
                          breakpoint: 768,
                          settings: {
                              slidesToShow: 3
                          }
                      }]
                  });
                  else {
                      t.not(".slick-initialized").slick({
                          rtl: e,
                          slidesToShow: 1,
                          slidesToScroll: 1,
                          infinite: !1,
                          adaptiveHeight: !0,
                          prevArrow: '<span class="fa fa-angle-left slick-prev-arrow"></span>',
                          nextArrow: '<span class="fa fa-angle-right slick-next-arrow"></span>'
                      });
                      var s = this.settings.product_design,
                          r = $(this.selectors.productFeaturedImage),
                          c = $(this.selectors.productMainImages);
                      o.find(".thumbnails-item").on("click", function(t) {
                          t.preventDefault();
                          var a = $(this).data("href").replace("https:", "").replace("http:", "").split("?v=")[0];
                          r.each(function(t) {
                              var e = $(this);
                              if (0 <= e.attr("href").indexOf(a) && !e.closest(".slick-slide").hasClass("slick-cloned")) {
                                  var i = e.closest(".slick-slide").attr("data-slick-index");
                                  "carousel" == s ? c.slick("slickGoTo", i) : c.slick("slickGoTo", i, !0)
                              } else;
                          }), o.find(".thumbnails-item").removeClass("current"), $(this).addClass("current")
                      }), c.on("beforeChange", function(t, e, i, a) {
                          console.log(a), console.log(r);
                          var n = $(r[a]).attr("href").replace("https:", "").replace("http:", "").split("?v=")[0];
                          o.find(".thumbnails-item").each(function(t) {
                              if (0 <= $(this).data("href").indexOf(n)) return o.find(".thumbnails-item").removeClass("current"), void $(this).addClass("current")
                          })
                      })
                  }
              }
          } else if ("carousel" == this.settings.product_design) {
              var l = t.width() / 4;
              t.not(".slick-initialized").slick({
                  rtl: e,
                  centerMode: !0,
                  centerPadding: l + "px",
                  slidesToShow: 1,
                  slidesToScroll: 1,
                  adaptiveHeight: !0,
                  prevArrow: '<span class="fa fa-angle-left slick-prev-arrow"></span>',
                  nextArrow: '<span class="fa fa-angle-right slick-next-arrow"></span>',
                  responsive: [{
                      breakpoint: 1680,
                      settings: {
                          centerMode: !0,
                          centerPadding: "400px",
                          slidesToShow: 1
                      }
                  }, {
                      breakpoint: 1440,
                      settings: {
                          centerMode: !0,
                          centerPadding: "350px",
                          slidesToShow: 1
                      }
                  }, {
                      breakpoint: 1200,
                      settings: {
                          centerMode: !0,
                          centerPadding: "300px",
                          slidesToShow: 1
                      }
                  }, {
                      breakpoint: 1024,
                      settings: {
                          arrows: !1,
                          centerMode: !0,
                          centerPadding: "250px",
                          slidesToShow: 1
                      }
                  }, {
                      breakpoint: 992,
                      settings: {
                          centerMode: !0,
                          centerPadding: "200px",
                          slidesToShow: 1
                      }
                  }, {
                      breakpoint: 768,
                      settings: {
                          arrows: !1,
                          centerMode: !0,
                          centerPadding: "125px",
                          slidesToShow: 1
                      }
                  }, {
                      breakpoint: 480,
                      settings: {
                          arrows: !1,
                          centerMode: !0,
                          centerPadding: "50px",
                          slidesToShow: 1
                      }
                  }]
              })
          } else t.not(".slick-initialized").slick({
              rtl: e,
              slidesToShow: 1,
              slidesToScroll: 1,
              infinite: !1,
              adaptiveHeight: !0,
              asNavFor: o,
              prevArrow: '<span class="fa fa-angle-left slick-prev-arrow"></span>',
              nextArrow: '<span class="fa fa-angle-right slick-next-arrow"></span>'
          });
          t.imagesLoaded(function() {
              t.addClass("loaded")
          })
      },
      _initThumbnailsGallery: function() {
          var i = $(this.selectors.productMainImages);
          "gallery" == this.settings.product_design && $(".thumbnail-gallery-item").on("click", function() {
              var e = $(this);
              e.hasClass("active") || ($(".thumbnail-gallery-item").removeClass("active"), e.addClass("active"), $(".thumbnail-gallery-item").each(function(t) {
                  $(this).attr("id") != e.attr("id") || i.slick("slickGoTo", t, !0)
              }))
          })
      },
      _initQuantity: function() {
          $(".q_up").unbind("click"), $(".q_up").on("click", function() {
              var t = $(this).data("product_id"),
                  e = parseInt($(".quantity-cart-" + t).val()) + 1;
              $(".quantity-cart-" + t).val(e)
          }), $(".q_down").unbind("click"), $(".q_down").on("click", function() {
              var t = $(this).data("product_id"),
                  e = parseInt($(".quantity-cart-" + t).val());
              1 < e && $(".quantity-cart-" + t).val(e - 1)
          })
      },
      _initPopup: function() {
          $(".sizechart-btn").magnificPopup({
              type: "image",
              midClick: !0
          }), $(".return-btn").click(function(t) {
              return $.magnificPopup.open({
                  items: {
                      src: "#delivery-return",
                      type: "inline"
                  },
                  tLoading: "",
                  mainClass: "popup-wrapper mfp-with-zoom",
                  removalDelay: 200
              }), !1
          })
      },
      _initFeature: function(t) {
          if (0 < $(this.selectors.product + " .product-video-button a").length && $(this.selectors.product + " .product-video-button a").unbind("click") && $(this.selectors.product + " .product-video-button a").click(function(t) {
                  t.stopPropagation();
                  var e = $(this).data("video"),
                      i = $(this).data("_qid");
                  $.magnificPopup.open({
                      items: {
                          src: e,
                          type: "iframe"
                      },
                      type: "iframe",
                      mainClass: "mfp-fade",
                      removalDelay: 160,
                      preloader: !1,
                      disableOn: !1,
                      fixedContentPos: !1,
                      callbacks: {
                          beforeClose: function() {
                              console.log("Popup close has been initiated")
                          }
                      }
                  }), (0 < $(".quickview .mfp-content").find(".product-360-view-wrapper").length || 0 < $(".quickview .mfp-content").find(".mfp-iframe-scaler").length) && ($(".quickview.mfp-wrap").addClass("_reopen"), $(".quickview.mfp-wrap").data("_qid", i))
              }), 0 < $(this.selectors.product + " .product-360-button a").length) {
              for (var e = $(this.selectors.product + " .product-360-button a").data("id"), i = $(this.selectors.product + " .product-360-button a").data("_qid"), a = $(this.selectors.product + " .product-360-button a"), n = Array(), o = JSON.parse(document.getElementById("threed-id-" + this.sectionId).innerHTML), s = 1; s <= 72; s++) {
                  var r = "f" + s;
                  o[r] && n.push(o[r])
              }
              if (0 < n.length) {
                  var c = n.length;
                  $(this.selectors.threedId).ThreeSixty({
                      totalFrames: c,
                      endFrame: c,
                      currentFrame: 1,
                      imgList: ".threed-view-images",
                      progress: ".spinner",
                      imgArray: n,
                      height: null,
                      width: null,
                      responsive: !0,
                      navigation: !0,
                      onReady: function() {
                          0 == $("#main").next(".product-360-view-wrapper").length && $("#main").after($(e)), a.unbind("click") && a.click(function(t) {
                              $.magnificPopup.open({
                                  items: {
                                      src: e,
                                      type: "inline"
                                  },
                                  type: "inline",
                                  mainClass: "mfp-fade",
                                  removalDelay: 160,
                                  disableOn: !1,
                                  preloader: !1,
                                  fixedContentPos: !1,
                                  callbacks: {
                                      open: function() {
                                          console.log("xx11"), $(window).resize()
                                      }
                                  }
                              }), $(window).resize(), (0 < $(".quickview .mfp-content").find(".product-360-view-wrapper").length || 0 < $(".quickview .mfp-content").find(".mfp-iframe-scaler").length) && ($(".quickview.mfp-wrap").addClass("_reopen"), $(".quickview.mfp-wrap").data("_qid", i))
                          })
                      }
                  })
              }
          }
      },
      _initCompact: function() {
          0 < $(".product-accordions").length && $(".product-accordions .tab-heading").unbind("click") && $(".product-accordions .tab-heading").click(function(t) {
              t.preventDefault();
              var e = $(this),
                  i = e.closest(".product-accordion"),
                  a = e.closest(".product-accordions");
              i.hasClass("active") ? (i.removeClass("active"), i.find(".product-accordion-content").stop(!0, !0).slideUp()) : (a.find(".product-accordion").removeClass("active"), i.addClass("active"), a.find(".product-accordion-content").stop(!0, !0).slideUp(), i.find(".product-accordion-content").stop(!0, !0).slideDown())
          })
      },
      _initStickyImages: function() {
          $("body").hasClass("fastor-product-design-sticky") && $(".product-design-sticky .product-summary").stick_in_parent()
      },
      _instagramProducts: function() {
          0 < $("#instagram_product").length && $.instagramFeed({
              username: $("#instagram_product").data("uid"),
              items: $("#instagram_product").data("limit"),
              container: "#instagram_product",
              display_profile: !1,
              display_biography: !1,
              display_gallery: !0,
              get_raw_json: !1,
              callback: null,
              styling: !1,
              custom_class: ""
          })
      },
      _initGallery: function() {
          ! function(t) {
              function e(t) {
                  (t = t || window.event).preventDefault ? t.preventDefault() : t.returnValue = !1;
                  var e = function t(e, i) {
                      return e && (i(e) ? e : t(e.parentNode, i))
                  }(t.target || t.srcElement, function(t) {
                      return function(t, e) {
                          return -1 < (" " + t.className + " ").indexOf(" " + e + " ")
                      }(t, "photoswipe-item")
                  });
                  if (e) {
                      for (var i, a = e.closest(".photoswipe-wrapper"), n = $(e.closest(".photoswipe-wrapper")).find(".photoswipe-item").get(), o = n.length, s = 0, r = 0; r < o; r++)
                          if (1 === n[r].nodeType) {
                              if (n[r] === e) {
                                  i = s;
                                  break
                              }
                              s++
                          } return 0 <= i && c(i, a), !1
                  }
              }
              for (var c = function(t, e, i, a) {
                      var n, o, s, r = document.querySelectorAll(".pswp")[0];
                      if (s = function(t) {
                              for (var e, i, a, n, o = $(t).find(".photoswipe-item").get(), s = o.length, r = [], c = 0; c < s; c++)
                                  if (1 === (e = o[c]).nodeType)
                                      if (a = (i = e.children[0]).getAttribute("data-size").split("x"), "video" == $(i).data("type")) {
                                          var l = $($(i).data("id")).html();
                                          r.push({
                                              html: l
                                          })
                                      } else n = {
                                          src: i.getAttribute("href"),
                                          w: parseInt(a[0], 10),
                                          h: parseInt(a[1], 10)
                                      }, 1 < e.children.length && (n.title = $(e).find(".caption").html()), 0 < i.children.length && (n.msrc = i.children[0].getAttribute("src")), n.el = e, r.push(n);
                              return r
                          }(e), o = {
                              closeOnScroll: !1,
                              galleryUID: e.getAttribute("data-pswp-uid")
                          }, a)
                          if (o.galleryPIDs) {
                              for (var c = 0; c < s.length; c++)
                                  if (s[c].pid == t) {
                                      o.index = c;
                                      break
                                  }
                          } else o.index = parseInt(t, 10) - 1;
                      else o.index = parseInt(t, 10);
                      isNaN(o.index) || (i && (o.showAnimationDuration = 0), (n = new PhotoSwipe(r, PhotoSwipeUI_Default, s, o)).init(), n.listen("beforeChange", function() {
                          var t = $(n.currItem.container);
                          $(".pswp__video").removeClass("active");
                          t.find(".pswp__video").addClass("active");
                          $(".pswp__video").each(function() {
                              $(this).hasClass("active") || $(this).attr("src", $(this).attr("src"))
                          })
                      }), n.listen("close", function() {
                          $(".pswp__video").each(function() {
                              $(this).attr("src", $(this).attr("src"))
                          }), $(".pswp__container .video-wrapper").empty()
                      }))
                  }, i = document.querySelectorAll(t), a = 0, n = i.length; a < n; a++) i[a].setAttribute("data-pswp-uid", a + 1), i[a].onclick = e;
              var o = function() {
                  var t = window.location.hash.substring(1),
                      e = {};
                  if (t.length < 5) return e;
                  for (var i = t.split("&"), a = 0; a < i.length; a++)
                      if (i[a]) {
                          var n = i[a].split("=");
                          n.length < 2 || (e[n[0]] = n[1])
                      } return e.gid && (e.gid = parseInt(e.gid, 10)), e
              }();
              o.pid && o.gid && c(o.pid, i[o.gid - 1], !0, !0)
          }(this.selectors.product + " .photoswipe-wrapper")
      },
      _initZoom: function() {
          if ($(".easyzoom").length)
              if (1024 < $(window).width()) $(".easyzoom:not(.feature-video)").easyZoom({
                  loadingNotice: "",
                  errorNotice: "",
                  preventClicks: !1
              }).data("easyZoom");
              else $(".easyzoom a").click(function(t) {
                  t.preventDefault()
              })
      },
      _initSidebar: function() {
          $sidebarSlide = $(this.selectors.sidebarSlide), 0 < $sidebarSlide.length && $sidebarSlide.each(function() {
              var t = $(this),
                  e = $(this).data("per_view");
              $(this).not(".slick-initialized").slick({
                  slidesToShow: e,
                  slidesToScroll: 1,
                  vertical: !0,
                  focusOnSelect: !0,
                  infinite: !1,
                  prevArrow: '<span class="fa fa-angle-up slick-prev-arrow"></span>',
                  nextArrow: '<span class="fa fa-angle-down slick-next-arrow"></span>'
              }), t.imagesLoaded(function() {
                  t.addClass("loaded")
              })
          })
      },
      _initForceHeight: function() {
          0 < $(this.selectors.productPreviewMainImages).length && $(this.selectors.productPreviewMainImages).not(".slick-initialized").slick({
              slidesToShow: 1,
              slidesToScroll: 1,
              infinite: !1,
              prevArrow: '<span class="fa fa-angle-left slick-prev-arrow"></span>',
              nextArrow: '<span class="fa fa-angle-right slick-next-arrow"></span>'
          })
      },
      _initSwatches: function() {
          var m = this.selectors.optionsSelect;
          var t, e, a, n, o, s = this.productSingleObject,
              r = this.productSwatchSingleObject,
              c = new Array;
          if ("1" == this.settings.swatch_size && c.push("Size"), c.push("size"), "1" == this.settings.swatch_color && (c.push("Color"), c.push("Colour"), c.push("color"), c.push("colour")), 0 < c.length) {
              var l = !1,
                  d = 0,
                  h = theme.asset_url.substring(0, theme.asset_url.lastIndexOf("?")),
                  u = theme.asset_url.substring(theme.asset_url.lastIndexOf("?"), theme.asset_url.length);
              for (i = 0; i < s.options.length; i++) {
                  var p = "",
                      f = "",
                      g = "",
                      v = "",
                      _ = "",
                      w = "",
                      y = "",
                      b = "img btooltip";
                  if (p = "object" == typeof s.options[i] ? s.options[i].name : s.options[i], l = !1, -1 < c.indexOf(p)) {
                      l = !0, d = i;
                      var C = p.toLowerCase();
                      if (/color|colour/i.test(C) && !0, l) {
                          var k = new Array;
                          for (j = 0; j < s.variants.length; j++) {
                              var S = s.variants[j],
                                  x = this.htmlEntities(S.options[d]),
                                  T = this.convertToSlug(x);
                              k.indexOf(x) < 0 && ("color" != C && "colour" != C ? (y = x, b = "btooltip") : y = "1" == this.settings.swatch_color_advanced ? null !== r[T] && void 0 !== r[T] && "" != r[T] ? (b = "img btooltip swatch_color_advanced", '<i class="b-lazy" data-src="' + h + r[T] + ".png" + u + '"></i>') : null !== S.featured_image ? (b = "img btooltip swatch_color_advanced", '<i class="b-lazy" data-src="' + (t = S.featured_image.src, a = e = void 0, e = t.replace("https:", "").replace("http:", "").split("?v=")[0].split("/"), a = e[e.length - 1].split("."), n = a.pop(), o = a.join(".") + "_100x." + n, t.replace(e[e.length - 1], o)) + '"></i>') : '<i class="b-lazy" style="background-color:' + x + ';" data-src="' + h + T + ".png" + u + '"></i>' : '<i class="b-lazy" style="background-color:' + x + ';" data-src="' + h + T + ".png" + u + '"></i>', w = $(this.selectors.singleOptionSelectorId + "-" + d).val() == x ? "selected " : "", g = g + '<div class="swatch-element ' + C + T + ' available"><input data-id="' + this.selectors.singleOptionSelectorId + "-" + d + '" data-value="' + x + '"  class="swatch-radio ' + w + '" id="swatch-' + d + "-" + T + '" type="radio" data-swatch="' + C + '" data-poption="' + d + '" name="option-' + d + '" value="' + x + '"><label for="swatch-' + d + "-" + T + '" class="' + b + '" title="' + x + '"><span class="soldout-image"></span>' + y + "</label></div>", k.push(x))
                          }
                          f = '<div class="' + this.selectors.singleOptionSwatches + " wrapper-swatches swatch " + C + '" data-attribute_name="attribute_pa_' + C + '"><div>' + g + "</div></div>", v = $(this.selectors.singleOptionSelectorId + "-" + d), _ = $(this.selectors.variationSelector + "-" + d), "" != f && (v.after(f), v.hide(), _.addClass("hide-choose-option"))
                      }
                  }
              }
          }
          var I = "",
              P = "." + this.selectors.singleOptionSwatches + " .swatch-radio",
              A = this;
          0 < $("." + this.selectors.singleOptionSwatches).length && ((I = $(P)).unbind("click"), I.on("click", function() {
              var t = $(this).data("id"),
                  e = $(this).data("poption"),
                  a = $(this).data("value"),
                  n = $(this).data("swatch");
              $(this).data("value") != $(t).val() && ($(t).val($(this).data("value")).trigger("change"), $(t).closest(".selector-wrapper").find(".swatch-radio").removeClass("selected"), $(this).addClass("selected"), $(t).closest(".selector-wrapper"), $(t).closest(".selector-wrapper").find(".option-select-value").html($(this).data("value"))),
                  function(o, s, r, t, e) {
                      if (1 < o.options.length)
                          for (i = 0; i < o.options.length; i++) i != s && $(m + "-" + i + " option").each(function() {
                              var t = "unavailable",
                                  e = $(this).attr("value");
                              for (j = 0; j < o.variants.length; j++) {
                                  var a = o.variants[j];
                                  if (a.options[s] == r && a.options[i] == e) {
                                      t = 1 == a.available ? "available" : "sold_out";
                                      break
                                  }
                              }
                              var n = "#swatch-" + i + "-" + e.toLowerCase().replace(/[^a-z0-9 -]/g, "").replace(/\s+/g, "-").replace(/-+/g, "-");
                              $(n).closest(".swatch-element").removeClass("available").removeClass("sold_out").removeClass("unavailable").addClass(t)
                          });
                      else
                          for (i = 0; i < o.options.length; i++) $("#single-option-selector-product-template-" + i + " option").each(function() {
                              var t = "unavailable",
                                  e = $(this).attr("value");
                              for (j = 0; j < o.variants.length; j++)
                                  if (o.variants[j].options[i] == e) {
                                      t = o.variants[j].available ? "available" : "sold_out";
                                      break
                                  } var a = "#swatch-" + i + "-" + e.toLowerCase().replace(/[^a-z0-9 -]/g, "").replace(/\s+/g, "-").replace(/-+/g, "-");
                              $(a).closest(".swatch-element").removeClass("available").removeClass("sold_out").removeClass("unavailable").addClass(t)
                          });
                      var a = e.settings.variant_image_grouped,
                          n = e.selectors.productMainImages + ".slick-slider",
                          c = e.selectors.productThumbImages + " .slick-slider",
                          l = r,
                          d = e.productSingleObject,
                          h = e.selectors.originalSelectorId;
                      if ("1" == a && ("color" == t || "colour" == t)) {
                          $(c).slick("slickUnfilter").slick("slickFilter", "[data-color='" + l + "']");
                          var u = $(c).find(".slick-slide"),
                              p = 0,
                              f = !1;
                          u.each(function(a, n) {
                              $(n).attr("data-slick-index", a), jQuery.each(d.variants, function(t, e) {
                                  if (e.id == $(h).val() && 0 == f) {
                                      var i = e.featured_image.src.replace(/^https?\:/i, "").split("?")[0].replace(".png", "").replace(".jpg", "");
                                      0 <= $(n).find("img").first().attr("src").indexOf(i) && (p = a, f = !0)
                                  }
                              })
                          }), $(c).slick("slickGoTo", p, !0), $(n).slick("slickUnfilter").slick("slickFilter", "[data-color='" + l + "']");
                          u = $(n).find(".slick-slide"), p = 0, f = !1;
                          u.each(function(a, n) {
                              $(n).attr("data-slick-index", a), jQuery.each(d.variants, function(t, e) {
                                  if (e.id == $(h).val() && 0 == f) {
                                      var i = e.featured_image.src.replace(/^https?\:/i, "").split("?")[0].replace(".png", "").replace(".jpg", "");
                                      0 <= $(n).find("img").first().attr("src").indexOf(i) && (p = a, f = !0)
                                  }
                              })
                          }), $(n).slick("slickGoTo", p, !0), $(".templateProduct .thumbnails .slick-list").width() >= $(".templateProduct .thumbnails .slick-track").width() ? $("body").append('<style id="product-images-filtering-style" type="text/css">.templateProduct .thumbnails .slick-track{transform:none!important;}</style>') : 0 < $("style#product-images-filtering-style").length && $("style#product-images-filtering-style").remove()
                      }
                  }(s, e, a, n, A)
          })), $(".swatch-radio.selected").trigger("click")
      },
      htmlEntities: function(t) {
          return String(t).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;")
      },
      convertToSlug: function(t) {
          return t.toLowerCase().replace(/[^a-z0-9 -]/g, "").replace(/\s+/g, "-").replace(/-+/g, "-")
      },
      _initVariants: function() {
          var t = {
              $container: this.$container,
              enableHistoryState: this.$container.data("enable-history-state") || !1,
              singleOptionSelector: this.selectors.singleOptionSelector,
              originalSelectorId: this.selectors.originalSelectorId,
              product: this.productSingleObject
          };
          this.variants = new slate.Variants(t), this.$container.on("variantChange" + this.settings.namespace, this._updateAddToCart.bind(this)), this.$container.on("variantImageChange" + this.settings.namespace, this._updateImages.bind(this)), this.$container.on("variantPriceChange" + this.settings.namespace, this._updatePrice.bind(this)), this.$container.on("variantSKUChange" + this.settings.namespace, this._updateSKU.bind(this))
      },
      _updateAddToCart: function(t) {
          var e = t.variant;
          e ? ($(this.selectors.productPrices).removeClass("invisible").attr("aria-hidden", "true"), $(".variations_button").removeClass("hide"), e.available ? ($(this.selectors.addToCart).prop("disabled", !1).toggleClass("hide", !1), $(this.selectors.addToCart).val(theme.strings.addToCart), $(this.selectors.stockText).html(theme.strings.inStock).removeClass("out-of-stock unavailable").addClass("in-stock"), "shopify" == e.inventory_management && "continue" != e.inventory_policy && (0 < e.inventory_quantity && 1 == parseInt(theme.inventory) ? $(this.selectors.stockText).html(e.inventory_quantity + " " + theme.strings.inStock) : $(this.selectors.stockText).html(theme.strings.inStock))) : ($(this.selectors.addToCart).prop("disabled", !0).toggleClass("hide", !1), $(this.selectors.addToCart).val(theme.strings.soldOut), $(this.selectors.stockText).html(theme.strings.outStock).removeClass("in-stock unavailable").addClass("out-of-stock"))) : ($(".variations_button").addClass("hide"), $(this.selectors.addToCart).prop("disabled", !0).toggleClass("hide", !0), $(this.selectors.addToCart).val(theme.strings.unavailable), $(this.selectors.stockText).html(theme.strings.unavailable).removeClass("in-stock").addClass("out-of-stock unavailable"), $(this.selectors.productPrices).addClass("invisible").attr("aria-hidden", "false"))
      },
      _updateImages: function(t) {
          var e = t.variant,
              o = this,
              s = this.settings.product_design,
              r = e.featured_image.src.replace("https:", "").replace("http:", "").split("?v=")[0];
          console.log(1), $(this.selectors.productFeaturedImage).each(function(t) {
              console.log(2);
              var e = $(this);
              if (0 <= e.attr("href").indexOf(r) && !e.closest(".slick-slide").hasClass("slick-cloned")) {
                  console.log(3);
                  var i = $(o.selectors.productMainImages),
                      a = e.closest(".slick-slide").attr("data-slick-index");
                  if (console.log("pos: " + a), "carousel" == s ? i.slick("slickGoTo", a) : (console.log(4), i.slick("slickGoTo", a, !0)), "scroll" == s) {
                      var n = parseInt(e.closest(".shopify-product-gallery__image").offset().top) - 50;
                      $("html,body").animate({
                          scrollTop: n
                      }, "slow")
                  }
                  "gallery" == s && 0 < $(".thumbnails .thumbnail-gallery-item").length && $(".thumbnails .thumbnail-gallery-item").each(function() {
                      0 <= $(this).data("href").indexOf(r) && $(this).trigger("click")
                  })
              } else;
          })
      },
      _updatePrice: function(t) {
          var e = t.variant;
          if ($(this.selectors.originalPrice).html('<span class="money">' + theme.Currency.formatMoney(e.price, theme.settings.moneyFormat) + "</span>"), e.compare_at_price > e.price) {
              if ($(this.selectors.productPrices).addClass("has-sale"), $(this.selectors.productPrices).removeClass("not-sale"), $(this.selectors.comparePrice).html('<span class="money">' + theme.Currency.formatMoney(e.compare_at_price, theme.settings.moneyFormat) + "</span>").removeClass("hide"), $(this.selectors.saleLabel).find("span").text(theme.strings.sale), "" != theme.sale_percentages) {
                  var i = Math.round(100 * (e.compare_at_price - e.price) / e.compare_at_price);
                  $(this.selectors.saleLabel).find("span").text("-" + i + "%")
              }
              $(this.selectors.saleLabel).addClass("hide")
          } else $(this.selectors.productPrices).removeClass("has-sale"), $(this.selectors.productPrices).addClass("not-sale"), $(this.selectors.comparePrice).addClass("hide"), $(this.selectors.saleLabel).addClass("hide");
          window.show_multiple_currencies && theme.CurrencyPicker.convert(this.selectors.product + " .money")
      },
      _updateSKU: function(t) {
          var e = t.variant;
          "" != e.sku ? $(this.selectors.SKU).removeClass("hide").find(".sku").text(e.sku) : $(this.selectors.SKU).addClass("hide")
      },
      onUnload: function() {
          this.$container.off(this.settings.namespace)
      }
  }), t
}(), 
window.theme = window.theme || {},
theme.Filters = (function() {
  var selectors = {
    filterForm: '#CollectionFiltersForm',
    filterChoice: '[data-filter-choice]',
    tagChoice: '[data-tag-choice]',
    tagClear: '[data-filter-clear]',

    sortSelection: '#SortBy',

    limitSelection: '#limit',

    layoutChoice: '[data-layout]'
  }, 
  attributes = {
      filterChoices: 'data-filter-choice',
      tagChoices: 'data-tag-choice'
  };
  
  function beforeInit() {
    if (!$(selectors.filter).length) {
      return;
    }
  }

  function Filters(container) {

    console.log('filter is here');
    
   // var $container = this.$container = $(container);

    this.$container = container;
    
    this._refresh();
  
    beforeInit();

    $(document).on('change', selectors.sortSelection, this._onSortChangeAjax.bind(this));
    $(document).on('change', selectors.limitSelection, this._onLimitChangeAjax.bind(this));
    $(document).on('input', selectors.filterForm , this._onFilterFormChangeAjax.bind(this));
    $(document).on('click', selectors.tagChoice , this._onTagChoiceChangeAjax.bind(this));
    $(document).on('click', selectors.layoutChoice , this._onLayoutChangeAjax.bind(this));
    $(document).on('click', selectors.tagClear , this._onTagClearChangeAjax.bind(this));
    
    
    this._initParams();
  }

  Filters.prototype = _.assignIn({}, Filters.prototype, {
    _initParams: function() {
      console.log('init-param');
      this.queryParams = new FormData();
      if (location.search.length) {
          var aKeyValue;
          var aCouples = location.search.substr(1).split('&');
          for (var i = 0; i < aCouples.length; i++) {
              aKeyValue = aCouples[i].split('=');
              if (aKeyValue.length > 1) {
                  this.queryParams.append(decodeURIComponent(aKeyValue[0]), decodeURIComponent(aKeyValue[1]));
              }
          }
      }
    },
    _refresh: function() {

        this.collectionHandle = this.$container.dataset.collectionHandle;
        this.currentTags = this.$container.dataset.currentTags;
        
        this.containerSelect = '#' + this.$container.id;
        this.filterChoices = this.$container.querySelectorAll(selectors.filterChoice);
        this.tagChoices = this.$container.querySelectorAll(selectors.tagChoice);
        this.sortSelect = this.$container.querySelector(selectors.sortSelection);
        this.sortClick = this.$container.querySelector(selectors.sortClick);
        this.limitSelect = this.$container.querySelector(selectors.limitSelection);

        this.filterChoicesAttr = attributes.filterChoices;
        this.tagChoicesAttr = attributes.tagChoices;

        if (this.sortSelect) {
            this.defaultSort = this._getDefaultSortValue();
        }

        if (this.limitSelect) {
            this.defaultLimit = this._getDefaultLimitValue();
        }
       
        this._priceSlider('.filter-price-slider');
    },
    _getSortValue: function() {
      return this.sortSelect.value || this.defaultSort;
    },
    _getDefaultSortValue: function() {
      return this.sortSelect.dataset.defaultSortby;
    },
    _getLimitValue: function() {
        return this.limitSelect.value || this.defaultLimit;
    },
    _getDefaultLimitValue: function() {
        return this.limitSelect.dataset.defaultLimit;
    },

    _priceSlider: function ( selector, option ) {
      if(document.querySelector('.filter-price-slider') == undefined ) return;
      var _rmin = parseInt(document.querySelector(selector).dataset.rangemin, 10);
      var _rmax = parseInt(document.querySelector(selector).dataset.rangemax, 10);
      var _cmin = parseInt(document.querySelector(selector).dataset.currmin, 10);
      var _cmax = parseInt(document.querySelector(selector).dataset.currmax, 10);
      if ( typeof noUiSlider === 'object' ) {
          $( selector ).each( function () {
              var self = this;

              noUiSlider.create( self, $.extend( true, {
                  start: [ _cmin, _cmax ],
                  connect: true,
                  step: 1,
                  range: {
                      min: _rmin,
                      max: _rmax
                  }
              }, option ) );

              self.noUiSlider.on( 'update', function ( values, handle ) {
                  var values = values.map( function ( value ) {
                      return '$' + parseInt( value );
                  } )
                  $( self ).parent().find( '.filter-price-range' ).text( values.join( ' - ' ) );
              } );
              self.noUiSlider.on( 'end', function ( values, handle ) {
                  var _min = parseInt( values[0] );
                  var _max = parseInt( values[1] );
                  $( self ).parent().find( '.filter-price--min' ).val(_min);
                  $( self ).parent().find( '.filter-price--max' ).val(_max);
              } );
              $( self ).parent().find( '.price-filter-action' ).on( 'click', function(){
                  var _event = new Event('input', {
                      bubbles: true,
                      cancelable: true,
                  });
                  document.querySelector(selector).closest( 'form' ).dispatchEvent(_event);
              });
          } );
      }
    },
    
    _onSortChangeAjax: function() {
      this.queryParams.set('sort_by', this._getSortValue());
      this.queryParams.delete('page');

      var new_url = window.location.origin + window.location.pathname + '?' + decodeURIComponent(
          new URLSearchParams(this.queryParams).toString()
      );
      this._ajaxCall(new_url);
    },
    _onLimitChangeAjax: function() {
        this.queryParams.set('limit', this._getLimitValue());
        this.queryParams.delete('page');

        var new_url = window.location.origin + window.location.pathname + '?' + decodeURIComponent(
            new URLSearchParams(this.queryParams).toString()
        );
        this._ajaxCall(new_url);
    },
    _onTagClearChangeAjax: function(evt){

      var currentTags = this.$container.dataset.currentTags;
      var currentTagsArray = currentTags.split(',');

      var otherTags = $(evt.target).closest('.column').find("input:checked");
      if(otherTags.length > 0) {
        otherTags.each(function() {
          var tagName = $(this).val();
          if(tagName) {
            var tagPos = currentTagsArray.indexOf(tagName);
            if(tagPos >= 0) {
              //remove tag
              currentTagsArray.splice(tagPos, 1);
            }
          }
        });
      }
      var filter_tags = "";
      var newTagsArray =  currentTagsArray.filter((v) => v != '');
      var newCurrentsTags = "";
      if (newTagsArray.length > 0){
        filter_tags = newTagsArray.join('+');
        var newCurrentsTags = ',' + newTagsArray.join(',') + ',';
      }

      // return current new tags
      this.$container.dataset.currentTags = newCurrentsTags;

      var defaultHref = '/collections/' + this.collectionHandle;

      if(filter_tags != "") {
        defaultHref = defaultHref + '/' + filter_tags;
      }
      this.queryParams.delete('page');

      var valid_params = [ "view", "limit", "sort_by", "lo", "token"];
      var toberemoved_params = [];
      for(var pair of this.queryParams.entries()) {
          if(valid_params.indexOf(pair[0]) <= 0) {
              toberemoved_params.push(pair[0]);
          }
      }
      toberemoved_params.forEach(el => this.queryParams.delete(el));
      var queryString = decodeURIComponent(
          new URLSearchParams(this.queryParams).toString()
      );
      var new_url = defaultHref + '?' + queryString;
      this._ajaxCall(new_url);

    },
    _onTagChoiceChangeAjax: function(evt){

    var currentTags = this.$container.dataset.currentTags;
    var tag_element = evt.target.closest(selectors.tagChoice);
    var data_tag = ','+tag_element.value+',';
    var currentTagsArray = currentTags.split(',');

    if(currentTags.indexOf(data_tag) !== -1) {
      
      tag_element.classList.remove('selected');
      var postion_element = currentTagsArray.indexOf(tag_element.value);
      if(postion_element >= 0) {
        currentTagsArray.splice(postion_element, 1);
      }
     
    }else{
      tag_element.classList.add('selected');
      currentTagsArray.push(tag_element.value);
    }
    var filter_tags = "";
    var newTagsArray =  currentTagsArray.filter((v) => v != '');
    var newCurrentsTags = "";
    if (newTagsArray.length > 0){
      filter_tags = newTagsArray.join('+');
      var newCurrentsTags = ',' + newTagsArray.join(',') + ',';
    }
    // return current new tags
    this.$container.dataset.currentTags = newCurrentsTags;

    var defaultHref = '/collections/' + this.collectionHandle;

    if(filter_tags != "") {
      defaultHref = defaultHref + '/' + filter_tags;
    }

    this.queryParams.delete('page');

    var valid_params = [ "view", "limit", "sort_by", "lo", "token"];
    var toberemoved_params = [];
    for(var pair of this.queryParams.entries()) {
        if(valid_params.indexOf(pair[0]) <= 0) {
            toberemoved_params.push(pair[0]);
        }
    }
    toberemoved_params.forEach(el => this.queryParams.delete(el));
     var queryString = decodeURIComponent(
        new URLSearchParams(this.queryParams).toString()
    );
    var new_url = defaultHref + '?' + queryString;
    this._ajaxCall(new_url);
    
    },
    _onFilterFormChangeAjax: function(evt) {

      var currentTags = this.$container.dataset.currentTags;
      var currentTagsArray = currentTags.split(',');
      var newTagsArray =  currentTagsArray.filter((v) => v != '');

      var filter_tags = "";
      if (newTagsArray.length > 0){
        filter_tags = newTagsArray.join('+');
      }

      var defaultHref = '/collections/' + this.collectionHandle;

      if(filter_tags != "") {
        defaultHref = defaultHref + '/' + filter_tags;
      }
    
      var choice_ui = evt.target.closest(selectors.filterChoice);

      this.queryParams.delete('page');

      var valid_params = [ "view", "limit", "sort_by", "lo", "token"];
        var toberemoved_params = [];
        for(var pair of this.queryParams.entries()) {
            if(valid_params.indexOf(pair[0]) <= 0) {
                toberemoved_params.push(pair[0]);
            }
        }
        toberemoved_params.forEach(el => this.queryParams.delete(el));

        var filterFormData = new FormData(evt.target.closest('form'));
        for(var pair of filterFormData.entries()) {
            this.queryParams.append(pair[0], pair[1]);
        }
        var queryString = decodeURIComponent(
            new URLSearchParams(this.queryParams).toString()
        );
        
        if(choice_ui?.parentNode.tagName == 'LI') {
            choice_ui?.parentNode.classList.toggle('active');
        }

        var new_url = defaultHref + '?' + queryString;
        this._ajaxCall(new_url);
    },
    _onLayoutChangeAjax: function(evt) {
      
      var choice = evt.target.closest(selectors.layoutChoice);
      console.log(choice);
      console.log(choice.dataset.value);
      if(choice.classList.contains('active')) return false;

      this.queryParams.set('lo', choice.dataset.value);
      this.queryParams.set('token', Math.floor(Math.random() * Math.floor(1000)));

      var new_url = window.location.origin + window.location.pathname + '?' + decodeURIComponent(
          new URLSearchParams(this.queryParams).toString()
      );
      this._ajaxCall(new_url);
      var _nc = 'flex-view-'+ choice.dataset.value;
      $(document.body).removeClass('flex-view-1 flex-view-2 flex-view-3 flex-view-4 flex-view-6').addClass(_nc);
      $('#mfilter-content-container').removeClass('list grid').addClass(choice.dataset.layout);

      
    },
    _ajaxCall: function(newurl) {
        
      var _content = "#mfilter-content-container";
      var _sidebar = ".collection-filter-wrap";
      var _filter_actions = ".filter-actions-result";
      
      var _this = this;
      $.ajax({
        type: "get",
        url: newurl,
        beforeSend: function() {
          roar.destroyCountdown(), $("body")
          .addClass("is_loading")
          .removeClass("open_filter");
        },
        success: function(data) {
          var _title = $(data).filter('title').text();
          $(_content).empty().html($(data).find(_content).html());
          $(_sidebar).empty().html($(data).find(_sidebar).html());
          $(_filter_actions).empty().html($(data).find(_filter_actions).html());
          _this._refresh();
          History.pushState({
            param: Shopify.queryParams
          }, _title, newurl), setTimeout(function() {
            $("html,body").animate({
              scrollTop: $("body #sandbox").offset().top
            }, 500, "swing")
          }, 100);
          $("body").removeClass("is_loading");
          roar.mapPaginationCallback();
          
          
        },
        error: function() {
          $("body").removeClass("is_loading")
        }
      })
    },


    onUnload: function() {

      if (this.sortSelect) {
        this.$sortSelect.off('change', this._onSortChangeAjax);
      }
      if (this.limitSelect) {
        this.$limitSelect.off('change', this._onLimitChangeAjax);
      }
    }
  });

  return Filters;
})(),
 theme.MegaMenuSection = function() {
  function t(t) {
      var e = this.$container = $(t),
          i = e.attr("data-section-id");
      e.attr("data-section-type");
      this.MegaMenu = $("#megamenu-" + i), this.megaMenuNamspace = "#megamenu-" + i, this.megaMenuId = $("#shopify-section-" + i), 0 < $(".section-megamenu-content").length && $(".section-megamenu-content").each(function() {
          var t = $(this).data("menu_width_class");
          0 < $(this).closest(".shopify-section").length && ($(this).closest(".shopify-section").hasClass(t) || $(this).closest(".shopify-section").addClass(t), $(this).closest(".shopify-section").removeClass("hidden"))
      }), 0 < $("#header-phantom .shopify-section").length && $("#header-phantom .shopify-section").each(function() {
          $(this).removeClass("shopify-section")
      }), this._init()
  }
  return t.prototype = _.assignIn({}, t.prototype, {
      _init: function() {
          roar.fixedHeaderMenu(), this._products(), this._handleMegaMenu(), this._handleVermenuCategory()
      },
      _products: function() {
          0 < $(".products-carousel-megamenu").length && $(".products-carousel-megamenu").each(function() {
              var t = $(this).data("_id"),
                  e = ($(this).data("_one"), $(this).data("_two")),
                  i = $(this).data("_three"),
                  a = $(this).data("_four"),
                  n = $("#productsCarousel" + t);
              n.not(".slick-initialized").slick({
                  arrows: !1,
                  slidesToShow: a,
                  slidesToScroll: a,
                  responsive: [{
                      breakpoint: 1920,
                      settings: {
                          slidesToShow: a,
                          slidesToScroll: a
                      }
                  }, {
                      breakpoint: 768,
                      settings: {
                          slidesToShow: i,
                          slidesToScroll: i
                      }
                  }, {
                      breakpoint: 480,
                      settings: {
                          slidesToShow: e,
                          slidesToScroll: e
                      }
                  }],
                  rtl: window.rtl
              }), $(".productsCarousel" + t + "_next").click(function() {
                  return n.slick("slickNext"), !1
              }), $(".productsCarousel" + t + "_prev").click(function() {
                  return n.slick("slickPrev"), !1
              }), $(window).resize(function() {
                  n.slick("setPosition")
              })
          })
      },
      _handleVermenuCategory: function() {
          if ($("#vermenu_cat_gap").length && 992 <= roar.getWidthBrowser() && 0 < $(".container-megamenu.vertical .megamenu-wrapper").length) {
              var t = $(".container-megamenu.vertical .megamenu-wrapper").outerHeight(),
                  e = $(".container-megamenu.vertical .megamenu-wrapper").offset().top,
                  i = $("#sidebar").offset().top;
              $("#vermenu_cat_gap").css("height", t - (i - e))
          }
      },
      _handleMegaMenu: function() {
          this._handleVermenuCategory();
          "yes" == window.megamenu_responsive_design && $(window).width() < 992 && (window.megamenu_responsive = !0), $("ul.megamenu > li").each(function() {
              var t = 0;
              $(this).find(".mobile-enabled").each(function() {
                  t++
              }), 0 == t && $(this).find(".open-menu").addClass("mobile-disabled")
          }), $("ul.megamenu li .sub-menu .content .hover-menu ul li").hover(function() {
              $(this).children("ul").addClass("active")
          }, function() {
              $(this).children("ul").removeClass("active")
          }), $(".close-categories").unbind("click"), $(".close-categories").on("click", function() {
              return $(this).parent().removeClass("active"), $(this).next().animate({
                  height: "hide"
              }, 400), !1
          }), $(".open-categories").unbind("click"), $(".open-categories").on("click", function() {
              $(this).parent().parent().find("li").removeClass("active"), $(this).parent().parent().find("ul").animate({
                  height: "hide"
              }, 400), $(this).parent().addClass("active"), $(this).next().next().animate({
                  height: "show"
              }, 400)
          }), $(".close-menu").unbind("click"), $(".close-menu").on("click", function() {
              return $(this).parent().removeClass("active"), $(this).next().next().next().animate({
                  height: "hide"
              }, 400), !1
          }), $(".open-menu").unbind("click"), $(".open-menu").on("click", function() {
              return $("ul.megamenu > li").removeClass("active"), $("ul.megamenu > li").find(".sub-menu").animate({
                  height: "hide"
              }, 400), $(this).parent().addClass("active"), $(this).next().next().animate({
                  height: "show"
              }, 400), $(window).trigger("resize"), !(window.megamenu_responsive = !0)
          }), $("ul.megamenu > li.click .content a").unbind("click"), $("ul.megamenu > li.click .content a").click(function() {
              window.location = $(this).attr("href")
          }), jQuery(window).resize(function() {
              $("ul.megamenu > li.hover").hover(function() {
                  if (0 == window.megamenu_responsive) {
                      if (window.megamenu_active = $(this), window.megamenu_hover = !0, $("ul.megamenu > li").removeClass("active"), $(this).addClass("active"), window.rtl) {
                          $(this).children(".sub-menu").css("right", "auto"), $(this).children(".sub-menu").css("left", "auto"), (e = (t = $(this).children(".sub-menu")).offset().left) < (a = (i = $(".horizontal ul.megamenu")).offset().left - 45) && $(this).children(".sub-menu").css("left", "0")
                      } else {
                          $(this).children(".sub-menu").css("right", "auto");
                          var t = $(this).children(".sub-menu"),
                              e = $(window).width() - (t.offset().left + t.outerWidth());
                          if ($(".header-type-3").length || $(".header-type-30").length) var i = $("#top .container"),
                              a = $(window).width() - (i.offset().left + i.outerWidth());
                          else i = $(".overflow-megamenu"), a = $(window).width() - (i.offset().left + i.outerWidth());
                          e < a && $(this).children(".sub-menu").css("right", "0")
                      }
                      var n = $(this).children("a").outerWidth() / 2,
                          o = $(this).children("a").offset().left - $(this).find(".content").offset().left;
                      $(this).find(".content > .arrow").css("left", o + n)
                  }
              }, function() {
                  if (0 == window.megamenu_responsive) {
                      var t = $(this).attr("title");
                      if (window.megamenu_hover = !1, "hover-intent" == t) {
                          var e = $(this);
                          setTimeout(function() {
                              0 == window.megamenu_hover && $(e).removeClass("active")
                          }, 500)
                      } else $(this).removeClass("active")
                  }
              })
          }).resize(), $("ul.megamenu > li.click").unbind("click"), $("ul.megamenu > li.click").click(function() {
              if (1 == $(this).removeClass("active")) return !1;
              if (window.megamenu_active = $(this), window.megamenu_hover = !0, $("ul.megamenu > li").removeClass("active"), $(this).addClass("active"), 1 == window.megamenu_responsive && $(this).children(".sub-menu").animate({
                      height: "show"
                  }, 400), window.rtl) {
                  $(this).children(".sub-menu").css("right", "auto"), $(this).children(".sub-menu").css("left", "auto"), (e = (t = $(this).children(".sub-menu")).offset().left) < (a = (i = $(".horizontal ul.megamenu")).offset().left - 45) && $(this).children(".sub-menu").css("left", "0")
              } else {
                  $(this).children(".sub-menu").css("right", "auto");
                  var t = $(this).children(".sub-menu"),
                      e = $(window).width() - (t.offset().left + t.outerWidth());
                  if ($(".header-type-3").length) var i = $("#top .container"),
                      a = $(window).width() - (i.offset().left + i.outerWidth());
                  else i = $(".overflow-megamenu"), a = $(window).width() - (i.offset().left + i.outerWidth());
                  e < a && $(this).children(".sub-menu").css("right", "0")
              }
              var n = $(this).children("a").outerWidth() / 2,
                  o = $(this).children("a").offset().left - $(this).find(".content").offset().left;
              return $(this).find(".content > .arrow").css("left", o + n), !1
          }), $(".categories-image-right ul > li > a").hover(function() {
              $(this).closest(".categories-image-right").find("img").attr("src", $(this).attr("data-image"))
          }, function() {
              var t = $(this).closest(".categories-image-right").attr("data-image");
              $(this).closest(".categories-image-right").find("img").attr("src", t)
          }), $(".megaMenuToggle").unbind("click"), $(".megaMenuToggle").click(function() {
              return 1 == $(this).removeClass("active") ? $(this).parent().find(".megamenu-wrapper").stop(!0, !0).animate({
                  height: "hide"
              }, 400) : ($(this).parent().find(".megamenu-wrapper").stop(!0, !0).animate({
                  height: "toggle"
              }, 400), $(this).addClass("active")), !1
          }), $("html").unbind("click"), $("html").on("click", function() {
              "yes" == window.megamenu_responsive_design && $(window).width() < 992 || $("ul.megamenu > li.click").removeClass("active")
          }), $(window).resize(function() {
              window.megamenu_responsive = !1, "yes" == window.megamenu_responsive_design && $(window).width() < 992 && (window.megamenu_responsive = !0)
          }), roar.initLazyLoading(".section-megamenu-content", !0)
      },
      onUnload: function(t) {
          this.$container.off(this.megaMenuNamspace)
      },
      onSelect: function(t) {
          0 < $(this.megaMenuNamspace + " .product-grid.rich-banner").length && roar.initCountdown(), roar.initProductQuickShopItem(this.megaMenuNamspace + " .product-grid.rich-banner"), roar.handleQuickshop(this.megaMenuNamspace + " .product-grid.rich-banner")
      },
      onBlockSelect: function(t) {},
      onBlockDeselect: function(t) {}
  }), t
}(), theme.TopBlockSection = function() {
  function t(t) {
      var e = this.$container = $(t),
          i = this.sectionId = e.attr("data-section-id");
      e.attr("data-section-type");
      this.topBlockId = $("#shopify-section-" + i), this.topBlock = $("#top-block-" + i), this.topBlockNamspace = "#top-block-wrapper-" + i, this._init()
  }
  return t.prototype = _.assignIn({}, t.prototype, {
      _init: function() {},
      onUnload: function(t) {
          this.$container.off(this.topBlockNamspace)
      }
  }), t
}(), theme.CustomWidgetSection = function() {
  function t(t) {
      var e = this.$container = $(t),
          i = this.sectionId = e.attr("data-section-id");
      e.attr("data-section-type");
      this.customWidgetId = $("#shopify-section-" + i), this.customWidgetNamspace = "#custom-widget-" + i, this.placement_fullwidth = $(this.customWidgetNamspace).data("placement_fullwidth"), this._init()
  }
  return t.prototype = _.assignIn({}, t.prototype, {
      _init: function() {
          "1" != this.placement_fullwidth || window.sidebar || onFullWidthOption(this.sectionId)
      },
      onUnload: function(t) {
          this.$container.off(this.customWidgetNamspace)
      }
  }), t
}(), theme.BannerSection = function() {
  function t(t) {
      var e = this.$container = $(t),
          i = this.sectionId = e.attr("data-section-id");
      e.attr("data-section-type");
      this.bannerId = $("#shopify-section-" + i), this.bannerNamspace = "#rich-banners-" + i, this.placement_fullwidth = $(this.bannerNamspace).data("placement_fullwidth"), this.placement_background = $(this.bannerNamspace).data("placement_background"), this._init()
  }
  return t.prototype = _.assignIn({}, t.prototype, {
      _init: function() {
          "1" != this.placement_fullwidth || window.sidebar || onFullWidthOption(this.sectionId);
          this._initFx(), this._handleFontSize(), this._initSlider(), this._initTilt(), "1" == this.placement_background && this._initBackground()
      },
      _initBackground: function() {
          var e = $("#shopify-section-" + this.sectionId),
              i = this.$container.data("placement_background_c"),
              a = this.$container.data("placement_background_i");
          $(window).resize(function() {
              if (e.removeAttr("style"), !($(window).width() < 768)) {
                  var t = e.offset();
                  e.width($("body").width()), e.css("left", "-" + t.left + "px").css("padding-left", t.left).css("padding-right", t.left), e.css("background-color", i).css("background-image", "url(" + a + ")").css("background-size", "cover")
              }
          }).resize()
      },
      _initTilt: function() {
          var t = this.$container.find(".rt-tilt-container");
          t.length <= 0 || (t.on("mousemove", function(t) {
              "use strict";
              var e = $(this).offset().left,
                  i = $(this).offset().top,
                  a = t.pageX - e,
                  n = t.pageY - i,
                  o = $(this).width() / 2 - a,
                  s = $(this).height() / 2 - n;
              $(this).css("transform", "perspective(500px) rotateX(" + s / 40 + "deg) rotateY(" + -o / 40 + "deg) translateZ(10px)");
              Math.sign(o), Math.abs(o);
              $(this).removeClass("rt-leave")
          }), t.on("mouseleave", function() {
              $(this).addClass("rt-leave")
          }))
      },
      _initSlider: function() {
          this.$container.find(".rich-banner--group.is-slider").each(function(t, e) {
              var i = {
                      interval: $(e).data("interval"),
                      autoplay: $(e).data("autoplay"),
                      itemsperslide: $(e).data("itemsperslide"),
                      blockid: $(e).data("blockid"),
                      variablewidth: $(e).data("variablewidth")
                  },
                  a = $(e).not(".slick-initialized");
              a.slick({
                  dots: !1,
                  arrows: !1,
                  slidesToShow: i.itemsperslide,
                  slidesToScroll: 1,
                  autoplay: i.autoplay,
                  autoplaySpeed: i.interval,
                  slide: "div, a.rich-banner-wrapper",
                  variableWidth: i.variablewidth,
                  centerMode: i.variablewidth
              }), $(e).find(".next-button").first().click(function() {
                  return a.slick("slickNext"), !1
              }), $(e).find(".prev-button").first().click(function() {
                  return a.slick("slickPrev"), !1
              }), roar.initLazyLoading("#rich-banner--group" + i.blockid, !0)
          })
      },
      _initFx: function() {
          this.$container.find(".rich-banner.has-text-fx").each(function(t, e) {
              var i = $(e).data("fx"),
                  a = $(e).data("fx-type");
              1 == i && ("0" == a ? anime.timeline({
                  loop: !0
              }).add({
                  targets: $(e).find(".rt-fx-dominos .letter").toArray(),
                  rotateY: [-90, 0],
                  duration: 1300,
                  delay: function(t, e) {
                      return 45 * e
                  }
              }).add({
                  targets: $(e).find(".rt-fx-dominos").toArray(),
                  opacity: 0,
                  duration: 1e3,
                  easing: "easeOutExpo",
                  delay: 1e3
              }) : "1" == a ? anime.timeline({
                  loop: !0
              }).add({
                  targets: $(e).find(".rt-fx-vertical-lines .letter").toArray(),
                  scale: [.3, 1],
                  opacity: [0, 1],
                  translateZ: 0,
                  easing: "easeOutExpo",
                  duration: 600,
                  delay: function(t, e) {
                      return 70 * (e + 1)
                  }
              }).add({
                  targets: $(e).find(".rt-fx-vertical-lines .line").toArray(),
                  scaleX: [0, 1],
                  opacity: [.5, 1],
                  easing: "easeOutExpo",
                  duration: 700,
                  offset: "-=875",
                  delay: function(t, e, i) {
                      return 80 * (i - e)
                  }
              }).add({
                  targets: $(e).find(".rt-fx-vertical-lines").toArray(),
                  opacity: 0,
                  duration: 1e3,
                  easing: "easeOutExpo",
                  delay: 1e3
              }) : "2" == a ? anime.timeline({
                  loop: !0
              }).add({
                  targets: $(e).find(".rt-fx-fading .letter").toArray(),
                  opacity: [0, 1],
                  easing: "easeInOutQuad",
                  duration: 2250,
                  delay: function(t, e) {
                      return 150 * (e + 1)
                  }
              }).add({
                  targets: $(e).find(".rt-fx-fading").toArray(),
                  opacity: 0,
                  duration: 1e3,
                  easing: "easeOutExpo",
                  delay: 1e3
              }) : "3" == a ? anime.timeline({
                  loop: !0
              }).add({
                  targets: $(e).find(".rt-fx-intro .letter").toArray(),
                  translateX: [40, 0],
                  translateZ: 0,
                  opacity: [0, 1],
                  easing: "easeOutExpo",
                  duration: 1200,
                  delay: function(t, e) {
                      return 500 + 30 * e
                  }
              }).add({
                  targets: $(e).find(".rt-fx-intro .letter").toArray(),
                  translateX: [0, -30],
                  opacity: [1, 0],
                  easing: "easeInExpo",
                  duration: 1100,
                  delay: function(t, e) {
                      return 100 + 30 * e
                  }
              }) : "4" == a ? anime.timeline({
                  loop: !0
              }).add({
                  targets: $(e).find(".rt-fx-surprising .word").toArray(),
                  scale: [14, 1],
                  opacity: [0, 1],
                  easing: "easeOutCirc",
                  duration: 800,
                  delay: function(t, e) {
                      return 800 * e
                  }
              }).add({
                  targets: $(e).find(".rt-fx-surprising").toArray(),
                  opacity: 0,
                  duration: 1e3,
                  easing: "easeOutExpo",
                  delay: 1e3
              }) : anime.timeline({
                  loop: !0
              }).add({
                  targets: $(e).find(".rt-fx-typing .line").toArray(),
                  scaleY: [0, 1],
                  opacity: [.5, 1],
                  easing: "easeOutExpo",
                  duration: 700
              }).add({
                  targets: $(e).find(".rt-fx-typing .line").toArray(),
                  translateX: [0, $(e).find(".rt-fx-typing .letters").first().width()],
                  easing: "easeOutExpo",
                  duration: 700,
                  delay: 100
              }).add({
                  targets: $(e).find(".rt-fx-typing .letter").toArray(),
                  opacity: [0, 1],
                  easing: "easeOutExpo",
                  duration: 600,
                  offset: "-=775",
                  delay: function(t, e) {
                      return 34 * (e + 1)
                  }
              }).add({
                  targets: $(e).find(".rt-fx-typing").toArray(),
                  opacity: 0,
                  duration: 1e3,
                  easing: "easeOutExpo",
                  delay: 1e3
              }))
          })
      },
      _handleFontSize: function() {
          var t = this.$container;
          $(window).resize(function() {
              var e = parseInt($(window).width());
              t.find(".self-fontsize-adj").each(function() {
                  if ($(this).css("fontSize", $(this).data("oriFontsize")), e <= 767) {
                      var t = parseInt($(this).data("oriFontsize")) / 2;
                      t = t < 10 ? 10 : t, $(this).css("fontSize", t + "px")
                  }
              }), t.find("a.self-fontsize-adj").each(function() {
                  $(this).css("fontSize", $(this).data("oriFontsize"))
              }), e <= 767 ? (t.find("a.self-fontsize-adj").css("fontSize", ""), t.find("a.self-fontsize-adj").css("padding", "7px 19px 5px")) : t.find("a.self-fontsize-adj").css("padding", "")
          }).resize()
      },
      onUnload: function(t) {
          this.$container.off(this.bannerNamspace)
      },
      onBlockSelect: function(t) {
          console.log(t)
      },
      onSelect: function(t) {
          0 < $(this.bannerNamspace + " .product-grid.rich-banner").length && roar.initCountdown(), roar.initLazyLoading(this.bannerNamspace + " .product-grid.rich-banner", !0), roar.initProductQuickShopItem(this.bannerNamspace + " .product-grid.rich-banner"), roar.handleQuickshop(this.bannerNamspace + " .product-grid.rich-banner")
      }
  }), t
}(), theme.DeliveryBarSection = function() {
  function t(t) {
      var e = this.$container = $(t),
          i = this.sectionId = e.attr("data-section-id");
      e.attr("data-section-type");
      this.deliveryBarId = $("#shopify-section-" + i), this.deliveryBar = $("#delivery-bar-" + i), this.deliveryBarNamspace = "#delivery-bar-" + i, this.placement_fullwidth = $(this.deliveryBarNamspace).data("placement_fullwidth"), this._init()
  }
  return t.prototype = _.assignIn({}, t.prototype, {
      _init: function() {
          "1" != this.placement_fullwidth || window.sidebar || onFullWidthOption(this.sectionId)
      },
      onUnload: function(t) {
          this.$container.off(this.deliveryBarNamspace)
      }
  }), t
}(), theme.SlideShowSection = function() {
  function t(t) {
      var e = this.$container = $(t),
          i = this.sectionId = e.attr("data-section-id");
      e.attr("data-section-type");
      this.slideShowId = $("#shopify-section-" + i), this.slideShow = $("#home-slider-" + i), this.slideShowNamspace = "#home-slider-" + i, this.option = {
          slider_auto: this.slideShow.data("slider_auto"),
          slider_interval: this.slideShow.data("slider_interval"),
          slider_scale: this.slideShow.data("slider_scale"),
          slider_auto_height: this.slideShow.data("slider_auto_height"),
          slider_height: this.slideShow.data("slider_height"),
          slider_align_top: this.slideShow.data("slider_align_top"),
          is_header_slider: this.slideShow.data("is_header_slider"),
          full_width: this.slideShow.data("full_width"),
          is_megamenu: this.slideShow.data("is_megamenu")
      }, this._init()
  }
  return t.prototype = _.assignIn({}, t.prototype, {
      _init: function() {
          "1" == this.option.is_header_slider && ("1" == this.option.slider_align_top ? $(".templateIndex").addClass("slider-align-top") : $(".templateIndex").removeClass("slider-align-top")), this._handleSlideshow(), this._initResize(), "1" != this.option.full_width || window.sidebar || onFullWidthOption(this.sectionId);
          "1" == this.option.is_megamenu && this._handleMegaMenu()
      },
      _handleVermenuCategory: function() {
          if ($("#vermenu_cat_gap").length && 992 <= roar.getWidthBrowser() && 0 < $(".container-megamenu.vertical .megamenu-wrapper").length) {
              var t = $(".container-megamenu.vertical .megamenu-wrapper").outerHeight(),
                  e = $(".container-megamenu.vertical .megamenu-wrapper").offset().top,
                  i = $("#sidebar").offset().top;
              $("#vermenu_cat_gap").css("height", t - (i - e))
          }
      },
      _handleMegaMenu: function() {
          this._handleVermenuCategory();
          "yes" == window.megamenu_responsive_design && $(window).width() < 992 && (window.megamenu_responsive = !0), $("ul.megamenu > li").each(function() {
              var t = 0;
              $(this).find(".mobile-enabled").each(function() {
                  t++
              }), 0 == t && $(this).find(".open-menu").addClass("mobile-disabled")
          }), $("ul.megamenu li .sub-menu .content .hover-menu ul li").hover(function() {
              $(this).children("ul").addClass("active")
          }, function() {
              $(this).children("ul").removeClass("active")
          }), $(".close-categories").unbind("click"), $(".close-categories").on("click", function() {
              return $(this).parent().removeClass("active"), $(this).next().animate({
                  height: "hide"
              }, 400), !1
          }), $(".open-categories").unbind("click"), $(".open-categories").on("click", function() {
              return $(".open-categories").parent().removeClass("active"), $(".open-categories").next().next().animate({
                  height: "hide"
              }, 400), $(this).parent().addClass("active"), $(this).next().next().animate({
                  height: "show"
              }, 400), !1
          }), $(".close-menu").unbind("click"), $(".close-menu").on("click", function() {
              return $(this).parent().removeClass("active"), $(this).next().next().next().animate({
                  height: "hide"
              }, 400), !1
          }), $(".open-menu").unbind("click"), $(".open-menu").on("click", function() {
              return $("ul.megamenu > li").removeClass("active"), $("ul.megamenu > li").find(".sub-menu").animate({
                  height: "hide"
              }, 400), $(this).parent().addClass("active"), $(this).next().next().animate({
                  height: "show"
              }, 400), $(window).trigger("resize"), !(window.megamenu_responsive = !0)
          }), $("ul.megamenu > li.click .content a").unbind("click"), $("ul.megamenu > li.click .content a").click(function() {
              window.location = $(this).attr("href")
          }), $("ul.megamenu > li.hover").hover(function() {
              if (0 == window.megamenu_responsive) {
                  if (window.megamenu_active = $(this), window.megamenu_hover = !0, $("ul.megamenu > li").removeClass("active"), $(this).addClass("active"), window.rtl) {
                      $(this).children(".sub-menu").css("right", "auto"), $(this).children(".sub-menu").css("left", "auto"), (e = (t = $(this).children(".sub-menu")).offset().left) < (a = (i = $(".horizontal ul.megamenu")).offset().left - 45) && $(this).children(".sub-menu").css("left", "0")
                  } else {
                      $(this).children(".sub-menu").css("right", "auto");
                      var t = $(this).children(".sub-menu"),
                          e = $(window).width() - (t.offset().left + t.outerWidth());
                      if ($(".header-type-3").length) var i = $("#top .container"),
                          a = $(window).width() - (i.offset().left + i.outerWidth());
                      else i = $(".overflow-megamenu"), a = $(window).width() - (i.offset().left + i.outerWidth());
                      e < a && $(this).children(".sub-menu").css("right", "0")
                  }
                  var n = $(this).children("a").outerWidth() / 2,
                      o = $(this).children("a").offset().left - $(this).find(".content").offset().left;
                  $(this).find(".content > .arrow").css("left", o + n)
              }
          }, function() {
              if (0 == window.megamenu_responsive) {
                  var t = $(this).attr("title");
                  if (window.megamenu_hover = !1, "hover-intent" == t) {
                      var e = $(this);
                      setTimeout(function() {
                          0 == window.megamenu_hover && $(e).removeClass("active")
                      }, 500)
                  } else $(this).removeClass("active")
              }
          }), $("ul.megamenu > li.click").unbind("click"), $("ul.megamenu > li.click").click(function() {
              if (1 == $(this).removeClass("active")) return !1;
              if (window.megamenu_active = $(this), window.megamenu_hover = !0, $("ul.megamenu > li").removeClass("active"), $(this).addClass("active"), 1 == window.megamenu_responsive && $(this).children(".sub-menu").animate({
                      height: "show"
                  }, 400), window.rtl) {
                  $(this).children(".sub-menu").css("right", "auto"), $(this).children(".sub-menu").css("left", "auto"), (e = (t = $(this).children(".sub-menu")).offset().left) < (a = (i = $(".horizontal ul.megamenu")).offset().left - 45) && $(this).children(".sub-menu").css("left", "0")
              } else {
                  $(this).children(".sub-menu").css("right", "auto");
                  var t = $(this).children(".sub-menu"),
                      e = $(window).width() - (t.offset().left + t.outerWidth());
                  if ($(".header-type-3").length) var i = $("#top .container"),
                      a = $(window).width() - (i.offset().left + i.outerWidth());
                  else i = $(".overflow-megamenu"), a = $(window).width() - (i.offset().left + i.outerWidth());
                  e < a && $(this).children(".sub-menu").css("right", "0")
              }
              var n = $(this).children("a").outerWidth() / 2,
                  o = $(this).children("a").offset().left - $(this).find(".content").offset().left;
              return $(this).find(".content > .arrow").css("left", o + n), !1
          }), $(".categories-image-right ul > li > a").hover(function() {
              $(this).closest(".categories-image-right").find("img").attr("src", $(this).attr("data-image"))
          }, function() {
              var t = $(this).closest(".categories-image-right").attr("data-image");
              $(this).closest(".categories-image-right").find("img").attr("src", t)
          }), $(".megaMenuToggle").unbind("click"), $(".megaMenuToggle").click(function() {
              return 1 == $(this).removeClass("active") ? $(this).parent().find(".megamenu-wrapper").stop(!0, !0).animate({
                  height: "hide"
              }, 400) : ($(this).parent().find(".megamenu-wrapper").stop(!0, !0).animate({
                  height: "toggle"
              }, 400), $(this).addClass("active")), !1
          }), $("html").unbind("click"), $("html").on("click", function() {
              "yes" == window.megamenu_responsive_design && $(window).width() < 992 || $("ul.megamenu > li.click").removeClass("active")
          }), $(window).resize(function() {
              window.megamenu_responsive = !1, "yes" == window.megamenu_responsive_design && $(window).width() < 992 && (window.megamenu_responsive = !0)
          })
      },
      _handleSlideshow: function() {
          var i, a, n, o, s, r, c, l;
          if (this.slideShow.length) {
              var t = this.slideShow;
              i = t.data("afx-head"), a = t.data("afx-cap"), n = t.data("afx-cta"), o = t.data("afx-sticker"), s = t.data("dfx-head"), r = t.data("dfx-cap"), c = t.data("dfx-cta"), l = t.data("dfx-sticker")
          }
          var e, d = this.slideShowNamspace,
              h = this.option.slider_auto,
              u = this.option.slider_interval,
              p = this.option.slider_scale,
              f = this;
          this.slideShow.length && (e = this.slideShow.flexslider({
              animation: "fade",
              prevText: "",
              nextText: "",
              controlNav: !1,
              directionNav: !1,
              slideshowSpeed: u,
              slideshow: h,
              start: function(t) {
                  jQuery("body").removeClass("loading"), jQuery(d + " ul.slides h2.caption-content").css("opacity", "0"), jQuery(d + " ul.slides .real-caption").css("opacity", "0"), jQuery(d + " ul.slides .caption-link").css("opacity", "0"), jQuery(d + " ul.slides .slide-sticker-wrapper img").css("opacity", "0"), jQuery(d + " ul.slides li:nth-child(1) h2.caption-content").css("opacity", "1.0").addClass("rt-animated " + i).one("webkitAnimationEnd mozAnimationEnd MSAnimationEnd oanimationend animationend", function() {
                      $(this).removeClass("rt-animated " + i)
                  }), jQuery(d + " ul.slides li:nth-child(1) .real-caption").css("opacity", "1.0").addClass("rt-animated " + a).one("webkitAnimationEnd mozAnimationEnd MSAnimationEnd oanimationend animationend", function() {
                      $(this).removeClass("rt-animated " + a)
                  }), jQuery(d + " ul.slides li:nth-child(1) .caption-link").css("opacity", "1.0").addClass("rt-animated " + n).one("webkitAnimationEnd mozAnimationEnd MSAnimationEnd oanimationend animationend", function() {
                      $(this).removeClass("rt-animated " + n)
                  }), jQuery(d + " ul.slides li:nth-child(1) .slide-sticker-wrapper img").css("opacity", "1.0").addClass("rt-animated " + o).one("webkitAnimationEnd mozAnimationEnd MSAnimationEnd oanimationend animationend", function() {
                      $(this).removeClass("rt-animated " + o)
                  })
              },
              after: function(t) {
                  var e = parseInt(t.currentSlide, 10) + 1;
                  jQuery(d + " ul.slides li:nth-child(" + e + ") h2.caption-content").css("opacity", "1.0").addClass("rt-animated " + i).one("webkitAnimationEnd mozAnimationEnd MSAnimationEnd oanimationend animationend", function() {
                      $(this).removeClass("rt-animated " + i)
                  }), jQuery(d + " ul.slides li:nth-child(" + e + ") .real-caption").css("opacity", "1.0").addClass("rt-animated " + a).one("webkitAnimationEnd mozAnimationEnd MSAnimationEnd oanimationend animationend", function() {
                      $(this).removeClass("rt-animated " + a)
                  }), jQuery(d + " ul.slides li:nth-child(" + e + ") .caption-link").css("opacity", "1.0").addClass("rt-animated " + n).one("webkitAnimationEnd mozAnimationEnd MSAnimationEnd oanimationend animationend", function() {
                      $(this).removeClass("rt-animated " + n)
                  }), jQuery(d + " ul.slides li:nth-child(" + e + ") .slide-sticker-wrapper img").css("opacity", "1.0").addClass("rt-animated " + o).one("webkitAnimationEnd mozAnimationEnd MSAnimationEnd oanimationend animationend", function() {
                      $(this).removeClass("rt-animated " + o)
                  })
              },
              before: function(t) {
                  var e = parseInt(t.currentSlide, 10) + 1;
                  jQuery(d + " ul.slides li:nth-child(" + e + ") h2.caption-content").addClass("rt-animated " + s).one("webkitAnimationEnd mozAnimationEnd MSAnimationEnd oanimationend animationend", function() {
                      $(this).removeClass("rt-animated " + s).css("opacity", "0")
                  }), jQuery(d + " ul.slides li:nth-child(" + e + ") .real-caption").addClass("rt-animated " + r).one("webkitAnimationEnd mozAnimationEnd MSAnimationEnd oanimationend animationend", function() {
                      $(this).removeClass("rt-animated " + r).css("opacity", "0")
                  }), jQuery(d + " ul.slides li:nth-child(" + e + ") .caption-link").addClass("rt-animated " + c).one("webkitAnimationEnd mozAnimationEnd MSAnimationEnd oanimationend animationend", function() {
                      $(this).removeClass("rt-animated " + c).css("opacity", "0")
                  }), jQuery(d + " ul.slides li:nth-child(" + e + ") .slide-sticker-wrapper img").addClass("rt-animated " + l).one("webkitAnimationEnd mozAnimationEnd MSAnimationEnd oanimationend animationend", function() {
                      $(this).removeClass("rt-animated " + l).css("opacity", "0")
                  })
              }
          }), imagesLoaded(d, function() {
              p ? f._mockupCaptionSlider2() : f._mockupCaptionSlider()
          })), this.slideShow.find(".flex-direction-nav .flex-next").click(function(t) {
              return t.preventDefault(), t.stopPropagation(), e.flexslider("next"), !1
          }), this.slideShow.find(".flex-direction-nav .flex-prev").click(function(t) {
              return t.preventDefault(), t.stopPropagation(), e.flexslider("prev"), !1
          })
      },
      _mockupCaptionSlider2: function() {
          if (this.slideShow.length) {
              var t = this.slideShowNamspace,
                  i = roar.getWidthBrowser();
              $(t + " .slide-body").each(i < 1200 ? function() {
                  var t = $(this).data("height") * i / 1200;
                  $(this).css({
                      height: t
                  })
              } : function() {
                  var t = $(this).data("height");
                  $(this).css({
                      height: t
                  })
              }), $(t + " .caption-content").each(i < 1200 ? function() {
                  var t = $(this).data("min"),
                      e = $(this).data("max") * i / 1200;
                  e < t && (e = t), $(this).css({
                      "font-size": e
                  })
              } : function() {
                  var t = $(this).data("max");
                  $(this).css({
                      "font-size": t
                  })
              })
          }
      },
      _mockupCaptionSlider: function() {
          if (this.slideShow.length) {
              var t = this.slideShowNamspace,
                  e = this.option.slider_auto_height,
                  i = this.option.slider_height,
                  a = roar.getWidthBrowser();
              if (a < 767 && 0 == e && 0 < i) {
                  var n = i * a / 1200;
                  $(t + " .slide-body").css("height", n)
              }
              767 <= a && 0 == e && 0 < i && $(t + " .slide-body").css("height", i), $(t + " .caption-content").each(a < 767 ? function() {
                  var t = $(this).data("min"),
                      e = $(this).data("max"),
                      i = e;
                  50 < e && (i = 50), i < t && (i = t), $(this).css({
                      "font-size": i
                  })
              } : function() {
                  var t = $(this).data("max");
                  $(this).css({
                      "font-size": t
                  })
              })
          }
      },
      _initResize: function() {
          var t = this.option.slider_scale,
              e = this;
          jQuery(window).resize(function() {
              t ? e._mockupCaptionSlider2() : e._mockupCaptionSlider()
          })
      },
      onUnload: function(t) {
          this.$container.off(this.slideShowNamspace)
      }
  }), t
}(), theme.SidebarSection = function() {
  function t(t) {
      var e = this.$container = $(t),
          i = this.sectionId = e.attr("data-section-id");
      e.attr("data-section-type");
      this.sideBarId = $("#shopify-section-" + i), this.sideBar = $("#sidebar-" + i), this.sideBarNamspace = "#sidebar-" + i, this.tabSideBar = $(".tab-filter-tabs" + i + " a"), this.tabItem = $(".procduct_tab_item-" + i), this._init()
  }
  return t.prototype = _.assignIn({}, t.prototype, {
      _init: function() {
          var e = this;
          0 < this.tabItem.length && this.tabItem.each(function() {
              var t = {
                  _tabcount: $(this).data("_tabcount"),
                  _ptab_carousel: $(this).data("_ptab_carousel"),
                  _id: $(this).data("_id")
              };
              0 < parseInt(t._tabcount) ? (e._initTab(), t._ptab_carousel && e._initMultiSlide(t), e._initMultiSlides(t)) : (t._ptab_carousel && e._initSlide(t), e._initSlides(t))
          })
      },
      _initTab: function() {
          this.tabSideBar.each(function() {
              $(this).click(function(t) {
                  t.preventDefault(), $(this).tab("show")
              })
          })
      },
      _initSlide: function(t) {
          var e = $(".box #myCarousel" + t._id + " .carousel-inner");
          $("#myCarousel" + t._id + "_next").click(function() {
              return e.trigger("next.owl.carousel"), !1
          }), $("#myCarousel" + t._id + "_prev").click(function() {
              return e.trigger("prev.owl.carousel"), !1
          }), e.owlCarousel({
              slideSpeed: 500,
              items: 1,
              rtl: window.rtl
          })
      },
      _initSlides: function(t) {
          var e = $(".box #myCarousel" + t._id + "s .carousel-inner");
          e.owlCarousel({
              slideSpeed: 500,
              rtl: window.rtl,
              responsive: {
                  0: {
                      items: 1
                  },
                  320: {
                      items: 1
                  },
                  479: {
                      items: 1
                  },
                  767: {
                      items: 1
                  },
                  979: {
                      items: 1
                  },
                  1199: {
                      items: 1
                  }
              }
          }), $("#myCarousel" + t._id + "s_next").click(function() {
              return e.trigger("next.owl.carousel"), !1
          }), $("#myCarousel" + t._id + "s_prev").click(function() {
              return e.trigger("prev.owl.carousel"), !1
          })
      },
      _initMultiSlide: function(t) {
          var e = $(".filter-product #myCarousel" + t._id + " .carousel-inner");
          $("#myCarousel" + t._id + "_next").click(function() {
              return e.trigger("next.owl.carousel"), !1
          }), $("#myCarousel" + t._id + "_prev").click(function() {
              return e.trigger("prev.owl.carousel"), !1
          }), e.owlCarousel({
              slideSpeed: 500,
              items: 1,
              rtl: window.rtl
          })
      },
      _initMultiSlides: function(t) {
          var e = $(".filter-product #myCarousel" + t._id + "s .carousel-inner");
          $("#myCarousel" + t._id + "s_next").click(function() {
              return e.trigger("next.owl.carousel"), !1
          }), $("#myCarousel" + t._id + "s_prev").click(function() {
              return e.trigger("prev.owl.carousel"), !1
          }), e.owlCarousel({
              slideSpeed: 500,
              rtl: window.rtl,
              responsive: {
                  0: {
                      items: 1
                  },
                  320: {
                      items: 1
                  },
                  479: {
                      items: 1
                  },
                  767: {
                      items: 1
                  },
                  979: {
                      items: 1
                  },
                  1199: {
                      items: 1
                  }
              }
          })
      },
      onUnload: function(t) {
          this.$container.off(this.sideBarNamspace)
      }
  }), t
}(), theme.ProductTabSection = function() {
  function t(t) {
      var e = this.$container = $(t),
          i = this.sectionId = e.attr("data-section-id");
      e.attr("data-section-type");
      this.productTabId = $("#shopify-section-" + i), this.productTab = $("#product-tab-" + i), this.productTabNamspace = "#product-tab-" + i, this.tabProductTabVertical = $(".tab-filter-tabs-vertical-" + i + " a"), this.tabProductTab = $(".tab-filter-tabs-" + i + " a"), this.tabItem = $(".product-tab-item-" + i), this._tabcount = this.productTab.data("_tabcount"), this.placement_fullwidth = this.productTab.data("placement_fullwidth"), this._init()
  }
  return t.prototype = _.assignIn({}, t.prototype, {
      _init: function() {
          var e = this,
              i = this._tabcount;
          0 < this.tabItem.length && this.tabItem.each(function() {
              var t = {
                  _tabcount: i,
                  _ptab_carousel: $(this).data("_ptab_carousel"),
                  _id: $(this).data("_id"),
                  _nextpage: $(this).data("_nextpage"),
                  _itemsperpage: $(this).data("_itemsperpage"),
                  _limit: parseInt($(this).data("_limit"), 10),
                  _colclass: $(this).data("_colclass"),
                  _catid: $(this).data("_catid"),
                  _all_loaded: !1,
                  _loaded_count: parseInt($(this).data("_itemsperpage"), 10)
              };
              e._initTab(), e._initMultiSlide(t)
          }), "1" != this.placement_fullwidth || window.sidebar || onFullWidthOption(this.sectionId)
      },
      _initTab: function() {
          0 < this.tabProductTab.length && this.tabProductTab.each(function() {
              $(this).click(function(t) {
                  t.preventDefault(), $(this).tab("show")
              })
          }), 0 < this.tabProductTabVertical.length && this.tabProductTabVertical.each(function() {
              $(this).click(function(t) {
                  t.preventDefault(), $(this).tab("show")
              })
          })
      },
      _initMultiSlide: function(r) {
          var i = 1,
              a = 0;
          if (r._ptab_carousel) {
              var c = $(".filter-product #myCarousel" + r._id),
                  l = $(".filter-product #myCarousel" + r._id + " .carousel-inner");
              l.slick({
                  autoplaySpeed: 500,
                  rtl: window.rtl,
                  slidesToShow: 1,
                  arrows: !1,
                  infinite: !1
              }), l.on("reInit ", function(t, e) {
                  i = e.slideCount
              }), l.on("afterChange", function(t, e) {
                  a = e.currentSlide
              }), $("#myCarousel" + r._id + "_next").click(function() {
                  return i == a + 1 && "" != r._catid && 0 == r._all_loaded && r._loaded_count < r._limit ? (console.log("There we go..."), c.addClass("b-loading"), $.ajax({
                      url: "/collections/" + r._catid,
                      type: "get",
                      dataType: "html",
                      data: {
                          section_id: "collection-customlim",
                          limit: r._itemsperpage + "a" + r._colclass,
                          page: r._nextpage
                      },
                      success: function(t) {
                          var e = t.trim();
                          if ("" == e) r._all_loaded = !0;
                          else {
                              var i = $(e),
                                  a = "row-" + r._id + "-" + r._nextpage,
                                  n = i.find(".row").first().attr("id", a).children();
                              if (r._loaded_count + n.length <= r._limit) ++r._nextpage, r._loaded_count += n.length;
                              else {
                                  for (var o = r._loaded_count + n.length - r._limit, s = 0; s < o; s++) n.last().remove(), n = i.find(".row").first().children();
                                  r._loaded_count = r._limit
                              }
                              l.slick("slickAdd", i[0].outerHTML), l.slick("slickNext"), roar.initCountdown(), roar.initLazyLoading("#" + a, !0), roar.initProductQuickShopItem("#" + a), roar.handleQuickshop("#" + a), window.show_multiple_currencies && theme.CurrencyPicker.convert("#sandbox .money")
                          }
                          c.removeClass("b-loading")
                      },
                      error: function() {
                          console.log("Something went wrong")
                      }
                  })) : l.slick("slickNext"), !1
              }), $("#myCarousel" + r._id + "_prev").click(function() {
                  return l.slick("slickPrev"), !1
              })
          }
      },
      onUnload: function(t) {
          this.$container.off(this.productTabNamspace)
      }
  }), t
}(), theme.AdvancedGridSection = function() {
  function t(t) {
      var e = this.$container = $(t),
          i = this.sectionId = e.attr("data-section-id");
      e.attr("data-section-type");
      this.advancedGridId = $("#shopify-section-" + i), this.advancedGrid = $("#advanced-grid-" + i), this.advancedGridNamspace = "#advanced-grid-" + i, this._ag_bgtype = this.advancedGrid.data("_ag_bgtype"), this._ag_fullwidth = this.advancedGrid.data("_ag_fullwidth"), this._agProductsCarousel = $(".myProductsCarousel-" + i), this._init()
  }
  return t.prototype = _.assignIn({}, t.prototype, {
      _init: function() {
          this._ag_fullwidth && !window.sidebar && onFullWidthOption(this.sectionId);
          "2" == this._ag_bgtype && this._initParalax(), this._initProductTab(), this._initProductsSlide(), this._initCountdown()
      },
      _initCountdown: function() {
          0 < $(".ag_product_countdown").length && $(".ag_product_countdown").each(function() {
              var t = parseInt($(this).data("offer_date_year")),
                  e = parseInt($(this).data("offer_date_month")),
                  i = parseInt($(this).data("offer_date_day")),
                  a = new Date,
                  n = new Date(t, e - 1, i);
              a < n ? $(this).countdown({
                  until: n
              }) : $(this).hide()
          })
      },
      _initParalax: function() {
          var t = this.sectionId;
          $(".advanced-grid-" + t + " .parallax-window").scrolly({
              bgParallax: !0
          })
      },
      _initProductsSlide: function() {
          0 < this._agProductsCarousel.length && this._agProductsCarousel.each(function() {
              var t = $(this),
                  e = t.data("_skin_type"),
                  i = t.data("_id");
              "sportwinter" == e ? t.owlCarousel({
                  slideSpeed: 500,
                  items: 1,
                  rtl: window.rtl
              }) : t.owlCarousel({
                  responsive: {
                      0: {
                          items: window.pitem_row
                      },
                      320: {
                          items: window.pitem_row
                      },
                      479: {
                          items: 2
                      },
                      767: {
                          items: 3
                      },
                      979: {
                          items: 4
                      },
                      1199: {
                          items: 5
                      }
                  },
                  rtl: window.rtl
              }), $("#myCarousel" + i + "_next").click(function() {
                  return t.trigger("next.owl.carousel"), !1
              }), $("#myCarousel" + i + "_prev").click(function() {
                  return t.trigger("prev.owl.carousel"), !1
              })
          })
      },
      _initProductTab: function() {
          var t = this.sectionId,
              e = this;
          $(".ag-products-tabs-" + t).each(function() {
              $(this).data("_tabcount");
              var t = $(this).data("_block_id");
              e._initTab(t), e._initMultiSlide(t)
          })
      },
      _initTab: function(t) {
          0 < $(".tab-filter-tabs-" + t).length && $(".tab-filter-tabs-" + t + " a").each(function() {
              $(this).click(function(t) {
                  t.preventDefault(), $(this).tab("show")
              })
          })
      },
      _initMultiSlide: function(t) {
          0 < $(".ag-product-tab-item-" + t).length && $(".ag-product-tab-item-" + t).each(function() {
              var r = $(this).data("_pid"),
                  t = $(this).data("_acm_carousel"),
                  e = $(this).data("_catid"),
                  c = $(this).data("_nextpage"),
                  i = $(this).data("_itemsperpage"),
                  l = parseInt($(this).data("_limit"), 10),
                  a = $(this).data("_colclass"),
                  d = !1,
                  h = parseInt($(this).data("_itemsperpage"), 10),
                  n = 1,
                  o = 0;
              if (t) {
                  var u = $(".filter-product #myCarousel" + r),
                      p = $(".filter-product #myCarousel" + r + " .carousel-inner");
                  p.slick({
                      autoplaySpeed: 500,
                      rtl: window.rtl,
                      slidesToShow: 1,
                      arrows: !1,
                      infinite: !1
                  }), p.on("reInit ", function(t, e) {
                      n = e.slideCount
                  }), p.on("afterChange", function(t, e) {
                      o = e.currentSlide
                  }), $("#myCarousel" + r + "_next").click(function() {
                      return n == o + 1 && "" != e && 0 == d && h < l ? (u.addClass("b-loading"), $.ajax({
                          url: "/collections/" + e,
                          type: "get",
                          dataType: "html",
                          data: {
                              section_id: "collection-customlim",
                              limit: i + "a" + a,
                              page: c
                          },
                          success: function(t) {
                              var e = t.trim();
                              if ("" == e) d = !0;
                              else {
                                  var i = $(e),
                                      a = "row-" + r + "-" + c,
                                      n = i.find(".row").first().attr("id", a).children();
                                  if (h + n.length <= l) ++c, h += n.length;
                                  else {
                                      for (var o = h + n.length - l, s = 0; s < o; s++) n.last().remove(), n = i.find(".row").first().children();
                                      h = l
                                  }
                                  p.slick("slickAdd", i[0].outerHTML), p.slick("slickNext"), roar.initCountdown(), roar.initLazyLoading("#" + a, !0), roar.initProductQuickShopItem("#" + a), roar.handleQuickshop("#" + a), window.show_multiple_currencies && theme.CurrencyPicker.convert("#sandbox .money")
                              }
                              u.removeClass("b-loading")
                          },
                          error: function() {
                              console.log("Something went wrong")
                          }
                      })) : p.slick("slickNext"), !1
                  }), $("#myCarousel" + r + "_prev").click(function() {
                      return p.slick("slickPrev"), !1
                  })
              }
          })
      },
      onUnload: function(t) {
          this.$container.off(this.advancedGridNamspace)
      }
  }), t
}(), theme.PrefaceFooterSection = function() {
  function t(t) {
      var e = this.$container = $(t),
          i = this.sectionId = e.attr("data-section-id");
      e.attr("data-section-type");
      this.prefaceFooterId = $("#shopify-section-" + i), this.prefaceFooter = $("#preface-footer-" + i), this.prefaceFooterNamspace = "#preface-footer-" + i, this._init()
  }
  return t.prototype = _.assignIn({}, t.prototype, {
      _init: function() {},
      onUnload: function(t) {
          this.$container.off(this.prefaceFooterNamspace)
      }
  }), t
}(), theme.FooterTopSection = function() {
  function t(t) {
      var e = this.$container = $(t),
          i = this.sectionId = e.attr("data-section-id");
      e.attr("data-section-type");
      this.footerTopId = $("#shopify-section-" + i), this.footerTop = $("#footer-top-" + i), this.footerTopNamspace = "#footer-top-" + i, this._init()
  }
  return t.prototype = _.assignIn({}, t.prototype, {
      _init: function() {},
      onUnload: function(t) {
          this.$container.off(this.footerTopNamspace)
      }
  }), t
}(), theme.FooterBottomSection = function() {
  function t(t) {
      var e = this.$container = $(t),
          i = this.sectionId = e.attr("data-section-id");
      e.attr("data-section-type");
      this.footerTopId = $("#shopify-section-" + i), this.footerTop = $("#footer-top-" + i), this.footerTopNamspace = "#footer-top-" + i, this._init()
  }
  return t.prototype = _.assignIn({}, t.prototype, {
      _init: function() {},
      onUnload: function(t) {
          this.$container.off(this.footerTopNamspace)
      }
  }), t
}(), theme.FooterCopyRightSection = function() {
  function t(t) {
      var e = this.$container = $(t),
          i = this.sectionId = e.attr("data-section-id");
      e.attr("data-section-type");
      this.footerCopyRightId = $("#shopify-section-" + i), this.footerCopyRight = $("#footer-copyright-" + i), this.footerCopyRightNamspace = "#footer-copyright-" + i, this._init()
  }
  return t.prototype = _.assignIn({}, t.prototype, {
      _init: function() {},
      onUnload: function(t) {
          this.$container.off(this.footerCopyRightNamspace)
      }
  }), t
}(), theme.FooterColumn = function() {
  function t(t) {
      var e = this.$container = $(t),
          i = this.sectionId = e.attr("data-section-id");
      e.attr("data-section-type");
      this.footerColumnId = $("#shopify-section-" + i), this.footerColumn = $("#footer-column-" + i), this.footerColumnNamspace = "#footer-column-" + i, this._class = this.footerColumn.data("_class"), this._init()
  }
  return t.prototype = _.assignIn({}, t.prototype, {
      _init: function() {
          "" != this._class && this.footerColumnId.addClass(this._class)
      },
      onUnload: function(t) {
          this.$container.off(this.footerColumnNamspace)
      }
  }), t
}(), theme.TestimonialSection = function() {
  function t(t) {
      var e = this.$container = $(t),
          i = this.sectionId = e.attr("data-section-id");
      e.attr("data-section-type");
      this.testimonialId = $("#shopify-section-" + i), this.testimonial = $("#testimonial-" + i), this.testimonialNamspace = "#testimonial-" + i, this.placement_fullwidth = this.testimonial.data("placement_fullwidth"), this._init()
  }
  return t.prototype = _.assignIn({}, t.prototype, {
      _init: function() {
          var t = this.sectionId,
              e = $(".box #myCarousel_testi_" + t + " .testimonial-slide"),
              i = !1;
          1 == parseInt(window.rtl) && (i = !0), e.not(".slick-initialized").slick({
              arrows: !1,
              slidesToShow: 1,
              slidesToScroll: 1,
              rtl: i
          }), $("#myCarousel_testi_next_" + t).click(function() {
              return e.slick("slickNext"), !1
          }), $("#myCarousel_testi_prev_" + t).click(function() {
              return e.slick("slickPrev"), !1
          }), $(window).resize(function() {
              e.slick("setPosition")
          }), "1" != this.placement_fullwidth || window.sidebar || onFullWidthOption(t = this.sectionId)
      },
      onUnload: function(t) {
          this.$container.off(this.testimonialNamspace)
      }
  }), t
}(), theme.LatestBlogSection = function() {
  function t(t) {
      var e = this.$container = $(t),
          i = this.sectionId = e.attr("data-section-id");
      e.attr("data-section-type");
      this.latestBlogId = $("#shopify-section-" + i), this.latestBlog = $("#latest_blog-" + i), this.latestBlogSlider = $("#latest_blog-" + i + " .blog-slick-slider"), this.latestBlogNamspace = "#latest_blog-" + i, this.placement_fullwidth = this.latestBlog.data("placement_fullwidth"), this._init()
  }
  return t.prototype = _.assignIn({}, t.prototype, {
      _init: function() {
          "1" != this.placement_fullwidth || window.sidebar || onFullWidthOption(this.sectionId);
          this._initSlide()
      },
      _initSlide: function() {
          var t = !1;
          1 == parseInt(window.rtl) && (t = !0), 0 < this.latestBlogSlider.length && this.latestBlogSlider.not(".slick-initialized").slick({
              rtl: t,
              slidesToShow: 3,
              slidesToScroll: 1,
              prevArrow: '<a class="prev-button arrow-btn" href="#"><svg><use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#global__symbols-prev"></use></svg></a>',
              nextArrow: '<a class="next-button arrow-btn" href="#"><svg><use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#global__symbols-next"></use></svg></a>',
              responsive: [{
                  breakpoint: 767,
                  settings: {
                      slidesToShow: 1,
                      slidesToScroll: 1
                  }
              }]
          })
      },
      onUnload: function(t) {
          this.$container.off(this.latestBlogNamspace)
      }
  }), t
}(), theme.InstafeedSection = function() {
  function t(t) {
      var e = this.$container = $(t),
          i = this.sectionId = e.attr("data-section-id");
      e.attr("data-section-type");
      this.instafeedId = $("#shopify-section-" + i), this.instafeed = $("#home-instagram-widget-" + i), this.instafeedNamspace = "#home-instagram-widget-" + i, this.instagram_list = $("#instagram_home_" + i), this.instagram_target = "#instagram_home_" + i, this.placement_fullwidth = this.instafeed.data("placement_fullwidth"), this._init()
  }
  return t.prototype = _.assignIn({}, t.prototype, {
      _init: function() {
          var i = this;
          if ("IntersectionObserver" in window && "IntersectionObserverEntry" in window && "intersectionRatio" in window.IntersectionObserverEntry.prototype) {
              var t = new IntersectionObserver(function(t, e) {
                      t.forEach(function(t) {
                          if (t.isIntersecting) {
                              if ("1" == i.placement_fullwidth && !window.sidebar) onFullWidthOption(i.sectionId);
                              0 < i.instagram_list.length && (i.instagram_list.hasClass("home-instafeed-api") ? i._instafeedAPI() : i._instafeedRun())
                          }
                      })
                  }),
                  e = document.querySelector(i.instafeedNamspace);
              t.observe(e)
          }
      },
      _instafeedAPI: function() {
          var t = this.instagram_target.replace("#", ""),
              e = this.instagram_list.data("social_instagram_token"),
              i = this.instagram_list.data("user_id"),
              a = this.instagram_list.data("home_instafeed_limit");
          new Instafeed({
              get: "user",
              target: t,
              accessToken: e,
              userId: i,
              limit: a,
              resolution: "standard_resolution",
              resolution2: "standard_resolution",
              template: '<div class="wrap animated"><a target="_blank" href="{{link}}"><img src="{{image}}" alt="{{caption}}" width="150" height="150" /><span class="hover_border"></span></a></div>'
          }).run()
      },
      _instafeedRun: function() {
          var t = this.instagram_target,
              e = this.instagram_list.data("uid"),
              i = this.instagram_list.data("limit"),
              a = this.instagram_list.data("row_limit");
          $.instagramFeed({
              username: e,
              container: t,
              display_profile: !1,
              display_biography: !1,
              display_gallery: !0,
              callback: null,
              styling: !0,
              items: i,
              items_per_row: a,
              margin: .1
          })
      },
      onUnload: function(t) {
          this.$container.off(this.instafeedNamspace)
      }
  }), t
}(), theme.mobileNavSection = function() {
  function t(t) {
      var e = this.$container = $(t),
          i = this.sectionId = e.attr("data-section-id");
      e.attr("data-section-type");
      this.mobileNavId = $("#shopify-section-" + i), this.mobileNav = $("#primary-" + i), this.mobilenavNamespace = "#primary-" + i, this._init()
  }
  return t.prototype = _.assignIn({}, t.prototype, {
      _init: function() {
          this._initMobile()
      },
      _initMobile: function() {
          $("#off-canvas-layer").on("click", function(t) {
              $(document.body).removeClass("open-canvas-panel"), $(document.body).removeClass("open_filter")
          }), $(".mobile-nav-icon").on("click", function(t) {
              $(document.body).toggleClass("open-canvas-panel")
          }), $(".mobile-child-menu").on("click", function() {
              $(this).closest(".menu-item-has-children").toggleClass("mobile-active")
          }), $(".mobile-nav-search, .mobile-nav-search-close").on("click", function(t) {
              $(document.body).toggleClass("open-search-form"), $(".mobile-nav-search-form input").focus()
          }), $(window).on("resize", function() {
              991 < $(window).width() && $(document.body).removeClass("open-canvas-panel")
          })
      },
      onUnload: function(t) {
          this.$container.off(this.mobilenavNamespace)
      }
  }), t
}(), theme.ProductVariantMobile = function() {
  function t(t) {
      var e = this.$container = $(t),
          i = this.sectionId = e.attr("data-section-id");
      e.attr("data-section-type");
      this.wrapperId = $("#" + i), this.wrapper = $("#" + i), this.wrapperNamspace = "#" + i, this.addCartId = $("#btn-" + i + ".m-allow-cart"), this.addCartClass = $(".variant-item-" + i + ".m-allow-cart"), this._init()
  }
  return t.prototype = _.assignIn({}, t.prototype, {
      _init: function() {
          var t = this;
          t._initScroll(), t._initCompact(), t._initEvents(), $(window).resize(function() {
              $(window).width() <= 991 && t._initCompact()
          })
      },
      _initScroll: function() {
          $(window).on("scroll", function() {
              var t = $("#shopify-section-product-variants-mobile").height();
              $(window).scrollTop() > t ? $(document.body).addClass("sticky-product-variants-mobile") : ($(document.body).removeClass("sticky-product-variants-mobile"), $(".product-variants-mobile").hasClass("active") && $(".product-variants-mobile").height($(".variants-header").data("height")))
          })
      },
      _initCompact: function() {
          if (0 < $(".product-variant-mobile-section").length) {
              var t = $(".product-variant-mobile-section"),
                  a = $(".product-variants-mobile");
              a.each(function() {
                  var t = $(this),
                      e = t.find(".variants-header"),
                      i = e.innerHeight(),
                      a = t.find(".variants-content").outerHeight();
                  e.closest(".product-variants-mobile");
                  e.data("height", i), t.data("height", i + a)
              }), a.each(function() {
                  var t = $(this),
                      e = t.find(".variants-header"),
                      i = e.innerHeight(),
                      a = t.find(".variants-content").outerHeight(),
                      n = e.closest(".product-variants-mobile");
                  e.data("height", i), t.data("height", i + a), n.hasClass("active") && n.height(n.data("height"))
              }), t.unbind("click") && t.on("click", ".variants-header .title", function() {
                  var t = $(this),
                      e = t.closest(".variants-header"),
                      i = t.closest(".product-variants-mobile");
                  i.hasClass("active") || a.closest(".active").removeClass("active").height(t.data("height")), i.toggleClass("active"), i.hasClass("active") ? i.height(i.data("height")) : i.height(e.data("height"))
              })
          }
      },
      _initEvents: function() {
          var t = $("#ProductSelect-product-template.variation-select").val();
          0 < this.addCartId.length && (this.addCartId.unbind("click"), this.addCartId.on("click", function() {
              $("#ProductSelect-product-template.variation-select").val(t), $("#AddToCart-product-template").trigger("click")
          })), 0 < this.addCartClass.length && (this.addCartClass.unbind("click"), this.addCartClass.on("click", function() {
              var t = $(this).data("id");
              $("#ProductSelect-product-template.variation-select").val(t), $("#AddToCart-product-template").trigger("click")
          }))
      },
      onUnload: function(t) {
          this.$container.off(this.wrapperNamspace)
      }
  }), t
}(), theme.CartVariantMobile = function() {
  function t(t) {
      var e = this.$container = $(t),
          i = this.sectionId = e.attr("data-section-id");
      e.attr("data-section-type");
      this.wrapperId = $("#" + i), this.wrapper = $("#" + i), this.wrapperNamspace = "#" + i, this.addCartId = $("#btn-" + i + ".m-allow-cart"), this.addCartClass = $(".variant-item-" + i + ".m-allow-cart"), this._init()
  }
  return t.prototype = _.assignIn({}, t.prototype, {
      _init: function() {
          this._initScroll()
      },
      _initScroll: function() {
          $(window).on("scroll", function() {
              var t = $("#shopify-section-product-variants-mobile").height();
              $(window).scrollTop() > t ? $(document.body).addClass("sticky-product-variants-mobile") : ($(document.body).removeClass("sticky-product-variants-mobile"), $(".product-variants-mobile").hasClass("active") && $(".product-variants-mobile").height($(".variants-header").data("height")))
          })
      },
      onUnload: function(t) {
          this.$container.off(this.wrapperNamspace)
      }
  }), t
}(), theme.Brands = function() {
  function t(t) {
      var e = this.$container = $(t),
          i = this.sectionId = e.attr("data-section-id");
      e.attr("data-section-type");
      this.brandsId = $("#brands-" + i), this.featuredBrands = $(".featured-brands-" + i), this.brandsNamspace = "#brands-" + i, this._init()
  }
  return t.prototype = _.assignIn({}, t.prototype, {
      _init: function() {
          var t = this.featuredBrands.data("perview"),
              e = this.featuredBrands.data("autoplay"),
              i = this.featuredBrands.data("speed");
          this.featuredBrands.not(".slick-initialized").slick({
              rtl: window.rtl,
              slidesToShow: t,
              slidesToScroll: 1,
              autoplaySpeed: i,
              autoplay: e,
              infinite: !0,
              prevArrow: '<a class="prev-button arrow-btn" href="#"><svg><use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#global__symbols-prev"></use></svg></a>',
              nextArrow: '<a class="next-button arrow-btn" href="#"><svg><use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#global__symbols-next"></use></svg></a>',
              responsive: [{
                  breakpoint: 1200,
                  settings: {
                      slidesToShow: 4,
                      slidesToScroll: 1
                  }
              }, {
                  breakpoint: 992,
                  settings: {
                      slidesToShow: 3,
                      slidesToScroll: 1
                  }
              }, {
                  breakpoint: 767,
                  settings: {
                      slidesToShow: 2,
                      slidesToScroll: 1
                  }
              }]
          })
      },
      onUnload: function(t) {
          this.$container.off(this.brandsNamspace)
      }
  }), t
}(), theme.rvsVideo = function() {
  function t(t) {
      var e = this.$container = $(t),
          i = this.sectionId = e.attr("data-section-id");
      e.attr("data-section-type");
      this.rvsId = $("#shopify-section-" + i), this.rvsNamspace = "#rvsvideo-" + i + "_wrapper", this.rvsMain = "#rvsvideo-" + i, this.placement_fullwidth = $(this.rvsNamspace).data("placement_fullwidth"), this.delayTime = $(this.rvsNamspace).data("delaytime"), this._init()
  }
  return t.prototype = _.assignIn({}, t.prototype, {
      _init: function() {
          var t, e = this.sectionId,
              i = this.rvsMain,
              a = this.delayTime,
              n = this.placement_fullwidth,
              o = jQuery;
          o(document).ready(function() {
              null == o(i).revolution ? revslider_showDoubleJqueryError(i) : (t = o(i).show().revolution({
                  sliderType: "carousel",
                  jsFileLocation: "https://cdn.shopify.com/s/files/1/0024/1149/5539/files/",
                  sliderLayout: "fullwidth",
                  dottedOverlay: "none",
                  delay: a,
                  navigation: {
                      keyboardNavigation: "off",
                      keyboard_direction: "horizontal",
                      mouseScrollNavigation: "off",
                      mouseScrollReverse: "default",
                      onHoverStop: "off",
                      touch: {
                          touchenabled: "on",
                          touchOnDesktop: "off",
                          swipe_threshold: 75,
                          swipe_min_touches: 1,
                          swipe_direction: "horizontal",
                          drag_block_vertical: !1
                      },
                      arrows: {
                          style: "gyges",
                          enable: !0,
                          hide_onmobile: !1,
                          hide_onleave: !1,
                          tmp: "",
                          left: {
                              h_align: "left",
                              v_align: "center",
                              h_offset: 20,
                              v_offset: 0
                          },
                          right: {
                              h_align: "right",
                              v_align: "center",
                              h_offset: 20,
                              v_offset: 0
                          }
                      },
                      tabs: {
                          style: "gyges",
                          enable: !0,
                          width: 250,
                          height: 80,
                          min_width: 250,
                          wrapper_padding: 30,
                          wrapper_color: "rgba(38,41,43,1)",
                          tmp: '<div class="tp-tab-content">  <span class="tp-tab-date">{{param1}}</span>  <span class="tp-tab-title">{{title}}</span></div><div class="tp-tab-image"></div>',
                          visibleAmount: 5,
                          hide_onmobile: !1,
                          hide_onleave: !1,
                          hide_delay: 200,
                          direction: "horizontal",
                          span: !0,
                          position: "outer-bottom",
                          space: 0,
                          h_align: "center",
                          v_align: "bottom",
                          h_offset: 0,
                          v_offset: 0
                      }
                  },
                  carousel: {
                      horizontal_align: "center",
                      vertical_align: "center",
                      fadeout: "on",
                      vary_fade: "on",
                      maxVisibleItems: 3,
                      infinity: "on",
                      space: 0,
                      stretch: "off",
                      showLayersAllTime: "off",
                      easing: "Power3.easeInOut",
                      speed: "800"
                  },
                  visibilityLevels: [1240, 1024, 778, 480],
                  gridwidth: 720,
                  gridheight: 405,
                  lazyType: "none",
                  shadow: 0,
                  spinner: "off",
                  stopLoop: "on",
                  stopAfterLoops: 0,
                  stopAtSlide: 1,
                  shuffle: "off",
                  autoHeight: "off",
                  disableProgressBar: "on",
                  hideThumbsOnMobile: "off",
                  hideSliderAtLimit: 0,
                  hideCaptionAtLimit: 0,
                  hideAllCaptionAtLilmit: 0,
                  debugMode: !1,
                  fallbacks: {
                      simplifyAll: "off",
                      nextSlideOnWindowFocus: "off",
                      disableFocusListener: !1
                  }
              })).one("revolution.slide.onloaded", function() {
                  "1" != n || window.sidebar || onFullWidthOption(e), t.revredraw()
              })
          })
      },
      onUnload: function() {}
  }), t
}(), theme.rvsHighlight = function() {
  function t(t) {
      var e = this.$container = $(t),
          i = this.sectionId = e.attr("data-section-id");
      e.attr("data-section-type");
      this.rvshighlightId = $("#shopify-section-" + i), this.rvshighlightNamspace = "#rvshighlight-" + i + "_wrapper", this.rvshighlightMain = "#rvshighlight-" + i, this.placement_fullwidth = $(this.rvshighlightNamspace).data("placement_fullwidth"), this.delayTime = $(this.rvshighlightNamspace).data("delaytime"), this._init()
  }
  return t.prototype = _.assignIn({}, t.prototype, {
      _init: function() {
          var t, e = this.sectionId,
              i = this.rvshighlightMain,
              a = this.delayTime,
              n = this.placement_fullwidth,
              o = jQuery;
          o(document).ready(function() {
              null == o(i).revolution ? revslider_showDoubleJqueryError(i) : (t = o(i).show().revolution({
                  sliderType: "standard",
                  jsFileLocation: "https://cdn.shopify.com/s/files/1/0024/1149/5539/files/",
                  sliderLayout: "auto",
                  dottedOverlay: "none",
                  delay: a,
                  navigation: {
                      keyboardNavigation: "off",
                      keyboard_direction: "horizontal",
                      mouseScrollNavigation: "off",
                      mouseScrollReverse: "default",
                      onHoverStop: "off",
                      touch: {
                          touchenabled: "on",
                          swipe_threshold: 75,
                          swipe_min_touches: 1,
                          swipe_direction: "horizontal",
                          drag_block_vertical: !1
                      },
                      tabs: {
                          style: "zeus",
                          enable: !0,
                          width: 100,
                          height: 30,
                          min_width: 100,
                          wrapper_padding: 0,
                          wrapper_color: "transparent",
                          wrapper_opacity: "0",
                          tmp: '<span class="tp-tab-title">{{title}}</span>',
                          visibleAmount: 3,
                          hide_onmobile: !0,
                          hide_under: 480,
                          hide_onleave: !1,
                          hide_delay: 200,
                          direction: "horizontal",
                          span: !0,
                          position: "inner",
                          space: 1,
                          h_align: "left",
                          v_align: "top",
                          h_offset: 30,
                          v_offset: 30
                      }
                  },
                  viewPort: {
                      enable: !0,
                      outof: "pause",
                      visible_area: "90%",
                      presize: !1
                  },
                  responsiveLevels: [1240, 1024, 778, 480],
                  visibilityLevels: [1240, 1024, 778, 480],
                  gridwidth: [1230, 1024, 767, 480],
                  gridheight: [720, 720, 480, 360],
                  lazyType: "none",
                  parallax: {
                      type: "scroll",
                      origo: "enterpoint",
                      speed: 400,
                      levels: [5, 10, 15, 20, 25, 30, 35, 40, 45, 50, 46, 47, 48, 49, 50, 55]
                  },
                  shadow: 0,
                  spinner: "off",
                  stopLoop: "off",
                  stopAfterLoops: -1,
                  stopAtSlide: -1,
                  shuffle: "off",
                  autoHeight: "off",
                  hideThumbsOnMobile: "off",
                  hideSliderAtLimit: 0,
                  hideCaptionAtLimit: 0,
                  hideAllCaptionAtLilmit: 0,
                  debugMode: !1,
                  fallbacks: {
                      simplifyAll: "off",
                      nextSlideOnWindowFocus: "off",
                      disableFocusListener: !1
                  }
              })).one("revolution.slide.onloaded", function() {
                  "1" != n || window.sidebar || onFullWidthOption(e), t.revredraw()
              })
          })
      },
      onUnload: function() {}
  }), t
}(), theme.rvsProducts = function() {
  function t(t) {
      var e = this.$container = $(t),
          i = this.sectionId = e.attr("data-section-id");
      e.attr("data-section-type");
      this.rvsproductsId = $("#shopify-section-" + i), this.rvsproductsNamspace = "#rvsproducts-" + i + "_wrapper", this.rvsproductsMain = "#rvsproducts-" + i, this.placement_fullwidth = $(this.rvsproductsNamspace).data("placement_fullwidth"), this.delayTime = $(this.rvsproductsNamspace).data("delaytime"), this._init()
  }
  return t.prototype = _.assignIn({}, t.prototype, {
      _init: function() {
          var t, e = this.sectionId,
              i = this.rvsproductsMain,
              a = this.delayTime,
              n = this.placement_fullwidth,
              o = jQuery;
          o(document).ready(function() {
              null == o(i).revolution ? revslider_showDoubleJqueryError(i) : (t = o(i).show().revolution({
                  sliderType: "standard",
                  jsFileLocation: "https://cdn.shopify.com/s/files/1/0024/1149/5539/files/",
                  sliderLayout: "auto",
                  dottedOverlay: "none",
                  delay: a,
                  navigation: {
                      keyboardNavigation: "off",
                      keyboard_direction: "horizontal",
                      mouseScrollNavigation: "off",
                      mouseScrollReverse: "default",
                      onHoverStop: "on",
                      touch: {
                          touchenabled: "on",
                          swipe_threshold: 75,
                          swipe_min_touches: 50,
                          swipe_direction: "horizontal",
                          drag_block_vertical: !1
                      },
                      arrows: {
                          style: "gyges",
                          enable: !0,
                          hide_onmobile: !1,
                          hide_onleave: !1,
                          tmp: "",
                          left: {
                              h_align: "right",
                              v_align: "bottom",
                              h_offset: 40,
                              v_offset: 0
                          },
                          right: {
                              h_align: "right",
                              v_align: "bottom",
                              h_offset: 0,
                              v_offset: 0
                          }
                      }
                  },
                  responsiveLevels: [1240, 1024, 778, 480],
                  visibilityLevels: [1240, 1024, 778, 480],
                  gridwidth: [1200, 1024, 778, 480],
                  gridheight: [600, 600, 600, 600],
                  lazyType: "single",
                  parallax: {
                      type: "scroll",
                      origo: "slidercenter",
                      speed: 400,
                      levels: [5, 10, 15, 20, 25, 30, 35, 40, 45, 46, 47, 48, 49, 50, 51, 55]
                  },
                  shadow: 0,
                  spinner: "off",
                  stopLoop: "off",
                  stopAfterLoops: -1,
                  stopAtSlide: -1,
                  shuffle: "off",
                  autoHeight: "off",
                  disableProgressBar: "on",
                  hideThumbsOnMobile: "off",
                  hideSliderAtLimit: 0,
                  hideCaptionAtLimit: 0,
                  hideAllCaptionAtLilmit: 0,
                  debugMode: !1,
                  fallbacks: {
                      simplifyAll: "off",
                      nextSlideOnWindowFocus: "off",
                      disableFocusListener: !1
                  }
              })).one("revolution.slide.onloaded", function() {
                  "1" != n || window.sidebar || onFullWidthOption(e), t.revredraw()
              })
          })
      },
      onUnload: function() {}
  }), t
}(), theme.YourCollections = function() {
  function t(t) {
      var e = this.$container = $(t),
          i = this.sectionId = e.attr("data-section-id");
      e.attr("data-section-type");
      this.latestCategoryId = $("#shopify-section-" + i), this.latestCategoryNamspace = $(".your-collections-" + i), this._limit = this.latestCategoryNamspace.data("limit"), this._speed = this.latestCategoryNamspace.data("speed"), this._autoplay = this.latestCategoryNamspace.data("autoplay"), this.placement_fullwidth = this.latestCategoryNamspace.data("placement_fullwidth"), this._init()
  }
  return t.prototype = _.assignIn({}, t.prototype, {
      _init: function() {
          var t = this.sectionId,
              e = ".your-collections-wrapper .CollectionGrid-" + t;
          "1" != this.placement_fullwidth || window.sidebar || onFullWidthOption(t), $(e).slick({
              slidesToShow: this._limit,
              slidesToScroll: 1,
              autoplay: this._autoplay,
              autoplaySpeed: this._speed,
              prevArrow: '<a class="prev-button arrow-btn" href="#"><svg><use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#global__symbols-prev"></use></svg></a>',
              nextArrow: '<a class="next-button arrow-btn" href="#"><svg><use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#global__symbols-next"></use></svg></a>',
              rtl: window.rtl,
              responsive: [{
                  breakpoint: 992,
                  settings: {
                      slidesToShow: 4,
                      slidesToScroll: 1
                  }
              }, {
                  breakpoint: 767,
                  settings: {
                      slidesToShow: 3,
                      slidesToScroll: 1
                  }
              }, {
                  breakpoint: 469,
                  settings: {
                      slidesToShow: 2,
                      slidesToScroll: 1
                  }
              }]
          }), roar.initLazyLoading(e, !0)
      },
      onUnload: function(t) {
          this.$container.off(this.latestCategoryNamspace)
      }
  }), t
}(), theme.CollectionsList = function() {
  function t(t) {
      var e = this.$container = $(t),
          i = this.sectionId = e.attr("data-section-id");
      e.attr("data-section-type");
      this.latestCollectionId = $("#shopify-section-" + i), this.latestCollectionNamspace = $(".collections-list-" + i), this._limit = this.latestCollectionNamspace.data("limit"), this._total = this.latestCollectionNamspace.data("count"), this._speed = this.latestCollectionNamspace.data("speed"), this._autoplay = this.latestCollectionNamspace.data("autoplay"), this.placement_fullwidth = this.latestCollectionNamspace.data("placement_fullwidth"), this._init()
  }
  return t.prototype = _.assignIn({}, t.prototype, {
      _init: function() {
          this.sectionId;
          var t = ".content-colection-list-" + this.sectionId;
          roar.initLazyLoading(t, !0), $(t).slick({
              slidesToShow: this._limit,
              slidesToScroll: 1,
              autoplay: this._autoplay,
              autoplaySpeed: this._speed,
              prevArrow: '<a class="prev-button arrow-btn" href="#"><svg><use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#global__symbols-prev"></use></svg></a>',
              nextArrow: '<a class="next-button arrow-btn" href="#"><svg><use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#global__symbols-next"></use></svg></a>',
              rtl: window.rtl,
              responsive: [{
                  breakpoint: 767,
                  settings: {
                      slidesToShow: 2,
                      slidesToScroll: 1
                  }
              }, {
                  breakpoint: 469,
                  settings: {
                      slidesToShow: 1,
                      slidesToScroll: 1
                  }
              }]
          })
      },
      onUnload: function(t) {
          this.$container.off(this.latestCollectionNamspace)
      }
  }), t
}(), theme.ShippingCalculator = function() {
  function ShippingCalculator(t) {
      var e = (this.$container = $(t)).attr("data-section-id");
      this.selectors = {
          shipping_btn: "#cart__shipping-btn-" + e,
          shipping_calculator: "#shipping__calculator-" + e,
          get_rates: "#shipping__calculator-btn-" + e,
          response: "#shipping__calculator-response-" + e,
          template: '<p id ="shipping-rates-feedback-' + e + '" class="shipping-rates-feedback"></p>',
          address_country: "address_country-" + e,
          address_province: "address_province-" + e,
          address_zip: "address_zip-" + e,
          address_province_label: "address_province_label-" + e,
          address_province_container: "address_province_container-" + e
      }, this.strings = {
          submitButton: "Calculate shipping",
          submitButtonDisabled: "Calculating...",
          customerIsLoggedIn: !1,
          moneyFormat: theme.settings.moneyFormat
      }, this._init()
  }
  return ShippingCalculator.prototype = _.assignIn({}, ShippingCalculator.prototype, {
      _disableButtons: function() {
          var t = this.selectors,
              e = this.strings;
          $(t.get_rates).text(e.submitButtonDisabled).attr("disabled", "disabled").addClass("disabled")
      },
      _enableButtons: function() {
          var t = this.selectors,
              e = this.strings;
          $(t.get_rates).removeAttr("disabled").removeClass("disabled").text(e.submitButton)
      },
      _render: function(t) {
          var e = this.selectors,
              i = (this.strings, $(e.template)),
              a = $(e.response);
          if (a.length) {
              if (t.success)
                  if (i.addClass("success"), t.rates) {
                      i.append(t.rates);
                      var n = t.rates;
                      if (n[0]) {
                          var o = n[0];
                          i.append('Rates start at <span class="money">' + o.price + "</span>.")
                      }
                  } else i.append("We do not ship to this destination.");
              else i.addClass("error"), i.append(t.errorFeedback);
              i.appendTo(a), window.show_multiple_currencies && theme.CurrencyPicker.convert(e.response + " .money")
          }
      },
      _formatRate: function(t) {
          this.selectors;
          var e = this.strings;
          if ("function" == typeof theme.Currency.formatMoney) return theme.Currency.formatMoney(t, e.moneyFormat);
          "string" == typeof t && (t = t.replace(".", ""));
          var i = "",
              a = /\{\{\s*(\w+)\s*\}\}/,
              n = e.moneyFormat;

          function o(t, e) {
              return void 0 === t ? e : t
          }

          function s(t, e, i, a) {
              if (e = o(e, 2), i = o(i, ","), a = o(a, "."), isNaN(t) || null == t) return 0;
              var n = (t = (t / 100).toFixed(e)).split(".");
              return n[0].replace(/(\d)(?=(\d\d\d)+(?!\d))/g, "$1" + i) + (n[1] ? a + n[1] : "")
          }
          switch (n.match(a)[1]) {
              case "amount":
                  i = s(t, 2);
                  break;
              case "amount_no_decimals":
                  i = s(t, 0);
                  break;
              case "amount_with_comma_separator":
                  i = s(t, 2, ".", ",");
                  break;
              case "amount_no_decimals_with_comma_separator":
                  i = s(t, 0, ".", ",")
          }
          return n.replace(a, i)
      },
      _onCartShippingRatesUpdate: function(t, e) {
          var i = this.selectors;
          this.strings;
          this._enableButtons();
          var a = "";
          if (e.zip && (a += e.zip + ", "), e.province && (a += e.province + ", "), a += e.country, t.length)
              for (var n = 0; n < t.length; n++) t[n].price = this._formatRate(t[n].price);
          this._render({
              rates: t,
              address: a,
              success: !0
          }), $(i.response).fadeIn()
      },
      _pollForCartShippingRatesForDestination: function(a) {
          var n = this,
              o = (this.selectors, this.strings, function() {
                  $.ajax("/cart/async_shipping_rates", {
                      dataType: "json",
                      success: function(t, e, i) {
                          200 === i.status ? n._onCartShippingRatesUpdate(t.shipping_rates, a) : setTimeout(o, 500)
                      },
                      error: function(t, e) {
                          n._onError(t, e, n)
                      }
                  })
              });
          return o
      },
      _fullMessagesFromErrors: function(t) {
          this.selectors, this.strings;
          var a = [];
          return $.each(t, function(i, t) {
              $.each(t, function(t, e) {
                  a.push(i + " " + e)
              })
          }), a
      },
      _onError: function(XMLHttpRequest, textStatus, self) {
          var selectors = self.selectors,
              strings = self.strings;
          self._enableButtons();
          var feedback = "",
              data = eval("(" + XMLHttpRequest.responseText + ")");
          feedback = data.message ? data.message + "(" + data.status + "): " + data.description : "Error : " + self._fullMessagesFromErrors(data).join("; ") + ".", "Error : country is not supported." === feedback && (feedback = "We do not ship to this destination."), self._render({
              rates: [],
              errorFeedback: feedback,
              success: !1
          }), $(selectors.response).show()
      },
      _getCartShippingRatesForDestination: function(t) {
          var i = this;
          this.selectors, this.strings;
          $.ajax({
              type: "POST",
              url: "/cart/prepare_shipping_rates",
              data: $.param({
                  shipping_address: t
              }),
              success: i._pollForCartShippingRatesForDestination(t),
              error: function(t, e) {
                  i._onError(t, e, i)
              }
          })
      },
      _init: function() {
          var e = this,
              i = this.selectors,
              t = this.strings;
          if ($(i.shipping_calculator).length) {
              new Shopify.CountryProvinceSelector(i.address_country, i.address_province, {
                  hideElement: i.address_province_container
              });
              var a = $("#" + i.address_country),
                  n = $("#" + i.address_province_label).get(0);
              "undefined" != typeof Countries && (Countries.updateProvinceLabel(a.val(), n), a.change(function() {
                  Countries.updateProvinceLabel(a.val(), n)
              })), $(i.get_rates).click(function() {
                  e._disableButtons(), $(i.response).empty().hide();
                  var t = {};
                  t.zip = $("#" + i.address_zip).val() || "", t.country = $("#" + i.address_country).val() || "", t.province = $("#" + i.address_province).val() || "", e._getCartShippingRatesForDestination(t)
              }), t.customerIsLoggedIn && $(i.get_rates + ":eq(0)").trigger("click"), $(i.shipping_btn).click(function() {
                  $(i.shipping_calculator).slideToggle()
              })
          }
      },
      onUnload: function() {}
  }), ShippingCalculator
}(), theme.GalleryTemplate = function() {
  function t(t) {
      var e = (this.$container = $(t)).attr("data-section-id");
      this.selectors = {
          grid_gallery: "grid-gallery-" + e
      }, this._init()
  }
  return t.prototype = _.assignIn({}, t.prototype, {
      _init: function() {
          new CBPGridGallery(document.getElementById(this.selectors.grid_gallery))
      },
      onUnload: function() {}
  }), t
}(), theme.FilterWidgetSection = function() {
  function t(t) {
      var e = this.$container = $(t),
          i = this.sectionId = e.attr("data-section-id");
      e.attr("data-section-type");
      this.filterWidgetId = $("#shopify-section-" + i), this.filterWidgetNamspace = "#filter-widget-" + i, this.filterNewSelect = $("#filter-widget-" + i + " .new-select"), this.filterCollectionId = $("#filter-widget-" + i + " #select_collection select"), this.filterTagSelection = $("#filter-widget-" + i + " .tag-selection"), this.filterButton = $("#filter-widget-" + i + " .button"), this.placement_fullwidth = $(this.filterWidgetNamspace).data("placement_fullwidth"), this._init(), this._initDropdown()
  }
  return t.prototype = _.assignIn({}, t.prototype, {
      _init: function() {
          "1" != this.placement_fullwidth || window.sidebar || onFullWidthOption(this.sectionId)
      },
      _initDropdown: function() {
          this.filterNewSelect.each(function() {
              var e = $(this).find("select"),
                  i = $(this).find("a.custom-selection"),
                  a = $(this).find("ul.custom-options"),
                  t = a.find("a");
              i.click(function(t) {
                  t.stopPropagation(), $("a.custom-selection").not(this).next("ul.options").hide().removeClass("active"), $(this).next(a).stop().slideToggle("fast", function() {
                      $(this).toggleClass("active")
                  })
              }), t.click(function(t) {
                  console.log("xx"), t.stopPropagation(), i.text($(this).text()).removeClass("active"), e.find("option").prop("selected", !1), e.find('option[value="' + $(this).attr("rel") + '"]').prop("selected", "selected"), a.hide(), e.change()
              }), $(document).click(function() {
                  i.removeClass("active"), a.hide()
              })
          });
          var e = this.filterTagSelection;
          this.filterCollectionId.on("change", function() {
              var t = $(this).find("option:selected").val();
              $(this).parent().find(".first").removeClass("hidden"), "" === t ? (e.find(".custom-select").addClass("disabled"), e.find(".tag-filter").val("").attr("disabled", !0)) : ($(this).parent().find(".error").hide(), e.find(".custom-select").removeClass("disabled").addClass("enabled"), e.find(".tag-filter").val("").attr("disabled", !1))
          });
          var i = this.filterTagSelection.find("select");
          i.on("change", function() {
              $(this).find("option:selected").val();
              $(this).parent().find(".first").removeClass("hidden")
          });
          var a = this.filterCollectionId,
              n = this.filterCollectionId.parent().find(".error");
          this.filterButton.click(function() {
              var e = [];
              if (i.each(function() {
                      var t = $(this).val();
                      "" !== t && e.push(t)
                  }), "" == a.val()) n.show();
              else {
                  var t = window.location.origin + a.val() + "?constraint=" + e.join("+");
                  window.location = t, n.hide()
              }
          })
      },
      onUnload: function(t) {
          this.$container.off(this.filterWidgetNamspace)
      }
  }), t
}(), $(document).ready(function() {
  var t = new theme.Sections;
  t.register("product-template", theme.Product),
  t.register("mega-menu", theme.MegaMenuSection),
  t.register("topblock-section", theme.TopBlockSection),
  t.register("custom-widget", theme.CustomWidgetSection),
  t.register("banner", theme.BannerSection),
  t.register("delivery-bar", theme.DeliveryBarSection),
  t.register("slideshow", theme.SlideShowSection),
  t.register("slideshow-with-html", theme.SlideShowSection),
  t.register("slideshow-with-megamenu", theme.SlideShowSection),
  t.register("sidebar", theme.SidebarSection),
  t.register("product-tab", theme.ProductTabSection),
  t.register("advanced-grid", theme.AdvancedGridSection),
  t.register("preface-footer", theme.PrefaceFooterSection),
  t.register("footer-top", theme.FooterTopSection),
  t.register("footer-bottom", theme.FooterBottomSection),
  t.register("footer-copyright", theme.FooterCopyRightSection),
  t.register("footer-column-1", theme.FooterColumn),
  t.register("footer-column-2", theme.FooterColumn),
  t.register("footer-column-3", theme.FooterColumn),
  t.register("footer-column-4", theme.FooterColumn),
  t.register("testimonial", theme.TestimonialSection),
  t.register("instafeed", theme.InstafeedSection),
  t.register("latest-blog", theme.LatestBlogSection),
  t.register("mobile-nav-section", theme.mobileNavSection),
  t.register("product-variant-mobile", theme.ProductVariantMobile),
  t.register("cart-variant-mobile", theme.CartVariantMobile),
  t.register("brands", theme.Brands),
  t.register("rvsvideo", theme.rvsVideo),
  t.register("rvshighlight", theme.rvsHighlight),
  t.register("rvsproducts", theme.rvsProducts),
  t.register("your-collections", theme.YourCollections),
  t.register("collections-list", theme.CollectionsList),
  t.register("shipping-calculator", theme.ShippingCalculator),
  t.register("collection-template", theme.Filters),
  t.register("search-template", theme.Filters),
  t.register("gallery-template", theme.GalleryTemplate),
  t.register("filter-widget", theme.FilterWidgetSection)
});

(function ($) {
  'use strict';
  window.onresize = function(){
    roar.getWidthBrowser() < 768 &&
    $("#popup-mailchimp.hidden-xs").find(".mfp-close").trigger("click");
  };

  window.onload = function () {
    document.body.classList.add('loaded');

    roar.init();
    theme.CurrencyPicker.init();
    theme.LanguagePicker.init();
    roar.initLazyLoading();
    setTimeout(function(){roar.handleSeasonalFrame();},3000);
  }
})(jQuery);